# Cómo poner el perfil navideño

Son dos repos públicos en GitHub:

- **`Cheque2305`** → el README que sale en tu perfil. Se sube todo lo de esta carpeta.
- **`cheque2305.github.io`** → tu página con música (https://cheque2305.github.io). Se sube **solo** `pagina/index.html`.

## 1. La página con música (`cheque2305.github.io`)

1. Abre https://github.com/Cheque2305/cheque2305.github.io
2. **Add file › Upload files** y arrastra **solo** el archivo `pagina/index.html` (un archivo, sin carpetas).
3. **Commit changes**. En 1 a 10 minutos https://cheque2305.github.io muestra la pantalla de arranque con el botón **¡QUE EMPIECE LA FIESTA!**.

## 2. El perfil (`Cheque2305`)

1. Crea un repo **público** llamado exactamente `Cheque2305` (igual que tu usuario). Si ya existe, entra a él.
2. **Add file › Upload files** y arrastra lo que hay **dentro** de esta carpeta: `README.md`, `COMO-INSTALAR.md` y las carpetas `assets`, `scripts`, `pagina` y `.github`.
   - En Mac la carpeta `.github` está oculta: en Finder presiona **Cmd + Shift + .** para verla.
3. **Commit changes**.
4. **Settings › Actions › General › Workflow permissions** → **Read and write permissions** → Save.
5. **Actions › Perfil navideño › Run workflow** (la primera vez a mano; después corre solo cada día a las 00:07 y actualiza la cuenta regresiva y la serpiente).

## Personalizar (opcional)

Todo se regenera con Python 3 (y `pip install numpy scipy pillow fonttools` para el árbol 3D y el Nacimiento):

- `python3 scripts/generar_svgs.py` – banner y guirnalda (textos en la sección CONFIGURACIÓN).
- `python3 scripts/arte.py` – el Christmas Tree en arte ASCII (luces, regalos, luna y trineo). Con `--terminal` lo ves en tu terminal a color.
- `python3 scripts/personajes.py` – La Villa de Santa, sprites sueltos y botón de música (motor de pixeles en `scripts/pixel.py`).
- `python3 scripts/ballet.py` – El Cascanueces y la bailarina: poses con esqueleto, el teatrito y la coreografía de 32 tiempos (`assets/cascanueces.svg` y `assets/ballet/`).
- `python3 scripts/nacimiento.py` – Noche de paz: pinta Belén y el pesebre y los convierte en letras de código (`assets/nacimiento.svg`). Tarda unos minutos.
- `scripts/gala.py` – adornos de la página (ramitas de acebo y notitas musicales); los usa `pagina.py`.
- `python3 scripts/cuenta_regresiva.py` – cuenta regresiva (`FECHA=2026-12-25 python3 ...` para probar otra fecha).
- `python3 scripts/pagina.py` – vuelve a armar `pagina/index.html` con todo lo anterior adentro.
- Colores: `scripts/comun.py` y `scripts/pixel.py`.

## Sobre la música

GitHub no deja que un README reproduzca audio y los navegadores bloquean el sonido automático, por eso el botón **Dale play** abre tu página, donde la Radio Polo Norte (tu playlist de YouTube) arranca al presionar **¡Que empiece la fiesta!**. Mientras suena, la Villa de Santa y el Cascanueces bailan al ritmo de la canción; si la pausas, vuelven a pasear y a ensayar.

- La playlist se cambia en `scripts/pagina.py` (`LISTA = "..."`). Si la dejas vacía (`LISTA = ""`) suena solo `VIDEO`.
- El tempo de cada canción se adivina por su título (las más conocidas) o queda en 120. Para que bailen exacto: presiona **♪ marcar ritmo** (o la tecla **T**) tres o cuatro veces al compás.
- Ojo: el reproductor de YouTube muestra el nombre del canal dueño de la playlist. Si no quieres que se vea, cámbiale el nombre al canal o pásale a `pagina.py` una playlist de otra cuenta.

## Quitarlo después de las fiestas

Desactiva el workflow (Actions › Perfil navideño › ··· › Disable workflow) y cambia el README por el de siempre.

Fuentes incrustadas (licencia SIL OFL 1.1, ver `scripts/fuente/`): Share Tech Mono, JetBrains Mono, Press Start 2P y Fredoka. El Nacimiento cita Lc 2, 7; Lc 2, 11; Lc 2, 14 y Jn 1, 14.
