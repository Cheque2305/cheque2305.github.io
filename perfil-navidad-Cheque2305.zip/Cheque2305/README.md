<!-- 🎄 Perfil navideño · los SVG se generan con los scripts de scripts/ -->

<p align="center">
  <img src="assets/banner.svg" alt="Feliz Navidad en ceros y unos" width="100%">
</p>

<p align="center">
  <a href="https://cheque2305.github.io"><img src="assets/musica.svg" alt="Dale play: entra a la gala navideña con música" width="100%"></a>
</p>

<h3 align="center">🎅 La Villa de Santa</h3>

<p align="center">
  <img src="assets/personajes.svg" alt="La Villa de Santa en pixel art: muñeco de nieve, pingüino, oso polar, Santa, reno y galleta de jengibre caminando" width="100%">
</p>

<h3 align="center">🎄 Christmas Tree</h3>

<p align="center">
  <img src="assets/arbol-ascii.svg" alt="Christmas Tree: árbol de Navidad 3D en arte ASCII que gira, con luces, regalos, luna llena y el trineo de Santa" width="100%">
</p>

<h3 align="center">🩰 El Cascanueces</h3>

<p align="center">
  <img src="assets/cascanueces.svg" alt="El Cascanueces y la bailarina bailando en un teatrito navideño, en pixel art" width="100%">
</p>

<p align="center">
  <img src="assets/cuenta-regresiva.svg" alt="Cuenta regresiva para Navidad" width="100%">
</p>

<h3 align="center">⭐ Noche de paz</h3>

<p align="center">
  <img src="assets/nacimiento.svg" alt="Noche de paz: Belén de noche, la estrella y su luz sobre el pesebre con María, José y el Niño, hecho de letras de código" width="78%">
</p>

<img src="assets/guirnalda.svg" alt="" width="100%">

<h3 align="center"><code>&gt; ./serpiente --se-come-mis-commits-como-tamales</code></h3>

<p align="center">
  <img src="assets/serpiente-navidad.svg" alt="Serpiente navideña comiéndose las contribuciones" width="100%">
</p>

<img src="assets/guirnalda.svg" alt="" width="100%">

<p align="center">
  <img src="https://komarev.com/ghpvc/?username=Cheque2305&label=invitados%20a%20la%20posada&color=e63946&style=for-the-badge" alt="visitas">
</p>

<p align="center">
  <sub><code>01000110 01100101 01101100 01101001 01111010 00100000 01001110 01100001 01110110 01101001 01100100 01100001 01100100</code></sub>
</p>
