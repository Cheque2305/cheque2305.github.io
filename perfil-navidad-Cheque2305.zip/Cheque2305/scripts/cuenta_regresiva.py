#!/usr/bin/env python3
"""Genera assets/cuenta-regresiva.svg con los días que faltan para Navidad.

Lo corre el GitHub Action cada día a las 00:07 (hora del centro de México).
Solo usa la biblioteca estándar de Python.

Para probar otra fecha:  FECHA=2026-12-24 python3 scripts/cuenta_regresiva.py
"""
import os
import random
from datetime import date, datetime, timedelta, timezone

from comun import (ASSETS, FONDO, ORO, ROJO, VERDE, VERDE2, BLANCO,
                   ancho, esc, patron_scanlines, svg_doc)

PROMPT = "cheque@navidad"
MX = timezone(timedelta(hours=-6))  # el centro de México ya no usa horario de verano


def hoy() -> date:
    if os.environ.get("FECHA"):
        return date.fromisoformat(os.environ["FECHA"])
    return datetime.now(MX).date()


def estado(d: date):
    """Regresa (modo, dias, antes, despues, porcentaje, etiqueta)."""
    navidad = date(d.year, 12, 25)
    inicio = date(d.year, 1, 1)
    if d == navidad:
        return "fiesta", 0, "", "¡FELIZ NAVIDAD!", 100.0, f"navidad {d.year}"
    if d > navidad:
        anio = date(d.year + 1, 1, 1)
        dias = (anio - d).days
        pct = (d - inicio).days / (anio - inicio).days * 100
        return ("cuenta", dias, "FALTA" if dias == 1 else "FALTAN",
                f"{'DÍA' if dias == 1 else 'DÍAS'} PARA {d.year + 1}", pct, f"año {d.year}")
    if d == inicio:
        return "fiesta", 0, "", f"¡FELIZ AÑO {d.year}!", 0.0, f"año {d.year}"
    dias = (navidad - d).days
    pct = (d - inicio).days / (navidad - inicio).days * 100
    return ("cuenta", dias, "FALTA" if dias == 1 else "FALTAN",
            f"{'DÍA' if dias == 1 else 'DÍAS'} PARA NAVIDAD", pct, "rumbo a la Nochebuena")


def generar(d: date) -> str:
    W, H = 1200, 176
    modo, dias, antes, despues, pct, etiqueta = estado(d)
    rnd = random.Random(d.toordinal())
    css, cuerpo = [], []
    defs = patron_scanlines() + (
        f'<clipPath id="tarj"><rect width="{W}" height="{H}" rx="22"/></clipPath>'
        '<filter id="oro" x="-30%" y="-30%" width="160%" height="160%">'
        '<feGaussianBlur in="SourceAlpha" stdDeviation="5" result="b"/>'
        f'<feFlood flood-color="{ORO}" flood-opacity=".8"/><feComposite in2="b" operator="in" result="g"/>'
        '<feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge></filter>'
        '<filter id="verde" x="-10%" y="-40%" width="120%" height="180%">'
        '<feGaussianBlur in="SourceAlpha" stdDeviation="6" result="b"/>'
        f'<feFlood flood-color="{VERDE}" flood-opacity=".8"/><feComposite in2="b" operator="in" result="g"/>'
        '<feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge></filter>'
    )
    cuerpo.append(f'<g clip-path="url(#tarj)"><rect width="{W}" height="{H}" fill="{FONDO}"/>')

    # Comando arriba
    cmd = f"{PROMPT}:~$ ./cuenta_regresiva --hoy={d.strftime('%d/%m/%Y')}"
    cuerpo.append(
        f'<text class="m" x="32" y="38" font-size="15" textLength="{ancho(len(cmd), 15):.1f}" '
        f'fill="{VERDE}" opacity=".85">{esc(cmd)}</text>'
    )

    y_base = 112
    if modo == "fiesta":
        fs = 58
        w = ancho(len(despues), fs)
        cuerpo.append(
            f'<text class="m late" x="600" y="{y_base + 4}" font-size="{fs}" text-anchor="middle" '
            f'textLength="{w:.1f}" fill="{ORO}" filter="url(#oro)">{esc(despues)}</text>'
        )
        css.append(".late{animation:late 1.6s ease-in-out infinite}@keyframes late{50%{opacity:.6}}")
    else:
        fs = 36
        txt_digitos = f"{dias:03d}"
        caja_w, caja_h, sep, hueco = 58, 76, 10, 26
        w_antes = ancho(len(antes), fs)
        w_desp = ancho(len(despues), fs)
        w_cajas = 3 * caja_w + 2 * sep
        total = w_antes + hueco + w_cajas + hueco + w_desp
        x = 600 - total / 2
        cuerpo.append(
            f'<text class="m" x="{x:.1f}" y="{y_base}" font-size="{fs}" textLength="{w_antes:.1f}" fill="{BLANCO}">{antes}</text>'
        )
        x += w_antes + hueco
        fs_d = 60
        fila = 70
        for i, dig in enumerate(txt_digitos):
            cx = x + i * (caja_w + sep)
            top = y_base - caja_h + 16
            defs += f'<clipPath id="cd{i}"><rect x="{cx:.1f}" y="{top:.1f}" width="{caja_w}" height="{caja_h}" rx="8"/></clipPath>'
            cuerpo.append(
                f'<rect x="{cx:.1f}" y="{top:.1f}" width="{caja_w}" height="{caja_h}" rx="8" fill="#3a1d18" '
                f'stroke="{VERDE}" stroke-opacity=".6" stroke-width="1.5"/>'
            )
            # Tira de dígitos tipo tragamonedas que se detiene en el dígito real
            tira = [str(rnd.randint(0, 9)) for _ in range(10)] + [dig]
            y_dig = y_base + 6
            textos = "".join(
                f'<text class="m" x="{cx + caja_w/2:.1f}" y="{y_dig + k*fila}" font-size="{fs_d}" '
                f'text-anchor="middle" fill="{ORO}">{c}</text>' for k, c in enumerate(tira)
            )
            css.append(
                f"@keyframes rd{i}{{from{{transform:translateY(0)}}to{{transform:translateY({-10*fila}px)}}}}"
            )
            cuerpo.append(
                f'<g clip-path="url(#cd{i})"><g filter="url(#oro)" '
                f'style="animation:rd{i} {1.3 + i*0.45:.2f}s cubic-bezier(.15,.75,.25,1) .3s both">{textos}</g></g>'
                f'<line x1="{cx+4:.1f}" y1="{top + caja_h/2:.1f}" x2="{cx + caja_w - 4:.1f}" y2="{top + caja_h/2:.1f}" '
                f'stroke="{FONDO}" stroke-width="2" opacity=".8"/>'
            )
        x += w_cajas + hueco
        cuerpo.append(
            f'<text class="m" x="{x:.1f}" y="{y_base}" font-size="{fs}" textLength="{w_desp:.1f}" '
            f'fill="{VERDE}" filter="url(#verde)">{esc(despues)}</text>'
        )

    # Pie: binario a la izquierda, barra de progreso a la derecha
    y_pie = 156
    binario = f"bin: {dias:09b}  ·  hex: 0x{dias:03X}"
    cuerpo.append(
        f'<text class="m" x="32" y="{y_pie}" font-size="14" textLength="{ancho(len(binario), 14):.1f}" '
        f'fill="{VERDE2}">{binario}</text>'
    )
    segs = 30
    llenos = round(pct / 100 * segs)
    seg_w, seg_g = 9, 3
    x_barra = W - 32 - 70 - segs * (seg_w + seg_g)
    lbl = f"{etiqueta} "
    cuerpo.append(
        f'<text class="m" x="{x_barra - 10:.1f}" y="{y_pie}" font-size="14" text-anchor="end" '
        f'textLength="{ancho(len(lbl.strip()), 14):.1f}" fill="#c9a78a">{esc(lbl.strip())}</text>'
    )
    for k in range(segs):
        sx = x_barra + k * (seg_w + seg_g)
        if k < llenos:
            ultimo = k == llenos - 1
            col = ROJO if ultimo else (VERDE if k % 2 == 0 else "#3fc463")
            clase = "seg ult" if ultimo else "seg"
            cuerpo.append(
                f'<rect class="{clase}" style="animation-delay:{0.6 + k*0.04:.2f}s" x="{sx}" y="{y_pie - 12}" '
                f'width="{seg_w}" height="13" rx="1.5" fill="{col}"/>'
            )
        else:
            cuerpo.append(f'<rect x="{sx}" y="{y_pie - 12}" width="{seg_w}" height="13" rx="1.5" fill="#4a2a22"/>')
    pct_txt = f"{pct:5.1f}%"
    cuerpo.append(
        f'<text class="m" x="{W - 32}" y="{y_pie}" font-size="14" text-anchor="end" '
        f'textLength="{ancho(len(pct_txt), 14):.1f}" fill="{ORO}" xml:space="preserve">{pct_txt}</text>'
    )
    css.append(
        ".seg{animation:seg .01s linear both}@keyframes seg{from{opacity:0}to{opacity:1}}"
        ".ult{animation:seg .01s linear both,parp 1s steps(1) 2s infinite}@keyframes parp{50%{opacity:.25}}"
    )

    # Fecha de actualización
    act = f"actualizado {d.strftime('%d/%m/%Y')}"
    cuerpo.append(
        f'<text class="m" x="{W - 32}" y="38" font-size="13" text-anchor="end" '
        f'textLength="{ancho(len(act), 13):.1f}" fill="#a8826a">{act}</text>'
    )

    # Nieve
    flakes = []
    for _ in range(30):
        dur = rnd.uniform(6, 13)
        flakes.append(
            f'<circle class="nv" cx="{rnd.uniform(0, W):.1f}" cy="-6" r="{rnd.uniform(.7, 1.9):.1f}" fill="#fff" '
            f'opacity="{rnd.uniform(.25, .7):.2f}" style="animation-duration:{dur:.2f}s;animation-delay:{-rnd.uniform(0, dur):.2f}s"/>'
        )
    cuerpo.append("".join(flakes))
    css.append(
        ".nv{animation-name:nv;animation-timing-function:linear;animation-iteration-count:infinite}"
        f"@keyframes nv{{to{{transform:translate(14px,{H + 14}px)}}}}"
    )
    cuerpo.append(f'<rect width="{W}" height="{H}" fill="url(#scan)" opacity=".2"/></g>')
    cuerpo.append(
        f'<rect x="1.5" y="1.5" width="{W-3}" height="{H-3}" rx="21" fill="none" stroke="{ORO}" stroke-opacity=".55" stroke-width="3"/>'
    )
    titulo = f"{antes} {dias} {despues}".strip() if modo == "cuenta" else despues
    return svg_doc(W, H, defs, "".join(css), "".join(cuerpo), titulo)


if __name__ == "__main__":
    d = hoy()
    ASSETS.mkdir(exist_ok=True)
    (ASSETS / "cuenta-regresiva.svg").write_text(generar(d), encoding="utf-8")
    print(f"assets/cuenta-regresiva.svg generado para {d.isoformat()}: {estado(d)[2]} {estado(d)[1]} {estado(d)[3]}")
