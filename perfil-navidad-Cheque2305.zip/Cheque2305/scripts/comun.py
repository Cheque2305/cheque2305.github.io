"""Piezas compartidas por los generadores de SVG (fuente, colores, utilidades)."""
import base64
import html
from pathlib import Path

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent
ASSETS = RAIZ / "assets"
FUENTE = AQUI / "fuente" / "ShareTechMono-Regular.woff2"

# Ancho de avance de Share Tech Mono: 0.54 em por carácter
CW = 0.54
CAP = 0.70

# Paleta "Navidad calientita": vino, chocolate, crema, oro y verde pino
VERDE = "#5fe07a"
VERDE2 = "#f0c99a"      # texto secundario color crema dorada
VERDE_OSC = "#1f5a33"
ROJO = "#ff4d5e"
ORO = "#ffcf5a"
AZUL = "#7cc8ff"
ROSA = "#ff8fb8"
BLANCO = "#fff4e6"
FONDO = "#2a1513"       # fondo de ventanas: chocolate
BARRA = "#3b1f1b"
BORDE = "#8a4a34"
TENUE = "#c9a78a"       # texto apagado cálido
VINO = "#4a0f17"
VINO_OSC = "#26080d"
FUENTE_PIXEL = AQUI / "fuente" / "PressStart2P-Regular.woff2"


def esc(t: str) -> str:
    return html.escape(t, quote=True)


def fuente_css() -> str:
    b64 = base64.b64encode(FUENTE.read_bytes()).decode()
    return (
        "@font-face{font-family:'STM';"
        f"src:url(data:font/woff2;base64,{b64}) format('woff2');}}"
        ".m{font-family:'STM','Share Tech Mono','Courier New',monospace;}"
    )


def fuente_pixel_css() -> str:
    b64 = base64.b64encode(FUENTE_PIXEL.read_bytes()).decode()
    return (
        "@font-face{font-family:'PS2P';"
        f"src:url(data:font/woff2;base64,{b64}) format('woff2');}}"
        ".px{font-family:'PS2P',monospace;}"
    )


# Si el visitante pidió menos movimiento, todo queda quieto (y visible)
CSS_MOVIMIENTO = "@media (prefers-reduced-motion: reduce){*{animation:none!important}}"


def ancho(n_chars: int, size: float) -> float:
    return n_chars * CW * size


def a_binario(texto: str) -> str:
    return " ".join(format(b, "08b") for b in texto.encode("latin-1", "replace"))


def svg_doc(w: int, h: int, defs: str, css: str, cuerpo: str, titulo: str) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
        f'viewBox="0 0 {w} {h}" role="img" aria-label="{esc(titulo)}">'
        f"<title>{esc(titulo)}</title>"
        f"<defs>{defs}</defs>"
        f"<style>{fuente_css()}{css}{CSS_MOVIMIENTO}</style>"
        f"{cuerpo}</svg>"
    )


def patron_scanlines(id_="scan") -> str:
    return (
        f'<pattern id="{id_}" width="4" height="4" patternUnits="userSpaceOnUse">'
        '<rect width="4" height="1" fill="#000" opacity=".28"/></pattern>'
    )


def halos() -> str:
    """Degradados radiales para el brillo de los foquitos (más ligeros que un filtro)."""
    out = []
    for nombre, color in (("R", ROJO), ("Y", ORO), ("G", VERDE), ("B", AZUL), ("P", ROSA), ("W", "#ffffff")):
        out.append(
            f'<radialGradient id="halo{nombre}">'
            f'<stop offset="0" stop-color="{color}" stop-opacity=".75"/>'
            f'<stop offset=".45" stop-color="{color}" stop-opacity=".25"/>'
            f'<stop offset="1" stop-color="{color}" stop-opacity="0"/></radialGradient>'
        )
    return "".join(out)


def estrella(cx: float, cy: float, R: float, r: float) -> str:
    import math
    pts = []
    for i in range(10):
        ang = -math.pi / 2 + i * math.pi / 5
        rad = R if i % 2 == 0 else r
        pts.append(f"{cx + rad * math.cos(ang):.1f},{cy + rad * math.sin(ang):.1f}")
    return " ".join(pts)
