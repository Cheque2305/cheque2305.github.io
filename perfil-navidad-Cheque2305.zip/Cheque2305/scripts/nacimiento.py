#!/usr/bin/env python3
"""El Nacimiento: Belén de noche, la estrella, el rayo de luz y el pesebre... hecho de puras letras.

Primero se pinta la escena (con numpy, capa por capa) y luego cada celdita de la
cuadrícula se vuelve un carácter con su color. La animación cuenta la historia:
la noche, aparece la estrella, baja su luz y el pesebre se ilumina.

    python3 scripts/nacimiento.py            # escribe assets/nacimiento.svg
    python3 scripts/nacimiento.py --png      # además guarda la pintura base (para revisar)
"""
import base64
import math
import os
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

AQUI = Path(__file__).resolve().parent
ASSETS = AQUI.parent / "assets"
FUENTE = AQUI / "fuente" / "JetBrainsMono-Regular.woff2"

# Cuadrícula de caracteres y lienzo
COLS, FILAS = 240, 140
CW, CH = 4, 8
W, H = COLS * CW, FILAS * CH          # 960 x 1120
S = int(os.environ.get("NAC_S", 2))     # sobremuestreo para bordes suaves
YY, XX = np.mgrid[0:H * S, 0:W * S].astype(np.float32) / S
RNG = np.random.default_rng(2412)

ESTRELLA = (480.0, 96.0)
MANTO = (480.0, 708.0)                 # el pesebre (donde está el Niño), en coordenadas del establo
K_ESTABLO = 1.55                       # el establo y la Sagrada Familia se ven de cerca
O_ESTABLO = (480 - 480 * K_ESTABLO, 612 - 522 * K_ESTABLO)
DY_PUEBLO = 96
O_PASTOR, K_PASTOR = (884 - 790 * 1.3, 1018 - 738 * 1.3), 1.3

# Transformación actual: las capas cercanas se dibujan en su propio sistema (x, y locales)
TR = [0.0, 0.0, 1.0]
LX, LY = XX, YY


def transformar(ox=0.0, oy=0.0, k=1.0):
    global LX, LY
    TR[:] = [ox, oy, k]
    LX, LY = (XX - ox) / k, (YY - oy) / k


def G(x, y):
    """De coordenadas locales del establo a coordenadas del dibujo."""
    return O_ESTABLO[0] + x * K_ESTABLO, O_ESTABLO[1] + y * K_ESTABLO


def hexa(c):
    c = c.lstrip("#")
    return np.array([int(c[i:i + 2], 16) for i in (0, 2, 4)], np.float32)


_RUIDOS = {}


def ruido(sig, semilla, amp=1.0):
    clave = (sig, semilla % 6)                       # pocas texturas, reusadas (para que sea rápido)
    if clave not in _RUIDOS:
        r = np.random.default_rng(semilla % 6 + 100 * len(_RUIDOS))
        n = ndimage.gaussian_filter(r.normal(size=(H * S, W * S)).astype(np.float32), sig)
        _RUIDOS[clave] = n / (n.std() + 1e-6)
    return _RUIDOS[clave] * amp


def poli(pts):
    ox, oy, k = TR
    im = Image.new("L", (W * S, H * S), 0)
    ImageDraw.Draw(im).polygon([((ox + x * k) * S, (oy + y * k) * S) for x, y in pts], fill=255)
    return np.asarray(im, np.float32) / 255


def elip(cx, cy, rx, ry, ang=0.0):
    if ang:
        c, s = math.cos(ang), math.sin(ang)
        u = ((LX - cx) * c + (LY - cy) * s) / rx
        v = (-(LX - cx) * s + (LY - cy) * c) / ry
        return (u * u + v * v <= 1).astype(np.float32)
    return (((LX - cx) / rx) ** 2 + ((LY - cy) / ry) ** 2 <= 1).astype(np.float32)


def linea(x0, y0, x1, y1, grosor):
    ox, oy, k = TR
    im = Image.new("L", (W * S, H * S), 0)
    ImageDraw.Draw(im).line([((ox + x0 * k) * S, (oy + y0 * k) * S), ((ox + x1 * k) * S, (oy + y1 * k) * S)],
                            fill=255, width=max(1, int(grosor * k * S)))
    return np.asarray(im, np.float32) / 255


def mezcla(t, pasos):
    """Degradado: pasos = [(t, '#rrggbb'), ...] evaluado en el arreglo t."""
    ts = [p for p, _ in pasos]
    cs = np.stack([hexa(c) for _, c in pasos])
    return np.stack([np.interp(t, ts, cs[:, i]) for i in range(3)], -1).astype(np.float32)


class Lienzo:
    def __init__(self):
        self.rgb = np.zeros((H * S, W * S, 3), np.float32)
        self.fig = np.zeros((H * S, W * S), np.float32)     # dónde hay figuras (para dibujarlas más sólidas)
        self.fondo = np.zeros((H * S, W * S), np.float32)   # el interior del establo (se dibuja más suave)
        self.parte = np.zeros((H * S, W * S), np.int16)     # qué pieza es cada pixel (para los contornos)
        self.n = 0

    def pintar(self, m, color, alfa=1.0):
        a = (m * alfa)[..., None]
        col = color if isinstance(color, np.ndarray) and color.ndim == 3 else np.asarray(color, np.float32)
        self.rgb = self.rgb * (1 - a) + col * a

    def luz(self, intensidad, color):
        """Luz que se suma (como un foco): intensidad HxW."""
        self.rgb = self.rgb + intensidad[..., None] * np.asarray(color, np.float32)

    def final(self):
        img = np.clip(self.rgb, 0, 255)
        red = lambda a: a.reshape(H, S, W, S).mean((1, 3))  # noqa: E731
        return img.reshape(H, S, W, S, 3).mean((1, 3)), red(self.fig), red(self.fondo), self.parte[::S, ::S].copy()


# ───────────────────────── la escena, capa por capa ─────────────────────────
def cielo(lz):
    t = YY / 560
    base = mezcla(t, [(0, "#060b22"), (.45, "#0e1a48"), (.8, "#1a2c68"), (1.05, "#2a3f86")])
    pincel = ruido((2.5 * S, 16 * S), 1, .07) + ruido((8 * S, 40 * S), 2, .06)
    base = base * (1 + pincel[..., None])
    d = np.hypot(XX - ESTRELLA[0], (YY - ESTRELLA[1]) * 1.25)
    base = base + (np.exp(-(d / 260) ** 2) * 40)[..., None] * np.array([.55, .7, 1.0])
    lz.pintar(np.ones_like(XX), base)


def estrellitas(lz, semilla=5):
    r = np.random.default_rng(semilla)
    puntos = []
    for _ in range(380):
        x, y = r.uniform(0, W), r.uniform(0, 430) ** 1.0
        if abs(x - ESTRELLA[0]) < 70 and y < 180:
            continue
        b = r.uniform(.35, 1) ** 2
        puntos.append((x, y, b, r.random() < .1))
    for x, y, b, grande in puntos:
        rr = 1.6 if not grande else 2.4
        m = elip(x, y, rr, rr)
        lz.pintar(m, (235 + 20 * b, 238 + 17 * b, 255), .55 + .45 * b)
        if grande:
            lz.pintar(linea(x - 7, y, x + 7, y, 1), (230, 236, 255), .7)
            lz.pintar(linea(x, y - 7, x, y + 7, 1), (230, 236, 255), .7)
    return puntos


def estrella(lz):
    """La estrella de Belén: ocho picos, centro blanco y un halo enorme."""
    cx, cy = ESTRELLA
    d = np.hypot(XX - cx, YY - cy)
    lz.luz(np.exp(-(d / 150) ** 2) * .55 + np.exp(-(d / 46) ** 2) * .9, (120, 140, 200))
    lz.luz(np.exp(-(d / 70) ** 2) * .7, (255, 214, 120))
    for k in range(8):
        a = k * math.pi / 4 - math.pi / 2
        largo = (66 if k % 4 == 0 else 50) if k % 2 == 0 else 30
        if k == 4:
            largo = 84                                 # el pico de abajo apunta al pesebre
        ancho = 9 if k % 2 == 0 else 6
        pa = (cx + math.cos(a + math.pi / 2) * ancho, cy + math.sin(a + math.pi / 2) * ancho)
        pb = (cx - math.cos(a + math.pi / 2) * ancho, cy - math.sin(a + math.pi / 2) * ancho)
        punta = (cx + math.cos(a) * largo, cy + math.sin(a) * largo)
        m = poli([pa, punta, pb])
        lz.pintar(m, mezcla(d / largo, [(0, "#ffffff"), (.35, "#fff6cf"), (.75, "#ffd65a"), (1, "#f2a81e")]))
    lz.pintar(elip(cx, cy, 11, 11), (255, 255, 255))


def colinas(lz):
    x = LX[0]
    r1 = 300 - 78 * np.exp(-((x - 170) / 210) ** 2) - 46 * np.exp(-((x - 830) / 190) ** 2) + 5 * np.sin(x / 23)
    r2 = 420 - 46 * np.exp(-((x - 80) / 170) ** 2) - 64 * np.exp(-((x - 905) / 150) ** 2) + 4 * np.sin(x / 17 + 2)
    for borde, (c1, c2), luz in ((r1, ("#2a3f8c", "#16245a"), "#5c79cf"), (r2, ("#1d2e6e", "#111a45"), "#4a66bd")):
        m = (LY >= borde[None, :]).astype(np.float32)
        prof = np.clip((LY - borde[None, :]) / 160, 0, 1)
        col = mezcla(prof, [(0, c1), (1, c2)]) * (1 + ruido((3 * S, 10 * S), 7, .08)[..., None])
        lz.pintar(m, col)
        filo = ((LY >= borde[None, :]) & (LY < borde[None, :] + 3)).astype(np.float32)
        lz.pintar(filo, hexa(luz), .8)
    return r1, r2


def casa(lz, x, yb, w, h, cara=None, cupula=False, torre=False, ventanas=(), luz_lado=1, frio=1.0):
    """Casita de piedra encalada: frente iluminado por la estrella, costado en sombra."""
    lado = max(4, w * .32)
    frente = cara or "#8ea4dc"
    sombra = "#34488a"
    m_f = poli([(x, yb), (x + w, yb), (x + w, yb - h), (x, yb - h)])
    textura = (1 + ruido((1.2 * S, 3 * S), int(x * 7 + yb), .04))[..., None]
    alto = np.clip((yb - LY) / max(h, 1), 0, 1)[..., None]
    piso = (.62 + .38 * alto)
    lz.pintar(m_f, hexa(frente) * textura * frio * piso)
    if luz_lado > 0:
        m_s = poli([(x + w, yb), (x + w + lado, yb - lado * .45), (x + w + lado, yb - h - lado * .45), (x + w, yb - h)])
    else:
        m_s = poli([(x, yb), (x - lado, yb - lado * .45), (x - lado, yb - h - lado * .45), (x, yb - h)])
    lz.pintar(m_s, hexa(sombra) * textura * frio * piso)
    techo = poli([(x - 1, yb - h), (x + w + 1, yb - h), (x + w + (lado if luz_lado > 0 else 0), yb - h - lado * .45),
                  (x + (0 if luz_lado > 0 else -lado), yb - h - lado * .45)])
    lz.pintar(techo, hexa("#c9d6f6") * frio)
    if cupula:
        lz.pintar(elip(x + w / 2, yb - h, w * .34, w * .3), mezcla((LX - (x + w / 2)) / (w * .34), [(-1, "#d6e2ff"), (1, "#5a71b8")]) * frio)
        lz.pintar(elip(x + w / 2, yb - h, w * .34, w * .3) * (LY > yb - h), hexa("#9fb4e8") * frio)
        lz.pintar(linea(x + w / 2, yb - h - w * .3, x + w / 2, yb - h - w * .3 - 9, 1.4), (220, 228, 250))
        lz.pintar(linea(x + w / 2 - 4, yb - h - w * .3 - 6, x + w / 2 + 4, yb - h - w * .3 - 6, 1.4), (220, 228, 250))
    if torre:
        tw = w * .28
        lz.pintar(poli([(x + 3, yb - h), (x + 3 + tw, yb - h), (x + 3 + tw, yb - h - h * .9), (x + 3, yb - h - h * .9)]), hexa(frente) * frio)
        lz.pintar(elip(x + 3 + tw / 2, yb - h - h * .9, tw / 2, tw * .6) * (LY < yb - h - h * .9), hexa("#c9d6f6") * frio)
    for vx, vy, vw, vh in ventanas:
        X0, Y0 = x + vx * w, yb - vy * h
        arco = poli([(X0, Y0), (X0 + vw, Y0), (X0 + vw, Y0 - vh), (X0, Y0 - vh)]) + elip(X0 + vw / 2, Y0 - vh, vw / 2, vw / 2)
        lz.pintar(np.clip(arco, 0, 1), (255, 206, 104))
        d = np.hypot(LX - (X0 + vw / 2), LY - (Y0 - vh / 2))
        lz.luz(np.exp(-(d / (vw * 2.2)) ** 2) * .35, (255, 170, 70))


def cipres(lz, x, yb, h, w=10):
    m = elip(x, yb - h / 2, w, h / 2)
    lz.pintar(m, mezcla((LX - x) / w, [(-1, "#20365a"), (0, "#0f1d36"), (1, "#081124")]))


def olivo(lz, x, yb, r):
    lz.pintar(linea(x, yb, x - 3, yb - r * .9, 4), (40, 34, 50))
    for k in range(7):
        a = k / 7 * math.tau
        cx, cy = x + math.cos(a) * r * .55, yb - r * 1.15 + math.sin(a) * r * .35
        lz.pintar(elip(cx, cy, r * .55, r * .42), mezcla((LY - (cy - r * .4)) / (r * .9), [(0, "#3f6a86"), (.5, "#1f3a55"), (1, "#0d1c30")]))


def pueblo(lz, r1, r2):
    """Belén sobre las colinas: casitas encaladas, cúpulas, cipreses y ventanas encendidas."""
    rr = np.random.default_rng(31)
    # lejos, sobre la primera colina (chiquitas y frías)
    for x in np.arange(30, 330, 26):
        yb = float(np.interp(x, LX[0], r1)) + 6
        w, h = rr.uniform(16, 26), rr.uniform(12, 22)
        casa(lz, x, yb, w, h, ventanas=[(.35, .4, 3, 4)] if rr.random() < .6 else (), frio=.85)
    casa(lz, 150, float(np.interp(150, LX[0], r1)) - 4, 22, 30, torre=True, frio=.9)          # la torrecita del cerro
    for x in np.arange(700, 930, 28):
        yb = float(np.interp(x, LX[0], r1)) + 6
        casa(lz, x, yb, rr.uniform(16, 24), rr.uniform(12, 20), ventanas=[(.4, .4, 3, 4)] if rr.random() < .5 else (), luz_lado=-1, frio=.85)
    for x in (60, 120, 260, 780, 860):
        cipres(lz, x, float(np.interp(x, LX[0], r1)) + 8, rr.uniform(34, 50), 6)
    # en medio, sobre la segunda colina
    for x, w, h, cup in ((10, 60, 46, False), (66, 44, 36, False), (112, 70, 54, True), (186, 52, 40, False), (236, 46, 34, False)):
        yb = float(np.interp(x + w / 2, LX[0], r2)) + 14
        casa(lz, x, yb, w, h, cupula=cup, ventanas=[(.2, .45, 6, 8), (.62, .45, 6, 8)] if w > 45 else [(.4, .45, 6, 8)])
    for x, w, h in ((662, 54, 42), (720, 66, 50), (790, 48, 38), (842, 72, 56), (918, 50, 40)):
        yb = float(np.interp(min(W - 1, x + w / 2), LX[0], r2)) + 14
        casa(lz, x, yb, w, h, luz_lado=-1, ventanas=[(.22, .45, 6, 8), (.62, .45, 6, 8)] if w > 50 else [(.4, .45, 6, 8)])
    # cerca, a los lados del pesebre: los edificios grandes de piedra
    casa(lz, -20, 600, 150, 120, cupula=True, ventanas=[(.2, .55, 10, 14), (.48, .55, 10, 14), (.75, .55, 10, 14), (.48, .2, 9, 12)])
    casa(lz, 140, 610, 110, 92, ventanas=[(.18, .5, 9, 13), (.6, .5, 9, 13)])
    casa(lz, 690, 612, 120, 100, luz_lado=-1, ventanas=[(.2, .5, 10, 14), (.6, .5, 10, 14), (.4, .15, 9, 12)])
    casa(lz, 820, 600, 160, 124, luz_lado=-1, ventanas=[(.15, .55, 10, 14), (.4, .55, 10, 14), (.65, .55, 10, 14), (.4, .2, 10, 13)])
    for x, h in ((262, 120), (296, 90), (668, 100), (950, 130)):
        cipres(lz, x, 612, h, 11)
    olivo(lz, 40, 690, 46)
    olivo(lz, 905, 686, 50)
    olivo(lz, 230, 700, 34)


def rayo(lz):
    """La luz que baja de la estrella al pesebre: blanca arriba, dorada abajo."""
    cx, y0, y1 = ESTRELLA[0], ESTRELLA[1] + 18, G(0, 528)[1]
    t = np.clip((YY - y0) / (y1 - y0), 0, 1)
    medio = 6 + 130 * t ** 1.15
    d = np.abs(XX - cx) / medio
    dentro = (YY >= y0) & (YY <= y1 + 30)
    cuerpo = np.exp(-d ** 2 * 1.6) * dentro
    nucleo = np.exp(-d ** 2 * 7) * dentro
    vetas = 1 + ruido((26 * S, 1.4 * S), 41, .22)
    fade = np.clip((y1 + 30 - YY) / 40, 0, 1)
    alfa = np.clip((.22 + .5 * t) * cuerpo * vetas * fade, 0, .92)
    color = mezcla(t, [(0, "#f3f6ff"), (.45, "#fdf6dc"), (.72, "#ffe486"), (1, "#ffcf3a")])
    lz.pintar(alfa, color)
    lz.luz(nucleo * fade * (.25 + .55 * t), (255, 236, 170))


def establo(lz, luz):
    """El pesebre: techo de paja, postes de madera y adentro la luz cálida."""
    # pared de piedra del fondo
    adentro = poli([(334, 566), (626, 566), (626, 768), (334, 768)])
    lz.fondo = np.maximum(lz.fondo, adentro)
    if luz:
        d = np.hypot((LX - MANTO[0]) / 1.25, (LY - MANTO[1]) / .95)
        col = mezcla(d / 230, [(0, "#ffd66b"), (.22, "#f0a83c"), (.5, "#b8641e"), (.8, "#5c2a10"), (1, "#2e140a")])
        piedras = 1 + .1 * np.sin(LX / 9 + np.sin(LY / 7) * 2) * np.sin(LY / 6.5) + ruido((2 * S, 3 * S), 8, .06)
        lz.pintar(adentro, col * piedras[..., None])
    else:
        lz.pintar(adentro, mezcla((LY - 566) / 200, [(0, "#191427"), (1, "#0d0b14")]))
    # piso de paja
    paja = poli([(320, 740), (640, 740), (650, 772), (310, 772)])
    tono = ruido((.6 * S, 5 * S), 9, 1)
    if luz:
        d = np.hypot((LX - MANTO[0]) / 1.4, (LY - 750) / .6)
        base = mezcla(d / 200, [(0, "#ffd77a"), (.5, "#d0902e"), (1, "#6a3d16")])
        lz.pintar(paja, base * (1 + .16 * tono[..., None]))
    else:
        lz.pintar(paja, hexa("#2a2128") * (1 + .1 * tono[..., None]))
    # postes y travesaño
    for x0 in (318, 628):
        m = poli([(x0, 592), (x0 + 15, 592), (x0 + 16, 772), (x0 - 1, 772)])
        lado = np.clip((LX - x0) / 15, 0, 1)
        if luz:
            col = mezcla(lado if x0 < 400 else 1 - lado, [(0, "#3a2414"), (1, "#c4843e")])
        else:
            col = mezcla(lado, [(0, "#1b1622"), (1, "#3a3550")])
        lz.pintar(m, col * (1 + .12 * ruido((.5 * S, 8 * S), 11, 1)[..., None]))
    viga = poli([(296, 590), (664, 590), (664, 604), (296, 604)])
    lz.pintar(viga, mezcla((LY - 590) / 14, [(0, "#9a6a3a" if luz else "#4a4560"), (1, "#3a2414" if luz else "#1a1622")]))


def techo(lz, con_rayo):
    """Techo de paja con flecos; donde le pega el rayo se pone dorado."""
    m = poli([(262, 598), (350, 522), (610, 522), (698, 598), (680, 604), (280, 604)])
    flecos = np.zeros_like(LX)
    r = np.random.default_rng(3)
    for x in np.arange(266, 696, 5):
        flecos += linea(x, 598, x + r.uniform(-3, 3), 604 + r.uniform(2, 13), 2.4)
    m = np.clip(m + flecos, 0, 1)
    vetas = ruido((.5 * S, 6 * S), 13, 1)
    alto = np.clip((604 - LY) / 82, 0, 1)
    base = mezcla(alto, [(0, "#4a3218"), (.5, "#7b5426"), (1, "#a77a3c")])
    if con_rayo:
        d = np.abs(LX - ESTRELLA[0]) / 150
        oro = np.exp(-d ** 2 * 1.4) * (0.4 + .6 * alto)
        base = base * (1 - oro[..., None]) + mezcla(alto, [(0, "#d99a3a"), (1, "#fff0a8")]) * oro[..., None]
    else:
        base = base * np.array([.55, .58, .8], np.float32)
    lz.pintar(m, base * (1 + .2 * vetas[..., None]))
    lz.pintar(poli([(346, 524), (614, 524), (612, 530), (348, 530)]), (255, 236, 160) if con_rayo else (90, 90, 120), .9)


def figura(lz, m, color, luz, rim=0.0):
    """Pinta una figura: con luz, se ilumina más del lado del Niño; sin luz, queda en penumbra."""
    if luz:
        d = np.hypot(LX - MANTO[0], LY - MANTO[1])
        k = np.clip(1.15 - d / 280, .55, 1.08)
        col = color * k[..., None] if isinstance(color, np.ndarray) and color.ndim == 3 else np.asarray(color, np.float32) * k[..., None]
    else:
        base = color if isinstance(color, np.ndarray) and color.ndim == 3 else np.broadcast_to(np.asarray(color, np.float32), LX.shape + (3,))
        gris = base.mean(-1, keepdims=True)
        col = (base * .25 + gris * .15) * np.array([.7, .75, 1.2], np.float32)
    lz.pintar(m, col)
    lz.fig = np.maximum(lz.fig, m)
    lz.n += 1
    lz.parte[m > .5] = lz.n


def sagrada_familia(lz, luz):
    piel = hexa("#f2c9a2")
    # ── el burrito (atrás, a la izquierda) y el buey (atrás, a la derecha)
    figura(lz, poli([(352, 600), (360, 574), (366, 600)]), hexa("#7d7884"), luz)
    figura(lz, poli([(368, 602), (378, 576), (382, 604)]), hexa("#7d7884"), luz)
    figura(lz, elip(372, 622, 17, 22, -.35), mezcla((LX - 360) / 30, [(0, "#5c5866"), (1, "#a29ca8")]), luz)
    figura(lz, elip(382, 640, 11, 9, -.35), hexa("#cfc7c0"), luz)
    figura(lz, elip(372, 616, 2.2, 2.2), hexa("#14121a"), luz)
    figura(lz, elip(604, 624, 24, 18), mezcla((LX - 585) / 40, [(0, "#8a5a36"), (1, "#5a3a24")]), luz)
    figura(lz, elip(596, 638, 13, 9), hexa("#d9b393"), luz)
    for lado in (-1, 1):
        figura(lz, linea(604 + lado * 16, 610, 604 + lado * 30, 596, 3), hexa("#f4ead6"), luz)
    figura(lz, elip(594, 618, 2.2, 2.2), hexa("#14121a"), luz)
    # ── el pesebre (la cunita de madera) con paja
    figura(lz, linea(446, 746, 434, 770, 4), hexa("#5a3a1e"), luz)
    figura(lz, linea(514, 746, 526, 770, 4), hexa("#5a3a1e"), luz)
    caja = poli([(424, 716), (536, 716), (524, 750), (436, 750)])
    tabla = 1 - .25 * ((np.abs(((LY - 716) % 11) - 5.5) < .7))
    figura(lz, caja, mezcla((LX - 424) / 112, [(0, "#8a5a2c"), (.5, "#b07a40"), (1, "#7a4a22")]) * tabla[..., None], luz)
    r = np.random.default_rng(17)
    pajas = np.zeros_like(LX)
    for _ in range(70):
        x = r.uniform(422, 538)
        pajas += linea(x, 718, x + r.uniform(-8, 8), 706 + r.uniform(-4, 6), 1.3)
    figura(lz, np.clip(pajas, 0, 1), hexa("#ffd96a"), luz)
    # ── el Niño, envuelto en pañales
    nino = elip(488, 706, 30, 11)
    figura(lz, nino, mezcla((LY - 695) / 22, [(0, "#ffffff"), (1, "#e8dcc8")]), luz)
    for k in range(4):
        figura(lz, linea(474 + k * 10, 697, 470 + k * 10, 715, 1), hexa("#d9ccb6"), luz)
    figura(lz, elip(462, 703, 10, 10), mezcla((LX - 454) / 18, [(0, "#ffe2c8"), (1, "#f0b894")]), luz)
    figura(lz, elip(459, 698, 8.5, 5) * (LY < 699), hexa("#7a4a2a"), luz)          # pelito
    figura(lz, elip(472, 712, 4, 3), piel, luz)                                  # manita
    if luz:
        d = np.hypot(LX - 470, LY - 703)
        lz.luz(np.exp(-(d / 34) ** 2) * .45 + np.exp(-((d - 30) / 3) ** 2) * .35, (255, 226, 140))
    # ── María, de rodillas, mirando al Niño (mx: cuánto se recorre a la izquierda)
    mx = -30
    figura(lz, poli([(436 + mx, 668), (448 + mx, 700), (452 + mx, 766), (436 + mx, 766), (432 + mx, 712)]), hexa("#c0283d"), luz)   # túnica roja
    manto = poli([(400 + mx, 642), (432 + mx, 640), (444 + mx, 668), (452 + mx, 708), (456 + mx, 766), (366 + mx, 766),
                  (372 + mx, 726), (388 + mx, 680)])
    figura(lz, manto, mezcla((LX - 366 - mx) / 90, [(0, "#2350a6"), (.55, "#3f7ae0"), (1, "#9cc0f8")]), luz)
    for k in range(4):                                                                                        # pliegues
        figura(lz, linea(392 + mx + k * 12, 690, 382 + mx + k * 14, 764, 1.6), hexa("#20489a"), luz)
    figura(lz, elip(420 + mx, 650, 16, 18), mezcla((LX - 404 - mx) / 32, [(0, "#1d3f86"), (1, "#5a86d6")]), luz)   # velo azul
    figura(lz, elip(424 + mx, 652, 11.5, 13.5), hexa("#f4efe4"), luz)                                              # velo blanco
    figura(lz, elip(426 + mx, 654, 8, 10), mezcla((LX - 418 - mx) / 16, [(0, "#e6b48e"), (1, "#ffdcc0")]), luz)     # carita
    figura(lz, linea(428 + mx, 652, 431 + mx, 653, 1.2), hexa("#5a3a2a"), luz)                                    # ojito cerrado
    figura(lz, elip(446 + mx, 690, 6, 5.5), piel, luz)                                                           # manos juntas
    figura(lz, linea(443 + mx, 684, 447 + mx, 678, 2), piel, luz)
    # ── José, de pie con su bastón, inclinado hacia el Niño (jx: cuánto se recorre a la derecha)
    jx = 14
    figura(lz, linea(600 + jx, 606, 606 + jx, 768, 4), mezcla((LY - 600) / 160, [(0, "#a87a44"), (1, "#5a3a1e")]), luz)
    tunica = poli([(528 + jx, 640), (562 + jx, 638), (580 + jx, 700), (588 + jx, 766), (516 + jx, 766), (520 + jx, 700)])
    figura(lz, tunica, mezcla((LX - 516 - jx) / 72, [(0, "#d24a40"), (.5, "#a8322e"), (1, "#6e2024")]), luz)
    capa = poli([(524 + jx, 638), (568 + jx, 640), (592 + jx, 690), (576 + jx, 702), (552 + jx, 664), (532 + jx, 700), (516 + jx, 688)])
    figura(lz, capa, mezcla((LX - 516 - jx) / 76, [(0, "#e2a956"), (.6, "#a8722e"), (1, "#6e4618")]), luz)
    figura(lz, elip(544 + jx, 624, 12.5, 14.5), mezcla((LX - 532 - jx) / 25, [(0, "#ffd7b4"), (1, "#c98e6a")]), luz)
    figura(lz, elip(546 + jx, 615, 13.5, 8) * (LY < 618), hexa("#5a3a24"), luz)                                   # pelo
    figura(lz, poli([(534 + jx, 628), (556 + jx, 630), (552 + jx, 646), (544 + jx, 650), (536 + jx, 644)]), hexa("#6b4a30"), luz)  # barba
    figura(lz, linea(536 + jx, 623, 540 + jx, 624, 1.2), hexa("#3a2418"), luz)
    figura(lz, elip(598 + jx, 668, 5.5, 5), piel, luz)                                                           # mano en el bastón
    # ── un corderito echado frente al pesebre
    lana = np.zeros_like(LX)
    for k in range(9):
        lana += elip(598 + (k % 3) * 9, 744 + (k // 3) * 5, 8, 6)
    figura(lz, np.clip(lana, 0, 1), mezcla((LY - 736) / 20, [(0, "#ffffff"), (1, "#d8d0c6")]), luz)
    figura(lz, elip(626, 740, 7, 6), hexa("#f0e8de"), luz)
    figura(lz, elip(629, 739, 1.6, 1.6), hexa("#14121a"), luz)
    # ── la lámpara colgada del travesaño
    figura(lz, linea(346, 604, 346, 616, 1.2), hexa("#3a2a1a"), luz)
    figura(lz, poli([(339, 616), (353, 616), (351, 634), (341, 634)]), hexa("#ffd36a") if luz else hexa("#3a3550"), luz)
    if luz:
        d = np.hypot(LX - 346, LY - 626)
        lz.luz(np.exp(-(d / 30) ** 2) * .55, (255, 170, 60))


def pastor(lz):
    """Un pastor que se acerca con su cordero en hombros (bajo la luz azul de la noche)."""
    def figura_azul(m, c):
        m = np.clip(m, 0, 1)
        lz.pintar(m, hexa(c))
        lz.fig = np.maximum(lz.fig, m)
        lz.n += 1
        lz.parte[m > .5] = lz.n
    figura_azul(linea(808, 612, 816, 738, 3), "#6a5440")
    figura_azul(poli([(804, 604), (812, 600), (818, 606), (814, 614), (808, 612)]) - poli([(807, 605), (812, 603), (815, 607), (811, 610)]), "#6a5440")
    figura_azul(poli([(764, 650), (792, 648), (804, 700), (808, 738), (756, 738), (760, 700)]), "#4a5a86")
    figura_azul(poli([(762, 648), (794, 650), (806, 680), (784, 676), (770, 690)]), "#8a7656")
    figura_azul(elip(780, 636, 10, 12), "#b99a86")
    figura_azul(elip(780, 628, 12, 9) * (LY < 632), "#6e5a48")
    lana = np.zeros_like(LX)
    for k in range(5):
        lana += elip(768 + k * 6, 646 - (k % 2) * 3, 6, 5)
    figura_azul(np.clip(lana, 0, 1), "#d8dcef")
    for cx, cy in ((724, 734), (852, 740), (884, 732)):
        lana = np.zeros_like(LX)
        for k in range(6):
            lana += elip(cx + (k % 3) * 8, cy + (k // 3) * 5, 8, 6)
        figura_azul(np.clip(lana, 0, 1), "#c9cfe6")
        figura_azul(elip(cx - 8, cy - 2, 6, 5), "#9aa2c4")
        for p in (0, 16):
            figura_azul(linea(cx + p, cy + 8, cx + p, cy + 16, 2), "#2a2e48")


def frente(lz, luz):
    """Suelo, muretes de piedra y la luz del pesebre derramándose hacia nosotros."""
    suelo = (LY >= 762).astype(np.float32)
    col = mezcla((LY - 762) / 54, [(0, "#1b2448"), (1, "#0f1530")])
    lz.pintar(suelo, col * (1 + .1 * ruido((1 * S, 8 * S), 19, 1)[..., None]))
    if luz:
        d = np.hypot((LX - 480) / 1.9, (LY - 762) / .9)
        lz.luz(np.exp(-(d / 95) ** 2) * suelo * .42, (255, 156, 52))
        r0 = np.random.default_rng(29)
        pajas = np.zeros_like(LX)
        for _ in range(60):                                   # paja regada frente al pesebre
            x, y = r0.normal(480, 70), r0.uniform(766, 800)
            pajas += linea(x, y, x + r0.uniform(-9, 9), y + r0.uniform(-2, 2), 1)
        lz.pintar(np.clip(pajas, 0, 1), (236, 186, 92), .8)
    r = np.random.default_rng(23)
    for x0, x1 in ((-10, 300), (664, 970)):
        x = x0
        fila = 0
        while x < x1:
            w = r.uniform(34, 60)
            for yb, alto in ((790, 26), (816, 26), (842, 26)):
                dx = 0 if (fila + (yb == 816)) % 2 == 0 else w / 2
                m = elip(x + dx + w / 2, yb - alto / 2, w / 2 - 2, alto / 2 - 2)
                tope = np.clip((yb - alto / 2 - LY) / (alto / 2), -1, 1)
                c = mezcla(tope, [(-1, "#141a34"), (0, "#2c3a6e"), (.7, "#6f88cf"), (1, "#9fb4ee")])
                if luz:
                    cerca = np.exp(-(np.abs(LX - 480) / 260) ** 2)
                    c = c * (1 - .5 * cerca[..., None]) + (c * np.array([1.6, 1.2, .55])) * .5 * cerca[..., None]
                lz.pintar(m, c * (1 + .08 * ruido((1.5 * S, 1.5 * S), int(x), 1)[..., None]))
            x += w
            fila += 1
    for _ in range(40):
        x = r.uniform(0, W)
        if 300 < x < 664:
            continue
        for k in range(4):
            lz.pintar(linea(x + k * 2, 764, x + k * 3 - 3, 748 - r.uniform(0, 8), 1.2), (52, 82, 96))


# ═════════════════════════ de cerca: la Sagrada Familia ═════════════════════════
BEBE = (404.0, 786.0)                 # la carita del Niño en el primer plano


def pieza(lz, m, color, alfa=1.0):
    """Una pieza de figura (cuenta como figura: se dibuja sólida)."""
    m = np.clip(m, 0, 1)
    lz.pintar(m, color, alfa)
    lz.fig = np.maximum(lz.fig, m * alfa)
    lz.n += 1
    lz.parte[m > .5] = lz.n


def lado_luz(x0, x1):
    """0 en x0 (sombra) a 1 en x1 (del lado del Niño)."""
    return np.clip((LX - x0) / (x1 - x0), 0, 1)


def pared_cerca(lz):
    """Pared de piedra del fondo: piedras irregulares, cálidas cerca del Niño y azul noche en las orillas."""
    d = np.hypot((LX - 470) / 1.1, (LY - 760) / .9)
    col = mezcla(d / 700 + .04 * ruido((6 * S, 6 * S), 2, 1), [(0, "#ffe7a8"), (.1, "#ffcd72"), (.26, "#ec9e48"), (.44, "#b8682e"),
                                                                (.6, "#78402a"), (.75, "#40263a"), (.88, "#1e1a40"), (1, "#0e0f2a")])
    alto_fila = 62
    fila = np.floor((LY + 12 * np.sin(LX / 140)) / alto_fila)
    yy = ((LY + 12 * np.sin(LX / 140)) % alto_fila) / alto_fila
    off = (fila * 47) % 97
    ancho = 97
    xx = ((LX + off + 10 * np.sin(LY / 50)) % ancho) / ancho
    ide = (np.floor((LX + off) / ancho) * 7.31 + fila * 3.17) % 1
    bulto = np.clip(1 - ((xx - .5) / .55) ** 2 - ((yy - .45) / .6) ** 2, 0, 1)    # cada piedra, abombadita
    junta = np.clip(1 - np.minimum(np.minimum(xx, 1 - xx) / .05, np.minimum(yy, 1 - yy) / .08), 0, 1)
    tono = (.86 + (ide - .5) * .18 + .2 * bulto) * (1 - .45 * junta)
    lz.pintar(np.ones_like(LX), col * tono[..., None])
    lz.fondo = np.ones_like(LX)


def techo_cerca(lz):
    """Arriba: la paja del techo con un hueco por donde se ven la noche, la estrella y baja la luz."""
    hueco = elip(480, 30, 175, 128)
    cielo_ = mezcla(LY / 160 + .06 * ruido((5 * S, 20 * S), 1, 1), [(0, "#060b22"), (.6, "#0f1d4c"), (1, "#22397e")])
    borde_paja = 214 + 10 * np.sin(LX / 37) + 6 * np.sin(LX / 11)
    paja_m = np.clip((LY < borde_paja).astype(np.float32) - hueco, 0, 1)
    vetas = ruido((.6 * S, 9 * S), 13, 1)
    calor = np.exp(-((LX - 480) / 300) ** 2) * np.clip((LY - 30) / 180, 0, 1)
    paja = mezcla(calor + .12 * vetas, [(0, "#120e1e"), (.3, "#33242a"), (.6, "#7a4e28"), (.85, "#c88a3c"), (1.1, "#ffd27a")])
    lz.pintar(hueco, cielo_)
    r = np.random.default_rng(31)
    for _ in range(26):                                # estrellitas en el hueco
        x, y = r.uniform(330, 630), r.uniform(-20, 140)
        lz.pintar(elip(x, y, 2.2, 2.2) * hueco, (230, 236, 255), r.uniform(.5, 1))
    cx, cy = 480, 60                                   # la estrella, asomándose
    d = np.hypot(LX - cx, LY - cy)
    lz.luz(np.exp(-(d / 70) ** 2) * hueco * .9, (170, 190, 255))
    for k in range(8):
        a = k * math.pi / 4 - math.pi / 2
        largo = 38 if k % 2 == 0 else 20
        if k == 4:
            largo = 52
        ancho = 6 if k % 2 == 0 else 4
        pa = (cx + math.cos(a + math.pi / 2) * ancho, cy + math.sin(a + math.pi / 2) * ancho)
        pb = (cx - math.cos(a + math.pi / 2) * ancho, cy - math.sin(a + math.pi / 2) * ancho)
        lz.pintar(poli([pa, (cx + math.cos(a) * largo, cy + math.sin(a) * largo), pb]) * hueco,
                  mezcla(d / largo, [(0, "#ffffff"), (.5, "#fff3c0"), (1, "#ffc94a")]))
    lz.pintar(paja_m, paja * (1 + .18 * vetas[..., None]))
    flecos = np.zeros_like(LX)
    for x in np.arange(-10, 980, 7):
        if abs(x - 480) < 160:
            continue
        flecos += linea(x, borde_paja[0, min(int(x * S), W * S - 1) if x >= 0 else 0] - 4, x + r.uniform(-5, 5), 236 + r.uniform(0, 18), 3)
    lz.pintar(np.clip(flecos, 0, 1), mezcla(calor + .1, [(0, "#2a1e22"), (.5, "#8a5a2c"), (1, "#e8a84a")]))
    viga = poli([(-10, 238), (970, 238), (970, 268), (-10, 268)])
    lz.pintar(viga, mezcla((LY - 238) / 30 + .15 * vetas, [(0, "#22161a"), (.6, "#5e3c24"), (1, "#b8783a")]))
    for x0 in (20, 902):
        lz.pintar(poli([(x0, 262), (x0 + 38, 262), (x0 + 40, 1130), (x0 - 2, 1130)]),
                  mezcla(lado_luz(x0, x0 + 38) if x0 < 400 else 1 - lado_luz(x0, x0 + 38), [(0, "#120e1c"), (1, "#6a4028")])
                  * (1 + .1 * ruido((.6 * S, 10 * S), 11, 1)[..., None]))


def luz_que_baja(lz, fuerza=1.0):
    ancho = 80 + (LY - 60) * .28
    d = np.abs(LX - 478 + (LY - 60) * .03) / ancho
    cono = np.clip(1 - d, 0, 1) ** 1.5 * np.clip((LY - 60) / 70, 0, 1) * np.clip((900 - LY) / 140, 0, 1)
    vetas = .72 + .28 * ruido((40 * S, 3 * S), 5, 1)
    lz.luz(cono * vetas * .5 * fuerza, mezcla(LY / 800, [(0, "#dfe8ff"), (.5, "#fff3cc"), (1, "#ffd870")]) * .62)


def burrito_cerca(lz):
    ll = lado_luz(110, 320)
    gris = mezcla(ll + .06 * ruido((4 * S, 4 * S), 3, 1), [(0, "#1a1828"), (.35, "#46425a"), (.7, "#8c8494"), (1, "#cfc2bc")])
    pieza(lz, poli([(-10, 520), (60, 470), (150, 470), (180, 560), (120, 640), (-10, 660)]), gris)            # cuello
    crin = np.zeros_like(LX)
    for k in range(9):
        x = 20 + k * 15
        crin += elip(x, 478 - k * 3, 10, 16, .4)
    pieza(lz, np.clip(crin, 0, 1), mezcla(ll, [(0, "#100e18"), (1, "#3a3040")]))
    for ox, ang in ((140, -.22), (196, .1)):                                                                  # orejas
        pieza(lz, elip(ox, 352, 21, 64, ang), gris)
        pieza(lz, elip(ox + 2, 362, 11, 44, ang), mezcla(ll, [(0, "#2a2032"), (1, "#8a6a70")]))
        pieza(lz, elip(ox + (ang * 60), 300, 9, 12, ang), (30, 26, 38))                                        # puntitas
    pieza(lz, elip(210, 470, 80, 54, .5), gris)                                                                # cabeza
    pieza(lz, elip(282, 534, 46, 38, .48), mezcla(lado_luz(236, 330), [(0, "#6a6060"), (1, "#f2e6d8")]))      # hocico
    pieza(lz, elip(302, 542, 8, 6, .4), (40, 30, 34))
    pieza(lz, elip(216, 448, 15, 10, .3), (22, 18, 26))                                                        # ojo
    pieza(lz, elip(221, 444, 4.5, 3.2), (240, 232, 220))
    pieza(lz, linea(200, 436, 234, 438, 3), (24, 20, 30))


def buey_cerca(lz):
    ll = 1 - lado_luz(760, 960)
    cafe = mezcla(ll + .06 * ruido((4 * S, 4 * S), 4, 1), [(0, "#1a0e0c"), (.35, "#46291a"), (.7, "#8a5634"), (1, "#c98a52")])
    pieza(lz, poli([(980, 450), (930, 420), (880, 500), (880, 640), (980, 660)]), cafe)                      # cuello
    for sx in (-1, 1):                                                                                        # cuernos
        x0 = 868 + sx * 50
        pts = [(x0, 404), (x0 + sx * 30, 386), (x0 + sx * 46, 352), (x0 + sx * 46, 322), (x0 + sx * 36, 346),
               (x0 + sx * 20, 372), (x0 - sx * 4, 390)]
        pieza(lz, poli(pts), mezcla(1 - lado_luz(800, 940), [(0, "#7a6a50"), (1, "#fbf2dc")]))
        pieza(lz, elip(x0 + sx * 22, 424, 24, 10, sx * .35), cafe)                                              # orejas
    pieza(lz, elip(868, 452, 64, 58), cafe)                                                                    # cabeza
    pieza(lz, elip(842, 520, 50, 34, -.2), mezcla(1 - lado_luz(800, 900), [(0, "#6a4a40"), (1, "#f4cdb6")]))  # hocico
    for dx in (-18, 16):
        pieza(lz, elip(838 + dx, 530, 7.5, 5.5), (50, 26, 24))
    pieza(lz, elip(838, 440, 13, 9, -.3), (20, 12, 10))                                                       # ojo
    pieza(lz, elip(834, 437, 4, 3), (240, 226, 210))
    pieza(lz, elip(870, 410, 28, 12), mezcla(ll, [(0, "#2a1810"), (1, "#a86a40")]))                           # mechón


def jose_cerca(lz):
    piel = lambda x0, x1: mezcla(1 - lado_luz(x0, x1), [(0, "#7a4a38"), (.5, "#d79c76"), (1, "#ffd8b8")])  # noqa: E731
    # bastón
    pieza(lz, linea(780, 330, 796, 1130, 10), mezcla((LY - 330) / 800, [(0, "#c8985a"), (1, "#4a2e18")]))
    pieza(lz, elip(780, 330, 12, 10), (200, 152, 92))
    # túnica café (de pie, un poquito inclinado hacia el Niño)
    tunica = poli([(590, 482), (722, 478), (748, 640), (782, 1130), (548, 1130), (566, 760)])
    pieza(lz, tunica, mezcla(1 - lado_luz(560, 780) + .05 * ruido((6 * S, 2 * S), 6, 1),
                             [(0, "#140a0c"), (.35, "#3e2016"), (.65, "#7a4422"), (1, "#c07a3a")]))
    for k in range(4):                                                                                        # pliegues
        pieza(lz, linea(610 + k * 40, 720, 590 + k * 50, 1130, 3), (34, 18, 12), .55)
    # manto ocre cruzado
    manto = poli([(588, 478), (690, 480), (730, 560), (690, 690), (640, 860), (586, 900), (566, 760), (578, 600)])
    pieza(lz, manto, mezcla(1 - lado_luz(560, 740) + .05 * ruido((5 * S, 2 * S), 7, 1),
                            [(0, "#341608"), (.3, "#86381a"), (.65, "#d27432"), (1, "#ffbc62")]))
    pieza(lz, linea(604, 530, 664, 846, 3), (110, 44, 20), .7)
    # brazo hacia el bastón
    pieza(lz, poli([(690, 486), (730, 500), (790, 610), (774, 636), (712, 560)]),
          mezcla(1 - lado_luz(690, 790), [(0, "#24120e"), (1, "#a85a2a")]))
    pieza(lz, elip(784, 616, 18, 15, .4), piel(766, 804))
    # mano en el pecho
    pieza(lz, poli([(586, 486), (624, 504), (628, 574), (592, 582)]), mezcla(lado_luz(580, 630), [(0, "#ffbc62"), (1, "#86381a")]))
    pieza(lz, elip(612, 576, 24, 16, -.5), piel(590, 636))
    # cuello y cabeza (inclinada hacia el Niño)
    pieza(lz, poli([(618, 448), (664, 446), (668, 486), (614, 488)]), piel(610, 680))
    pieza(lz, elip(652, 398, 48, 58, .22), mezcla(lado_luz(600, 704), [(0, "#20140c"), (1, "#4e321e")]))     # pelo (atrás)
    pieza(lz, elip(634, 406, 40, 50, .22), piel(596, 676))                                                     # cara
    pieza(lz, elip(650, 356, 46, 22, .2) * (LY < 366), mezcla(lado_luz(600, 696), [(0, "#2e1c10"), (1, "#6e4a2c")]))  # cabello
    barba = poli([(596, 410), (604, 438), (618, 460), (638, 470), (662, 460), (676, 434), (678, 408), (662, 424), (640, 430), (614, 424)])
    pieza(lz, barba, mezcla(lado_luz(596, 680) + .1 * ruido((1.5 * S, 1.5 * S), 8, 1), [(0, "#3e2818"), (.6, "#6e5038"), (1, "#a08a76")]))
    pieza(lz, linea(620, 442, 644, 444, 3.2), (110, 56, 44), .9)                                               # sonrisa
    for x0 in (614, 650):                                                                                      # ojos mirando abajo
        pieza(lz, linea(x0 - 10, 398, x0 + 10, 402, 3.4), (46, 26, 20))
        pieza(lz, linea(x0 - 11, 385, x0 + 10, 383, 4), (60, 38, 24))                                           # cejas


def maria_cerca(lz):
    piel = lambda x0, x1: mezcla(lado_luz(x0, x1), [(0, "#9a6650"), (.5, "#e6ad8a"), (1, "#ffe2cc")])  # noqa: E731
    azul = lambda x0, x1: mezcla(lado_luz(x0, x1) + .04 * ruido((6 * S, 2 * S), 9, 1),  # noqa: E731
                                 [(0, "#070d2a"), (.25, "#122664"), (.5, "#1d42a2"), (.72, "#3870d8"), (.9, "#78a8f6"), (1.05, "#c8deff")])
    # manto azul: cubre la cabeza y cae hasta el piso (de rodillas, mirando al Niño)
    manto = poli([(300, 452), (338, 392), (398, 368), (444, 392), (462, 452), (452, 520), (470, 600), (486, 720),
                  (506, 880), (530, 1130), (96, 1130), (150, 900), (214, 700), (262, 560)])
    pieza(lz, manto, azul(150, 500))
    for x0, y0, x1, y1 in ((296, 560, 236, 1130), (344, 610, 326, 1130), (392, 660, 414, 1130), (248, 620, 160, 1100)):
        pieza(lz, linea(x0, y0, x1, y1, 3.4), mezcla(lado_luz(150, 500), [(0, "#040820"), (1, "#22489e")]), .7)
    pieza(lz, linea(470, 600, 506, 1130, 3), (200, 225, 255), .45)                                            # filo de luz
    # velo blanco bajo el manto, enmarcando la cara
    velo = poli([(370, 400), (420, 388), (452, 420), (458, 486), (440, 530), (400, 528)])
    pieza(lz, velo, mezcla(lado_luz(370, 458), [(0, "#7a7894"), (.5, "#dcd4d0"), (1, "#fffaf2")]))
    # túnica rosa (se asoma entre el manto, en el pecho)
    pieza(lz, poli([(440, 520), (470, 540), (478, 640), (452, 660)]), mezcla(lado_luz(440, 480), [(0, "#5a1222"), (.6, "#c0384e"), (1, "#ff8a8a")]))
    # cara (de perfil, mirando al Niño)
    cara = elip(422, 460, 27, 35, -.4)
    pieza(lz, cara, piel(396, 450))
    pieza(lz, elip(436, 478, 9, 6, -.3), (240, 130, 120), .6)                                                  # chapita
    pieza(lz, linea(418, 452, 438, 459, 3.2), (80, 44, 40))                                                    # ojo cerrado
    pieza(lz, linea(414, 440, 438, 445, 3), (110, 70, 50), .85)                                                # ceja
    pieza(lz, linea(436, 486, 446, 487, 3), (176, 70, 74), .95)                                                # sonrisa
    # manos juntas, orando
    pieza(lz, poli([(410, 600), (466, 566), (490, 606), (440, 646)]), azul(410, 490))
    pieza(lz, elip(486, 576, 13, 28, .45), piel(470, 500))
    pieza(lz, elip(497, 580, 11, 25, .45), piel(482, 510))
    d = np.hypot(LX - 470, LY - 560)
    lz.luz(np.exp(-(d / 120) ** 2) * cara * .25, (255, 200, 140))
    # aureola suave
    anillo_ = np.abs(np.hypot(LX - 408, LY - 440) - 74) < 2.6
    lz.pintar(anillo_.astype(np.float32) * (1 - cara) * (1 - velo), (255, 214, 120), .6)


def pesebre_cerca(lz):
    madera = lambda t: mezcla(t, [(0, "#2a160c"), (.4, "#6a3e1e"), (.75, "#b07438"), (1, "#e8a84e")])  # noqa: E731
    for x0, x1 in ((330, 280), (360, 410), (630, 680), (600, 550)):                                         # patas en X
        pieza(lz, linea(x0, 880, x1, 1080, 14), madera(.5 + .3 * (x0 < 480)))
    caja = poli([(296, 800), (664, 800), (636, 900), (324, 900)])
    tablas = 1 - .3 * (np.abs(((LY - 800) % 33) - 16.5) < 1.4)
    pieza(lz, caja, madera(1 - np.abs(LX - 480) / 260 + .08 * ruido((.8 * S, 8 * S), 10, 1)) * tablas[..., None])
    r = np.random.default_rng(17)
    pajas = np.zeros_like(LX)
    for _ in range(170):
        x = r.uniform(290, 670)
        y = r.uniform(784, 812)
        pajas += linea(x, y, x + r.uniform(-16, 16), y - r.uniform(-6, 22), 1.6)
    pieza(lz, np.clip(pajas, 0, 1), mezcla(1 - np.abs(LX - 480) / 260, [(0, "#b8802a"), (1, "#ffe08a")]))
    # el Niño, envuelto en pañales
    cuerpo = elip(512, 786, 118, 36, -.02)
    pieza(lz, cuerpo, mezcla((LY - 752) / 72, [(0, "#ffffff"), (.6, "#f6eedd"), (1, "#d8c6a8")]))
    for k in range(5):
        pieza(lz, linea(450 + k * 40, 756, 432 + k * 40, 818, 3), (214, 196, 168), .8)
    pieza(lz, elip(448, 770, 14, 11), mezcla(lado_luz(436, 462), [(0, "#e8b896"), (1, "#ffe6d4")]))          # manita
    bebe = elip(BEBE[0], BEBE[1], 38, 35)
    pieza(lz, bebe, mezcla(np.hypot(LX - 410, LY - 778) / 40, [(0, "#fff0e2"), (.6, "#ffd8bc"), (1, "#e8a888")]))
    pieza(lz, elip(398, 760, 30, 15) * (LY < 764), mezcla(lado_luz(370, 430), [(0, "#7a4a2a"), (1, "#b07a4a")]))   # pelito
    for x0 in (390, 418):                                                                                       # ojitos dormidos
        pieza(lz, linea(x0 - 8, 786, x0 + 8, 787, 3.2), (110, 60, 52))
    for x0 in (384, 426):
        pieza(lz, elip(x0, 798, 7, 4.5), (250, 150, 150), .6)                                                   # cachetitos
    pieza(lz, linea(398, 805, 410, 805, 3), (196, 86, 90), .95)                                                 # boquita
    # su luz
    d = np.hypot(LX - BEBE[0], LY - BEBE[1])
    lz.luz(np.exp(-(d / 70) ** 2) * .55 + np.exp(-((d - 58) / 3.5) ** 2) * .5, (255, 226, 150))


def piso_cerca(lz):
    piso = (LY >= 1030).astype(np.float32)
    d = np.hypot((LX - 480) / 1.6, (LY - 1030) / .7)
    lz.pintar(piso, mezcla(d / 420, [(0, "#ffd77a"), (.4, "#c0802e"), (.75, "#4a2a20"), (1, "#151228")]))
    r = np.random.default_rng(29)
    pajas = np.zeros_like(LX)
    for _ in range(220):
        x, y = r.uniform(0, 960), r.uniform(1030, 1120)
        pajas += linea(x, y, x + r.uniform(-20, 20), y + r.uniform(-4, 4), 1.4)
    lz.pintar(np.clip(pajas, 0, 1) * piso, mezcla(d / 420, [(0, "#fff0a8"), (.5, "#d09a40"), (1, "#3a2a2a")]), .8)


def cordero_cerca(lz):
    lana = np.zeros_like(LX)
    for k in range(12):
        lana += elip(690 + (k % 4) * 24, 1040 + (k // 4) * 16 - (k % 2) * 6, 22, 16)
    pieza(lz, np.clip(lana, 0, 1), mezcla(1 - lado_luz(680, 780) + .08 * ruido((3 * S, 3 * S), 12, 1),
                                         [(0, "#6a6070"), (.5, "#d8ccc0"), (1, "#fffaf0")]))
    pieza(lz, elip(668, 1034, 22, 18, -.2), mezcla(1 - lado_luz(650, 690), [(0, "#b0a49a"), (1, "#fff6ea")]))
    pieza(lz, elip(650, 1022, 10, 6, -.6), (210, 190, 180))                                                    # orejita
    pieza(lz, linea(656, 1034, 666, 1036, 2.2), (40, 30, 34))                                                  # ojo dormido


def farolito(lz):
    pieza(lz, linea(870, 244, 870, 290, 2), (40, 30, 24))
    pieza(lz, poli([(852, 290), (888, 290), (884, 336), (856, 336)]), (255, 210, 110))
    pieza(lz, poli([(848, 282), (892, 282), (888, 292), (852, 292)]), (60, 40, 30))
    d = np.hypot(LX - 870, LY - 314)
    lz.luz(np.exp(-(d / 60) ** 2) * .6, (255, 170, 70))


def escena_cerca():
    lz = Lienzo()
    transformar()
    pared_cerca(lz)
    techo_cerca(lz)
    farolito(lz)
    luz_que_baja(lz)
    burrito_cerca(lz)
    buey_cerca(lz)
    piso_cerca(lz)
    jose_cerca(lz)
    maria_cerca(lz)
    pesebre_cerca(lz)
    cordero_cerca(lz)
    luz_que_baja(lz, .35)
    lz.rgb *= (1 - .55 * np.clip(np.hypot((XX - 480) / 560, (YY - 700) / 620) - .55, 0, 1) * 2.2)[..., None]
    return lz.final()


def escena(con_estrella=True, con_rayo=True, con_luz=True, con_estrellitas=True):
    lz = Lienzo()
    transformar()
    cielo(lz)
    if con_estrellitas:
        estrellitas(lz)
    if con_estrella:
        estrella(lz)
    transformar(0, DY_PUEBLO, 1)
    r1, r2 = colinas(lz)
    pueblo(lz, r1, r2)
    transformar(*O_PASTOR, K_PASTOR)
    pastor(lz)
    transformar()
    if con_rayo:
        rayo(lz)
    transformar(*O_ESTABLO, K_ESTABLO)
    establo(lz, con_luz)
    techo(lz, con_rayo)
    sagrada_familia(lz, con_luz)
    frente(lz, con_luz)
    transformar()
    return lz.final()


# ═════════════════════════ de pintura a letras ═════════════════════════
RAMPA = np.array(list(" .:-=+*#%@"))
UMBRAL_CODIGO = .42


def contornos(parte):
    """Donde se tocan dos piezas (manto y cara, Niño y paja...), un trazo: / \\ | _ -"""
    der = (parte[:, 1:] != parte[:, :-1]) & ((parte[:, 1:] > 0) | (parte[:, :-1] > 0))
    aba = (parte[1:, :] != parte[:-1, :]) & ((parte[1:, :] > 0) | (parte[:-1, :] > 0))
    e = np.zeros(parte.shape, bool)
    e[:, :-1] |= der
    e[:-1, :] |= aba
    out = np.full((FILAS, COLS), "", dtype="<U1")
    for f in range(FILAS):
        for c in range(COLS):
            bloque = e[f * CH:(f + 1) * CH, c * CW:(c + 1) * CW]
            n = int(bloque.sum())
            if n < 4:
                continue
            ys, xs = np.nonzero(bloque)
            if n > CW * CH * .55:
                continue
            xs = xs - xs.mean()
            ys = ys.astype(float)
            ym = ys.mean()
            ys = ys - ym
            cov = np.array([[np.mean(xs * xs), np.mean(xs * ys)], [np.mean(xs * ys), np.mean(ys * ys)]])
            val, vec = np.linalg.eigh(cov)
            vx, vy = vec[:, 1]
            if val[1] < 1.2 * val[0] + .2:                  # un puntito o una esquina: sin trazo
                continue
            th = math.degrees(math.atan2(-vy, vx)) % 180
            if th < 22 or th > 158:
                out[f, c] = "_" if ym > CH * .62 else "-"
            elif th < 68:
                out[f, c] = "/"
            elif th < 112:
                out[f, c] = "|"
            else:
                out[f, c] = "\\"
    return out


PROGRAMA = """// noche_de_paz.js · Belén de Judá, hace poco más de dos mil años
const cielo = new Noche({ tono: "azul profundo", silencio: true, frio: true });
const belen = pueblo("Belén", { tamaño: "pequeñito", importancia: "la más grande" });
let meson = { cuartos: 0 }; // no había lugar para ellos en el mesón (Lc 2,7)
const jose = new Carpintero("José", { de: "Nazaret", manos: "callosas", corazon: "justo" });
const maria = new Madre("María", { fe: Infinity, respuesta: "hágase" }); // Lc 1,38
jose.caminar(maria, { desde: "Nazaret", hasta: "Belén", prisa: false });
const pesebre = establo.buscar("un rincón tibio entre la paja");
await tiempo.cumplirse(); // y se cumplieron los días (Lc 2,6)
const nino = maria.darALuz({ envuelto: "en pañales", cuna: pesebre });
nino.nombre = "Jesús"; // porque él salvará a su pueblo (Mt 1,21)
const Emanuel = "Dios con nosotros"; // Mt 1,23
estrella.encender({ sobre: pesebre, para: "todos los pueblos" });
ejercitoCelestial.cantar("Gloria a Dios en las alturas, y en la tierra paz"); // Lc 2,13-14
pastores.dejar(rebaño).irDePrisa(pesebre); // Lc 2,16
maria.guardar(todo, { en: "su corazón" }); // Lc 2,19
if (mundo.oscuro) { luz.brillar(); } // la luz brilla en las tinieblas (Jn 1,5)
while (noche.santa) { amor.hacerseCarne(); paz.repartir(); esperanza++; }
for (const corazon of tierra) { corazon.abrirPuerta(nino); }
export default { gloria: Dios, paz: "a los hombres de buena voluntad" };
"""

# Dentro de cada figura, el código dice quién es (de cerca se lee)
NOMBRES = {
    "nino": ("Jesús·Emanuel·", (452, 690, 520, 718)),
    "maria": ("María·", (330, 630, 430, 768)),
    "jose": ("José·", (526, 600, 622, 768)),
    "burro": ("burrito·", (348, 570, 398, 652)),
    "buey": ("buey·", (576, 592, 636, 650)),
    "cordero": ("cordero·", (586, 732, 638, 762)),
}


def _corrido():
    lineas = [l.strip() for l in PROGRAMA.strip().splitlines()]
    flujo = "  ".join(lineas) + "  "
    return flujo


def a_letras(img, fig, fondo, parte):
    """Cada celda se vuelve una letra con el color del cuadro: la luz se dibuja con símbolos densos
    (@ % # * +) y la penumbra y la noche son puro código que cuenta la historia."""
    cel = img.reshape(FILAS, CH, COLS, CW, 3).mean((1, 3))
    cob = fig.reshape(FILAS, CH, COLS, CW).mean((1, 3))
    flujo = _corrido()
    n = len(flujo)
    codigo = np.array([[flujo[(f * COLS + c + f * 37) % n] for c in range(COLS)] for f in range(FILAS)], dtype="<U1")
    V = cel.max(-1) / 255
    k = np.clip((V ** 1.05) * 10.6, 0, 9).astype(int)
    en_fig = cob > .45
    k[en_fig] = np.clip(k[en_fig] + 2, 5, 9)                 # las figuras, sólidas
    chars = RAMPA[k].astype("<U1")
    noche = (V < UMBRAL_CODIGO) & ~en_fig
    chars = np.where(noche, codigo, chars)
    col = np.minimum(255, cel * (1.04 + .6 * np.clip(1 - V / .45, 0, 1))[..., None])   # solo se aclara lo oscuro
    chars = np.where((V < .02) | (chars == " "), " ", chars)
    return chars, col


def hexq(rgb, paso=10):
    q = [min(255, int(round(v / paso) * paso)) for v in rgb]
    return "#%02x%02x%02x" % tuple(q)


def texto(celdas, extra=""):
    """Un <text> por color, con posiciones x/y por carácter."""
    grupos = {}
    for f, c, ch, rgb in celdas:
        grupos.setdefault(hexq(rgb), []).append((c, f, ch))
    out = []
    for color, lst in grupos.items():
        xs = " ".join(str(c * CW) for c, _, _ in lst)
        ys = " ".join(str(f * CH + 6) for _, f, _ in lst)
        t = "".join(ch for _, _, ch in lst).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        out.append(f'<text fill="{color}" x="{xs}" y="{ys}"{extra}>{t}</text>')
    return "".join(out)


def jpg_uri(img, ancho, oscurece):
    from io import BytesIO
    im = Image.fromarray(np.clip(img * oscurece, 0, 255).astype(np.uint8)).resize((ancho, int(ancho * H / W)), Image.LANCZOS)
    b = BytesIO()
    im.save(b, "JPEG", quality=70)
    return "data:image/jpeg;base64," + base64.b64encode(b.getvalue()).decode()


def fuente_css():
    """JetBrains Mono recortada a los caracteres que se usan (pesa poquito)."""
    from io import BytesIO
    from fontTools import subset
    from fontTools.ttLib import TTFont
    f = TTFont(FUENTE)
    texto_usado = "".join(chr(i) for i in range(32, 127)) + "áéíóúÁÉÍÓÚñÑ¿¡·—♥"
    sub = subset.Subsetter()
    sub.populate(text=texto_usado)
    sub.subset(f)
    f.flavor = "woff2"
    b = BytesIO()
    f.save(b)
    return ("@font-face{font-family:'JB';src:url(data:font/woff2;base64," + base64.b64encode(b.getvalue()).decode()
            + ") format('woff2')}text{font-family:'JB','JetBrains Mono',Menlo,Consolas,monospace;white-space:pre}")


# ═════════════════════════ la animación (la historia) ═════════════════════════
T_ESCANEO = 1.4                      # la pantalla "dibuja" la noche
T_ESTRELLA = 1.9                     # aparece la estrella
T_RAYO, D_RAYO = 3.0, 2.0            # baja su luz
T_LUZ, D_LUZ = 5.2, 1.6              # se ilumina el pesebre
T_VIVO = 7.0                         # y todo sigue vivo: destellos, versículos...
EVENTOS = [0.0, T_ESTRELLA, T_RAYO, T_LUZ]
BANDA = 70                           # franja de abajo con los versículos
VERSOS = [
    ("Y la Palabra se hizo carne, y habitó entre nosotros.", "Juan 1, 14"),
    ("Hoy les ha nacido un Salvador, que es el Mesías, el Señor.", "Lucas 2, 11"),
    ("Gloria a Dios en el cielo, y en la tierra paz a los hombres.", "Lucas 2, 14"),
]
COMENTARIO = "# aquí, donde Dios se hizo hombre y la estrella alumbró el lugar"
NINO = G(472.0, 703.0)


def igual(a, b):
    return a[0] == b[0] and float(np.abs(a[1] - b[1]).sum()) < 30


def construir():
    cache = Path(f"/tmp/nacimiento_cache_{S}.npz")
    if os.environ.get("NAC_CACHE") and cache.exists():           # para afinar las letras sin repintar
        z = np.load(cache)
        todos = [tuple(z[f"e{i}_{j}"] for j in range(4)) for i in range(5)]
    else:
        todos = [escena(False, False, False), escena(True, False, False), escena(True, True, False), escena(True, True, True),
                 escena(True, True, True, con_estrellitas=False)]
        np.savez_compressed(cache, **{f"e{i}_{j}": a for i, e in enumerate(todos) for j, a in enumerate(e)})
    estados, sin_estrellitas = todos[:4], todos[4]
    cache_c = Path(f"/tmp/nacimiento_cerca_{S}.npz")
    if os.environ.get("NAC_CACHE") and cache_c.exists() and not os.environ.get("NAC_CERCA"):
        z = np.load(cache_c)
        cerca = tuple(z[f"c{j}"] for j in range(4))
    else:
        cerca = escena_cerca()
        np.savez_compressed(cache_c, **{f"c{j}": a for j, a in enumerate(cerca)})
    letras = [a_letras(*e) for e in estados]
    letras_ns = a_letras(*sin_estrellitas)
    grupos, titilan = {}, {0: [], 1: [], 2: []}
    for f in range(FILAS):
        for c in range(COLS):
            st = [(L[0][f, c], L[1][f, c]) for L in letras]
            inicio, segs = 0, []
            for e in (1, 2, 3):
                if not igual(st[e], st[e - 1]):
                    segs.append((inicio, e, st[e - 1]))
                    inicio = e
            segs.append((inicio, 4, st[3]))
            for t0, t1, (ch, col) in segs:
                if ch == " ":
                    continue
                if (t0, t1) == (0, 4) and not (letras_ns[0][f, c] == ch and np.abs(letras_ns[1][f, c] - col).sum() < 30):
                    titilan[(f * 7 + c * 3) % 3].append((f, c, "*" if col.max() > 200 else "+", col))  # una estrellita
                    continue
                grupos.setdefault((t0, t1), []).append((f, c, ch, col))
    ch_c, col_c = a_letras(*cerca)
    celdas_cerca = [(f, c, ch_c[f, c], col_c[f, c]) for f in range(FILAS) for c in range(COLS) if ch_c[f, c] != " "]
    return estados, grupos, titilan, (cerca, celdas_cerca)


def capas_svg(grupos, titilan):
    out = []
    for (t0, t1), celdas in sorted(grupos.items()):
        cuerpo = texto(celdas)
        if t1 == 1:
            cuerpo = f'<g class="oc1">{cuerpo}</g>'
        elif t1 == 2:
            cuerpo = f'<g clip-path="url(#oculta)">{cuerpo}</g>'
        elif t1 == 3:
            cuerpo = f'<g class="oc3">{cuerpo}</g>'
        if t0 == 1:
            cuerpo = f'<g class="ap1">{cuerpo}</g>'
        elif t0 == 2:
            cuerpo = f'<g clip-path="url(#revela)">{cuerpo}</g>'
        elif t0 == 3:
            cuerpo = f'<g class="ap3">{cuerpo}</g>'
        out.append(cuerpo)
    for k, celdas in titilan.items():
        out.append(f'<g class="tw{k}">{texto(celdas)}</g>')
    return "".join(out)


def destellos():
    """Chispitas de luz que caen por el rayo hasta el pesebre."""
    r = np.random.default_rng(12)
    out = []
    for k in range(30):
        x = ESTRELLA[0] + r.normal(0, 14)
        dur = r.uniform(3.2, 6.0)
        ch = "*+·.*"[k % 5]
        out.append(f'<text class="cae" x="{x:.0f}" y="96" fill="{["#fff6d8", "#ffe08a", "#ffffff"][k % 3]}" '
                   f'style="animation-duration:{dur:.1f}s;animation-delay:{T_VIVO + r.uniform(0, 6):.1f}s">{ch}</text>')
    return "".join(out)


def anillo():
    """Una coronita de luz que gira despacio alrededor del Niño."""
    cx, cy = NINO
    out = []
    for k in range(14):
        a = k / 14 * math.tau
        x, y = cx + math.cos(a) * 34 * K_ESTABLO, cy + math.sin(a) * 22 * K_ESTABLO
        out.append(f'<text x="{x - 2.5:.1f}" y="{y + 3:.1f}" fill="#fff0b0">{"·*·+"[k % 4]}</text>')
    return f'<g class="anillo"><g class="gira" style="transform-origin:{cx:.1f}px {cy:.1f}px">{"".join(out)}</g></g>'


def banda():
    """La terminal de abajo: un comentario y los versículos que se van tecleando."""
    y0 = H
    cw = 7.8
    out = [f'<rect x="0" y="{y0}" width="{W}" height="{BANDA}" fill="#0a0d1f"/>',
           f'<rect x="0" y="{y0}" width="{W}" height="1.5" fill="#c9a24a" opacity=".6"/>',
           f'<text x="16" y="{y0 + 24}" class="b" fill="#7d8bb8">{COMENTARIO}</text>']
    ciclo = 9.0 * len(VERSOS)
    for k, (verso, cita) in enumerate(VERSOS):
        linea_ = f"$ {verso}  — {cita}"
        n = len(linea_)
        ancho = n * cw
        pct = 9.0 / ciclo * 100
        teclea = 3.4 / ciclo * 100
        out.append(
            f'<style>@keyframes v{k}{{0%,{pct - 1.5:.2f}%{{opacity:1}}{pct:.2f}%,100%{{opacity:0}}}}'
            f'@keyframes c{k}{{0%{{transform:translateX(0);animation-timing-function:steps({n},end)}}'
            f'{teclea:.2f}%,100%{{transform:translateX({ancho:.1f}px)}}}}'
            f'.v{k}{{opacity:0;animation:v{k} {ciclo}s linear {T_VIVO + 9 * k}s infinite}}'
            f'.c{k}{{animation:c{k} {ciclo}s linear {T_VIVO + 9 * k}s infinite}}</style>'
            f'<g class="v{k}"><text x="16" y="{y0 + 50}" class="b"><tspan fill="#5fe07a">$ </tspan>'
            f'<tspan fill="#fff4e6">{verso}</tspan><tspan fill="#ffcf5a">  — {cita}</tspan></text>'
            f'<g class="c{k}"><rect x="{16 - 1}" y="{y0 + 36}" width="{W}" height="20" fill="#0a0d1f"/>'
            f'<rect class="cur" x="15" y="{y0 + 38}" width="8" height="15" fill="#ffcf5a"/></g></g>')
    return "".join(out)


T_CICLO, P_CICLO = 13.0, 34.0         # luego, cada 34 s: nos acercamos al pesebre y regresamos


def plano_cerca(cerca, celdas):
    """El primer plano: la Sagrada Familia de cerca, con su propia luz y chispitas."""
    bx, by = BEBE
    chispas = []
    r = np.random.default_rng(21)
    for k in range(26):
        x = 480 + r.normal(0, 26)
        dur = r.uniform(3.4, 6.2)
        chispas.append(f'<text class="cae2" x="{x:.0f}" y="96" fill="{["#fff6d8", "#ffe08a", "#ffffff"][k % 3]}" '
                       f'style="animation-duration:{dur:.1f}s;animation-delay:{-r.uniform(0, 6):.1f}s">{"*+·.*"[k % 5]}</text>')
    corona = []
    for k in range(18):
        a = k / 18 * math.tau
        corona.append(f'<text x="{bx + math.cos(a) * 74 - 2:.1f}" y="{by + math.sin(a) * 56 + 3:.1f}" fill="#fff0b0">{"·*·+"[k % 4]}</text>')
    return (f'<image href="{jpg_uri(cerca[0], 320, .56)}" width="{W}" height="{H}" preserveAspectRatio="none"/>'
            f'<ellipse class="respira-c" cx="480" cy="760" rx="380" ry="300" fill="url(#gP)"/>'
            f'<circle class="farol-c" cx="870" cy="314" r="70" fill="url(#gF)"/>'
            + f'<circle class="nino-c" cx="{bx}" cy="{by}" r="110" fill="url(#gN)"/>'
            + texto(celdas)
            + f'<circle class="nino-c" cx="{bx}" cy="{by}" r="80" fill="url(#gN)" opacity=".22"/>'
            f'<g class="gira" style="transform-origin:{bx}px {by}px">{"".join(corona)}</g>'
            + "".join(chispas))


def svg(estados, grupos, titilan, cerca_datos):
    HT = H + BANDA
    fondo_a = jpg_uri(estados[0][0], 320, .42)
    fondo_d = jpg_uri(estados[3][0], 320, .42)
    ex, ey = ESTRELLA
    nx, ny = NINO
    css = [
        fuente_css(),
        "text{font-size:6.67px}.b{font-size:13px}",
        "@keyframes ap{from{opacity:0}to{opacity:1}}@keyframes oc{from{opacity:1}to{opacity:0}}",
        f".ap1{{animation:ap .9s ease-out {T_ESTRELLA}s both}}.oc1{{animation:oc .6s linear {T_ESTRELLA}s both}}",
        f".ap3{{animation:ap {D_LUZ}s ease-in-out {T_LUZ}s both}}.oc3{{animation:oc {D_LUZ}s ease-in-out {T_LUZ}s both}}",
        f".fd{{animation:ap {T_LUZ + D_LUZ - T_ESTRELLA:.1f}s ease-in {T_ESTRELLA}s both}}",
        ".tw0{animation:tw 3.1s ease-in-out infinite}.tw1{animation:tw 4.3s ease-in-out -1.2s infinite}"
        ".tw2{animation:tw 2.4s ease-in-out -.7s infinite}@keyframes tw{50%{opacity:.25}}",
        f".halo-e{{opacity:0;animation:ap 1s ease-out {T_ESTRELLA}s both,late 3.6s ease-in-out {T_ESTRELLA + 1}s infinite}}",
        f".flare{{opacity:0;transform-origin:{ex}px {ey}px;animation:ap 1s ease-out {T_ESTRELLA + .2}s both,flare 5s ease-in-out {T_ESTRELLA + 1.2}s infinite}}",
        "@keyframes flare{0%,100%{transform:scale(1) rotate(0deg)}50%{transform:scale(1.18) rotate(4deg)}}",
        "@keyframes late{0%,100%{opacity:1}50%{opacity:.62}}",
        f".halo-p{{opacity:0;animation:ap {D_LUZ}s ease-in {T_LUZ}s both,respira 5s ease-in-out {T_LUZ + D_LUZ}s infinite}}",
        f".halo-n{{opacity:0;transform-origin:{nx:.1f}px {ny:.1f}px;animation:ap 1.4s ease-out {T_LUZ + .7}s both,nino 4s ease-in-out {T_LUZ + 2}s infinite}}",
        "@keyframes respira{0%,100%{opacity:1}50%{opacity:.7}}@keyframes nino{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.75;transform:scale(1.12)}}",
        f".farol{{opacity:0;animation:ap 1s ease-out {T_LUZ + .3}s both,farol 1.9s steps(6) {T_LUZ + 1.3}s infinite}}",
        "@keyframes farol{0%{opacity:1}20%{opacity:.72}35%{opacity:.95}55%{opacity:.8}75%{opacity:1}90%{opacity:.86}}",
        f".anillo{{opacity:0;animation:ap 2s ease-out {T_LUZ + 1}s both}}.gira{{animation:gira 40s linear infinite}}@keyframes gira{{to{{transform:rotate(360deg)}}}}",
        ".cae{opacity:0;animation-name:cae;animation-timing-function:ease-in;animation-iteration-count:infinite}"
        f"@keyframes cae{{0%{{opacity:0;transform:translateY(0)}}12%{{opacity:1}}85%{{opacity:.9}}100%{{opacity:0;transform:translateY({G(0, 528)[1] - 110:.0f}px)}}}}",
        f".fugaz{{opacity:0;animation:fugaz 15s ease-in {T_VIVO + 3}s infinite}}"
        "@keyframes fugaz{0%{opacity:0;transform:translate(0,0)}2%{opacity:1}7%{opacity:0;transform:translate(260px,110px)}100%{opacity:0;transform:translate(260px,110px)}}",
        ".cur{animation:parp 1s steps(1) infinite}@keyframes parp{50%{opacity:0}}",
        f".lejos{{transform-origin:{G(480, 700)[0]:.0f}px {G(480, 700)[1]:.0f}px;animation:lejos {P_CICLO}s ease-in-out {T_CICLO}s infinite both}}"
        "@keyframes lejos{0%{opacity:1;transform:scale(1)}7%{opacity:0;transform:scale(1.7)}50%{opacity:0;transform:scale(1.7)}"
        "57%{opacity:1;transform:scale(1)}100%{opacity:1;transform:scale(1)}}",
        f".cerca{{opacity:0;transform-origin:480px 760px;animation:cerca {P_CICLO}s ease-in-out {T_CICLO}s infinite both}}"
        "@keyframes cerca{0%{opacity:0;transform:scale(.62)}7%{opacity:1;transform:scale(1)}50%{opacity:1;transform:scale(1)}"
        "57%{opacity:0;transform:scale(.62)}100%{opacity:0;transform:scale(.62)}}",
        ".respira-c{animation:respira 5s ease-in-out infinite}.farol-c{animation:farol 1.9s steps(6) infinite}"
        f".nino-c{{transform-origin:{BEBE[0]}px {BEBE[1]}px;animation:nino 4s ease-in-out infinite}}",
        ".cae2{opacity:0;animation-name:cae2;animation-timing-function:ease-in;animation-iteration-count:infinite}"
        "@keyframes cae2{0%{opacity:0;transform:translateY(0)}12%{opacity:1}85%{opacity:.9}100%{opacity:0;transform:translateY(640px)}}",
        "@media (prefers-reduced-motion:reduce){*{animation:none!important}.ap1,.ap3,.fd,.halo-e,.halo-p,.halo-n,.farol,.anillo,.flare{opacity:1}"
        ".oc1,.oc3,.cae,.fugaz,.cerca,.cae2{opacity:0}}",
    ]
    defs = (
        f'<clipPath id="escaneo"><rect x="0" y="0" width="{W}" height="0">'
        f'<animate attributeName="height" from="0" to="{H}" dur="{T_ESCANEO}s" fill="freeze"/></rect></clipPath>'
        f'<clipPath id="revela"><rect x="0" y="0" width="{W}" height="100">'
        f'<animate attributeName="height" values="100;{G(0, 540)[1]:.0f};{H}" keyTimes="0;.82;1" begin="{T_RAYO}s" dur="{D_RAYO}s" fill="freeze"/></rect></clipPath>'
        f'<clipPath id="oculta"><rect x="0" y="100" width="{W}" height="{H}">'
        f'<animate attributeName="y" values="100;{G(0, 540)[1]:.0f};{H}" keyTimes="0;.82;1" begin="{T_RAYO}s" dur="{D_RAYO}s" fill="freeze"/></rect></clipPath>'
        '<radialGradient id="gE"><stop offset="0" stop-color="#ffffff" stop-opacity=".5"/><stop offset=".25" stop-color="#cfe0ff" stop-opacity=".22"/>'
        '<stop offset="1" stop-color="#8fb0ff" stop-opacity="0"/></radialGradient>'
        '<radialGradient id="gP"><stop offset="0" stop-color="#ffcf6a" stop-opacity=".34"/><stop offset=".6" stop-color="#ff9a30" stop-opacity=".12"/>'
        '<stop offset="1" stop-color="#ff9a30" stop-opacity="0"/></radialGradient>'
        '<radialGradient id="gN"><stop offset="0" stop-color="#fffbe8" stop-opacity=".75"/><stop offset=".4" stop-color="#ffe7a0" stop-opacity=".3"/>'
        '<stop offset="1" stop-color="#ffd060" stop-opacity="0"/></radialGradient>'
        '<radialGradient id="gF"><stop offset="0" stop-color="#ffc060" stop-opacity=".6"/><stop offset="1" stop-color="#ff9a30" stop-opacity="0"/></radialGradient>'
        '<linearGradient id="gH" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".9"/>'
        '<stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
        '<linearGradient id="gV" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".9"/>'
        '<stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'
        '<linearGradient id="gS" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity=".95"/></linearGradient>'
    )
    escena_svg = (
        f'<rect width="{W}" height="{H}" fill="#050817"/>'
        f'<image href="{fondo_a}" width="{W}" height="{H}" preserveAspectRatio="none"/>'
        f'<image class="fd" href="{fondo_d}" width="{W}" height="{H}" preserveAspectRatio="none"/>'
        f'<circle class="halo-e" cx="{ex}" cy="{ey}" r="150" fill="url(#gE)"/>'
        f'<ellipse class="halo-p" cx="{G(480, 690)[0]:.0f}" cy="{G(480, 690)[1]:.0f}" rx="{190 * K_ESTABLO:.0f}" ry="{120 * K_ESTABLO:.0f}" fill="url(#gP)"/>'
        f'<circle class="farol" cx="{G(346, 626)[0]:.0f}" cy="{G(346, 626)[1]:.0f}" r="{30 * K_ESTABLO:.0f}" fill="url(#gF)"/>'
        f'<g class="fugaz"><rect x="120" y="60" width="70" height="1.6" fill="url(#gS)" transform="rotate(23 155 60)"/></g>'
        + capas_svg(grupos, titilan)
        + f'<g class="flare"><rect x="{ex - 120}" y="{ey - .8}" width="240" height="1.6" fill="url(#gH)"/>'
          f'<rect x="{ex - .8}" y="{ey - 70}" width="1.6" height="140" fill="url(#gV)"/></g>'
        + f'<circle class="halo-n" cx="{nx:.1f}" cy="{ny:.1f}" r="{46 * K_ESTABLO:.0f}" fill="url(#gN)"/>'
        + anillo() + destellos()
    )
    titulo = "El Nacimiento: Belén de noche, la estrella y su luz sobre el pesebre con María, José y el Niño, hecho de puras letras"
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{HT}" viewBox="0 0 {W} {HT}" role="img" aria-label="{titulo}">'
            f'<title>{titulo}</title><defs>{defs}</defs><style>{"".join(css)}</style>'
            f'<rect width="{W}" height="{HT}" fill="#050817"/>'
            f'<g clip-path="url(#escaneo)"><g class="lejos">{escena_svg}</g>'
        f'<g class="cerca">{plano_cerca(*cerca_datos)}</g></g>{banda()}</svg>')


if __name__ == "__main__" and "--png" not in sys.argv:
    import time
    t = time.time()
    estados, grupos, titilan, cerca_datos = construir()
    doc = svg(estados, grupos, titilan, cerca_datos)
    ASSETS.mkdir(exist_ok=True)
    (ASSETS / "nacimiento.svg").write_text(doc, encoding="utf-8")
    n = sum(len(v) for v in grupos.values()) + sum(len(v) for v in titilan.values())
    print(f"assets/nacimiento.svg  ({len(doc.encode()) / 1e6:.2f} MB, {n} letras, {time.time() - t:.0f} s)")

if __name__ == "__main__" and "--png" in sys.argv:
    img = escena_cerca()[0] if "--cerca" in sys.argv else escena(True, True, True)[0]
    Image.fromarray(img.astype(np.uint8)).save("/tmp/nacimiento_base.png")
    print("ok")
