"""Mini motor de pixel art: figuras con sombreado, contorno y capas animables."""
import math

# ── Paleta (claro, base, sombra, sombra profunda)
CONTORNO = "#17141f"
NIEVE = ("#ffffff", "#e3edf5", "#b4c6d6", "#8197ad")
ROJO = ("#ff5c63", "#d62f3b", "#9c1d2c", "#6b1220")
VERDE = ("#6fdc7e", "#2fae5a", "#1d7a40", "#11502a")
ORO = ("#ffe58a", "#f6c03f", "#c98a1e", "#8a5a12")
NARANJA = ("#ffb057", "#f07f22", "#b8561a", "#7f3a12")
CAFE = ("#c98a55", "#9c623a", "#6e4026", "#45271a")
NEGRO = ("#4a4659", "#2b2836", "#1b1922", "#121017")
PIEL = ("#ffe0c8", "#f4b998", "#d98f72", "#b56a52")
AZUL = ("#9ad6ff", "#3f8fe0", "#235aa6", "#16386b")
CANELA = ("#f3d3a6", "#e2b585", "#c4915f", "#9a6a3e")
GALLETA = ("#eda466", "#c97a3f", "#9a5528", "#6e3a1a")
COSTAL = ("#e2b273", "#b98445", "#8c5e2c", "#5f3d1b")
ROSA = "#ff8fb8"
MEJILLA = "#f2787c"
OJO = "#15131b"


class Sprite:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.capas = {"base": {}}
        self.orden = ["base"]
        self.actual = "base"

    def capa(self, nombre):
        if nombre not in self.capas:
            self.capas[nombre] = {}
            self.orden.append(nombre)
        self.actual = nombre
        return self

    def px(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.capas[self.actual][(x, y)] = c

    def get(self, x, y):
        return self.capas[self.actual].get((x, y))

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, c)

    def pts(self, lista, c):
        for x, y in lista:
            self.px(x, y, c)

    def linea(self, x0, y0, x1, y1, c, grosor=1):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            for g in range(grosor):
                self.px(x0 + g, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def elipse(self, cx, cy, rx, ry, tonos, luz=(-0.6, -0.8), dentro=None, solo=None):
        """Elipse rellena con brillo arriba-izquierda y sombra abajo-derecha."""
        claro, base, sombra = tonos[0], tonos[1], tonos[2]
        hondo = tonos[3] if len(tonos) > 3 else sombra
        for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
            for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
                u, v = (x + .5 - cx) / rx, (y + .5 - cy) / ry
                d = u * u + v * v
                if d > 1 or (dentro and not dentro(x, y)) or (solo and (x, y) not in solo):
                    continue
                s = u * luz[0] + v * luz[1]
                if s > .42 and d < .6:
                    c = claro
                elif s < -.62 and d > .62:
                    c = hondo
                elif s < -.3 and d > .4:
                    c = sombra
                else:
                    c = base
                self.px(x, y, c)

    def poligono(self, puntos, c):
        ys = [p[1] for p in puntos]
        for y in range(math.floor(min(ys)), math.ceil(max(ys)) + 1):
            yc = y + .5
            cortes = []
            for (x0, y0), (x1, y1) in zip(puntos, puntos[1:] + puntos[:1]):
                if (y0 <= yc < y1) or (y1 <= yc < y0):
                    cortes.append(x0 + (yc - y0) * (x1 - x0) / (y1 - y0))
            cortes.sort()
            for a, b in zip(cortes[::2], cortes[1::2]):
                for x in range(math.ceil(a - .5), math.floor(b - .5) + 1):
                    self.px(x, y, c)

    def recolorear(self, filtro, fn):
        """Cambia el color de los pixeles de la capa actual que cumplan filtro(x, y, color)."""
        capa = self.capas[self.actual]
        for (x, y), c in list(capa.items()):
            if filtro(x, y, c):
                capa[(x, y)] = fn(x, y, c)

    def contorno(self, color=CONTORNO, diagonales=False):
        capa = self.capas[self.actual]
        vecinos = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        if diagonales:
            vecinos += [(1, 1), (-1, -1), (1, -1), (-1, 1)]
        nuevos = set()
        for (x, y) in capa:
            for dx, dy in vecinos:
                if (x + dx, y + dy) not in capa:
                    nuevos.add((x + dx, y + dy))
        for x, y in nuevos:
            self.px(x, y, color)
        return self


def mezclar_textura(tonos, x, y, patron=5):
    """Pelaje/nieve: salpica pixeles de sombra en patrón diagonal."""
    return tonos[2] if (x * 2 + y * 3) % patron == 0 else tonos[1]
