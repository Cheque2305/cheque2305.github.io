#!/usr/bin/env python3
"""Adornos vectoriales para la página: ramitas de acebo (pino, hojas, bayas y florecitas)
y las notitas musicales que salen cuando bailan. Todo sale como texto SVG (lo usa pagina.py).

    python3 scripts/gala.py [carpeta]      # escribe las piezas sueltas para verlas
"""
import math
import random
from pathlib import Path

AQUI = Path(__file__).resolve().parent
# ───────────────────────── notitas musicales ─────────────────────────
def nota(doble=False, color1="#fbe7b0", color2="#c9973f"):
    defs = (f'<defs><linearGradient id="n" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{color1}"/>'
            f'<stop offset="1" stop-color="{color2}"/></linearGradient></defs>')
    if doble:
        cuerpo = ('<ellipse cx="8" cy="31" rx="7" ry="5" transform="rotate(-22 8 31)"/>'
                  '<ellipse cx="30" cy="27" rx="7" ry="5" transform="rotate(-22 30 27)"/>'
                  '<path d="M13 30V7l23-5v24h-2.6V7.6L15.6 11.3V30z"/><path d="M15 7.8l21-4.7v5.2l-21 4.6z"/>')
        w = 40
    else:
        cuerpo = ('<ellipse cx="9" cy="31" rx="7.5" ry="5.4" transform="rotate(-22 9 31)"/>'
                  '<path d="M14.6 30V2h2.8c.6 6 9.4 8.6 7.6 19 1-8-3.5-11.3-7.6-12.3V30z"/>')
        w = 28
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} 38" width="{w}" height="38">{defs}<g fill="url(#n)">{cuerpo}</g></svg>'


# ───────────────────────── acebo, bayas y pino (estilo grabado botánico) ─────────────────────────
def _hoja_acebo(r, L, W, picos=4):
    sup, inf = [], []
    ts = [k / (picos + 1) for k in range(1, picos + 1)]
    ancho = lambda t: W * math.sin(math.pi * min(t, .999)) ** .65  # noqa: E731
    curva = lambda t: L * .07 * math.sin(math.pi * t)  # noqa: E731
    prev = 0.0
    for t in ts + [1.0]:
        m = (prev + t) / 2
        sup.append(f"Q{L * m:.1f} {-ancho(m) * .58 + curva(m):.1f} {L * t:.1f} {(-ancho(t) * 1.06 if t < 1 else 0) + curva(t):.1f}")
        prev = t
    prev = 1.0
    for t in list(reversed(ts)) + [0.0]:
        m = (prev + t) / 2
        inf.append(f"Q{L * m:.1f} {ancho(m) * .58 + curva(m):.1f} {L * t:.1f} {(ancho(t) * 1.06 if t > 0 else 0) + curva(t):.1f}")
        prev = t
    contorno = "M0 0" + "".join(sup) + "".join(inf) + "Z"
    mitad = "M0 0" + "".join(sup) + f"Q{L * .5:.1f} {curva(.5) + 1:.1f} 0 0Z"
    venas = "".join(f"M{L * t * .82:.1f} {curva(t * .82):.1f}L{L * t:.1f} {s_ * ancho(t) * .9 + curva(t):.1f}"
                    for t in ts for s_ in (-1, 1))
    tono = r.choice(["gH1", "gH2", "gH3"])
    return (f'<path d="{contorno}" fill="url(#{tono})" stroke="#16301f" stroke-width=".8"/>'
            f'<path d="{mitad}" fill="#e8f0d8" opacity=".13"/>'
            f'<path d="M0 0Q{L * .5:.1f} {curva(.5):.1f} {L * .97:.1f} 0" stroke="#b9cfa3" stroke-width="1.3" fill="none" opacity=".75"/>'
            f'<path d="{venas}" stroke="#a9c296" stroke-width=".7" opacity=".45" fill="none"/>')


def _pino(r, x0, y0, ang, largo):
    out = [f'<path d="M{x0:.1f} {y0:.1f}l{largo * math.cos(ang):.1f} {largo * math.sin(ang):.1f}" stroke="#6b4a2e" stroke-width="2.2"/>']
    agujas = []
    n = int(largo / 3.2)
    for k in range(n):
        t = k / n
        bx, by = x0 + largo * t * math.cos(ang), y0 + largo * t * math.sin(ang)
        for lado in (-1, 1):
            a = ang + lado * r.uniform(.55, .8)
            l = 15 * (1 - .55 * t) + r.uniform(-2, 2)
            agujas.append(f"M{bx:.1f} {by:.1f}l{l * math.cos(a):.1f} {l * math.sin(a):.1f}")
    colores = ["#23402c", "#2f5539", "#3f6b47", "#58835a"]
    trozos = [agujas[i::4] for i in range(4)]
    for c, tr in zip(colores, trozos):
        out.append(f'<path d="{"".join(tr)}" stroke="{c}" stroke-width="1.4" stroke-linecap="round" fill="none"/>')
    return "".join(out)


def _baya(x, y, rr):
    return (f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rr:.1f}" fill="url(#gB)" stroke="#5a0a12" stroke-width=".6"/>'
            f'<circle cx="{x - rr * .35:.1f}" cy="{y - rr * .38:.1f}" r="{rr * .22:.1f}" fill="#fff" opacity=".8"/>'
            f'<circle cx="{x + rr * .45:.1f}" cy="{y + rr * .45:.1f}" r="{rr * .14:.1f}" fill="#3a0509"/>')


def _flor(x, y, rr):
    petalos = "".join(f'<ellipse cx="{x + rr * .55 * math.cos(a):.1f}" cy="{y + rr * .55 * math.sin(a):.1f}" rx="{rr * .55:.1f}" ry="{rr * .36:.1f}" '
                      f'transform="rotate({math.degrees(a):.0f} {x + rr * .55 * math.cos(a):.1f} {y + rr * .55 * math.sin(a):.1f})"/>'
                      for a in [k * 2 * math.pi / 5 - math.pi / 2 for k in range(5)])
    return (f'<g fill="#fbf6ea" stroke="#c9b8a0" stroke-width=".6">{petalos}</g>'
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rr * .28:.1f}" fill="#b3242c"/>')


def acebo(W=380, H=380, semilla=12):
    """Ramillete de esquina: pino, hojas de acebo, bayas rojas y florecitas blancas."""
    r = random.Random(semilla)
    defs = ('<radialGradient id="gB" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#ff8a80"/>'
            '<stop offset=".35" stop-color="#d2232f"/><stop offset=".85" stop-color="#7d0c17"/><stop offset="1" stop-color="#4a050c"/></radialGradient>'
            '<linearGradient id="gH1" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#1b3a27"/><stop offset="1" stop-color="#3d6a49"/></linearGradient>'
            '<linearGradient id="gH2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#16301f"/><stop offset="1" stop-color="#2f5a3b"/></linearGradient>'
            '<linearGradient id="gH3" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#22422c"/><stop offset="1" stop-color="#4f7d55"/></linearGradient>')
    capas = []
    ox, oy = 16, 16                                   # el "nudo" del ramillete, en la esquina
    for ang, largo in ((.05, 300), (.42, 230), (.85, 200), (1.2, 240), (1.5, 210), (.65, 140)):
        capas.append(_pino(r, ox - 10, oy - 10, ang, largo))
    hojas = ((.0, 140, 44), (.26, 128, 40), (.52, 148, 46), (.8, 120, 38), (1.06, 136, 42), (1.32, 126, 40),
             (1.55, 112, 36), (.4, 86, 30), (.95, 80, 28))
    for ang, L, Wd in hojas:
        capas.append(f'<g transform="translate({ox + r.uniform(-3, 3):.1f} {oy + r.uniform(-3, 3):.1f}) rotate({math.degrees(ang):.1f})">'
                     f'{_hoja_acebo(r, L, Wd)}</g>')
    for ang, L, Wd, x0, y0 in ((.1, 88, 28, 196, 30), (-.3, 74, 24, 204, 38), (.45, 70, 24, 214, 46),
                               (1.42, 86, 28, 30, 190), (1.85, 72, 24, 38, 200), (1.15, 68, 22, 46, 210)):
        capas.append(f'<g transform="translate({x0} {y0}) rotate({math.degrees(ang):.1f})">{_hoja_acebo(r, L, Wd)}</g>')
    capas.append(_flor(150, 136, 14) + _flor(268, 74, 11) + _flor(84, 244, 11) + _flor(196, 156, 9))
    for cx, cy, n in ((92, 86, 11), (206, 44, 6), (44, 206, 6), (150, 160, 4), (300, 40, 3), (40, 296, 3)):
        bs = [(cx + r.gauss(0, 12), cy + r.gauss(0, 11), r.uniform(7, 10)) for _ in range(n)]
        capas.append("".join(_baya(*b) for b in sorted(bs, key=lambda b: b[1])))
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}"><defs>{defs}</defs>'
            f'<g filter="drop-shadow(0 2px 2px rgba(60,40,20,.25))">{"".join(capas)}</g></svg>')


if __name__ == "__main__":
    import sys
    dest = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/adornos")
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "acebo.svg").write_text(acebo(), encoding="utf-8")
    (dest / "nota.svg").write_text(nota(), encoding="utf-8")
    (dest / "nota2.svg").write_text(nota(True), encoding="utf-8")
    print(f"{dest}/ listo")
