#!/usr/bin/env python3
"""Árbol de Navidad 3D en arte ASCII que gira, estilo terminal.

    python3 scripts/arte.py              -> genera assets/arbol-ascii.svg (para el README)
    python3 scripts/arte.py --terminal   -> lo reproduce en tu terminal con color real

Necesita numpy (pip install numpy).
"""
import base64
import math
import re
import sys
import time
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
ASSETS = AQUI.parent / "assets"
FUENTE = AQUI / "fuente" / "JetBrainsMono-Regular.woff2"

# ───────────────────────── lienzo y cámara ─────────────────────────
COLS, FILAS = 100, 44          # tamaño de la escena en caracteres
CW, CH, FS = 9, 18, 15         # celda en px (JetBrains Mono 15px avanza 9px)
FPS = 15
PASO = 4.0                     # grados de giro por cuadro
N_BUCLE = round(360 / PASO)    # una vuelta completa = cuadros del bucle
T_ARBOL = 3.0                  # segundos que tarda el árbol en crecer
N_INTRO = round(T_ARBOL * FPS)
RAMPA = " .:-=+*#%@"

K = 280.0                      # px por unidad del mundo
CX, FY = 50.0, 36.5            # columna del eje del árbol y fila del piso
ALFA = math.radians(11)        # la cámara mira un poquito hacia abajo
CA, SA = math.cos(ALFA), math.sin(ALFA)
LUZ = np.array([-0.55, 0.55, 0.63])
LUZ = LUZ / np.linalg.norm(LUZ)

ROJO = np.array([236, 48, 64.0])
ORO = np.array([247, 192, 58.0])
PLATA = np.array([214, 224, 238.0])
ROSA = np.array([255, 122, 184.0])
AZUL = np.array([80, 140, 255.0])
VERDE = np.array([70, 210, 100.0])
CALIDO = np.array([255, 214, 150.0])
BLANCO = np.array([242, 246, 240.0])

# Momentos (segundos) en que aparece cada parte; el editor de código va sincronizado
T_ESTRELLA, T_ESFERAS, T_LUCES, T_REGALOS = 3.0, 4.2, 5.6, 7.0
T_NIEVE, T_TRINEO, T_TERMINAL, T_LISTO = 8.6, 10.0, 11.4, 13.0

rng = np.random.default_rng(2512)


def proyectar(x, y, z):
    ys = y * CA - z * SA
    prof = z * CA + y * SA
    return CX + x * K / CW, FY - ys * K / CH, prof


def mezcla(lum, paradas, colores):
    lum = np.asarray(lum, dtype=float)
    return np.stack([np.interp(lum, paradas, [c[i] for c in colores]) for i in range(3)], axis=-1)


def verde(lum):
    return mezcla(lum, [0, .5, .8, 1], [(16, 64, 32), (34, 150, 64), (115, 218, 112), (226, 250, 214)])


def dorado(lum):
    return mezcla(lum, [0, .5, .85, 1], [(120, 78, 12), (232, 166, 40), (255, 214, 88), (255, 246, 205)])


class Lienzo:
    """Buffer de caracteres con profundidad (z-buffer), como una pantalla de terminal."""

    def __init__(self):
        n = COLS * FILAS
        self.z = np.full(n, -np.inf)
        self.lum = np.zeros(n)
        self.rgb = np.zeros((n, 3))
        self.tag = np.full(n, -1)
        self.car = np.full(n, "", dtype="<U1")

    def solido(self, col, fila, prof, lum, rgb, tag=-1, car=None):
        ci = np.floor(col).astype(np.int64)
        ri = np.floor(fila).astype(np.int64)
        ok = (ci >= 0) & (ci < COLS) & (ri >= 0) & (ri < FILAS)
        if not ok.any():
            return
        idx, prof = ri[ok] * COLS + ci[ok], np.asarray(prof)[ok]
        lum, rgb = np.asarray(lum)[ok], np.asarray(rgb)[ok]
        tag = np.broadcast_to(np.asarray(tag), ok.shape)[ok]
        car = np.broadcast_to(np.asarray(car if car is not None else ""), ok.shape)[ok]
        o = np.lexsort((prof, idx))
        idx, prof, lum, rgb, tag, car = idx[o], prof[o], lum[o], rgb[o], tag[o], car[o]
        ult = np.r_[idx[1:] != idx[:-1], True]           # el punto más cercano de cada celda
        idx, prof, lum, rgb, tag, car = idx[ult], prof[ult], lum[ult], rgb[ult], tag[ult], car[ult]
        g = prof > self.z[idx]
        i = idx[g]
        self.z[i], self.lum[i], self.rgb[i], self.tag[i], self.car[i] = prof[g], lum[g], rgb[g], tag[g], car[g]

    def celdas(self, rampa=RAMPA, minimo=1):
        occ = np.nonzero(np.isfinite(self.z))[0]
        k = np.clip(np.rint(self.lum[occ] * (len(rampa) - 1)), minimo, len(rampa) - 1).astype(int)
        cars = np.array(list(rampa))[k]
        forz = self.car[occ] != ""
        cars[forz] = self.car[occ][forz]
        vis = cars != " "
        return occ[vis] % COLS, occ[vis] // COLS, cars[vis], self.rgb[occ][vis], self.tag[occ][vis]


# ───────────────────────── geometría del árbol ─────────────────────────
R0, Y0, ALTO, PISOS = 0.88, 0.06, 1.80, 7
NH, NT = 190, 420
_h = (np.arange(NH) + 0.5) / NH
_t = 2 * np.pi * (np.arange(NT) + 0.5) / NT
H, TH = (a.ravel() for a in np.meshgrid(_h, _t, indexing="ij"))
U = (H * PISOS + 0.12) % 1.0                         # posición dentro de cada piso de ramas


def radio(h, u):
    return R0 * (1 - h) ** 1.02 * (1.0 - 0.30 * u)


# ramas frondosas: puntas que salen y entran como en un pino de verdad
R = radio(H, U) * (1 + 0.08 * np.sin(TH * 13 + H * 29) + 0.05 * np.sin(TH * 31 - H * 53)
                   + 0.035 * rng.normal(size=H.shape))
Y = Y0 + H * ALTO
NY = 0.42 + 0.38 * U
TEX = 0.55 * np.sin(TH * 23 + H * 41) * np.sin(H * 97 + TH * 5) + rng.normal(0, .38, H.shape)

DISCO_R, DISCO_A = (a.ravel() for a in np.meshgrid(np.sqrt(np.linspace(0, 1, 40)), np.linspace(0, 2 * np.pi, 160)))
_tr_h = np.linspace(-0.02, Y0 + 0.06, 10)
_tr_t = np.linspace(0, 2 * np.pi, 60, endpoint=False)
TRH, TRT = (a.ravel() for a in np.meshgrid(_tr_h, _tr_t, indexing="ij"))


def verde_dorado(lum):
    """Verde pino con brillos dorados, como iluminado por la estrella."""
    return mezcla(lum, [0, .45, .75, .92, 1],
                  [(10, 46, 26), (26, 112, 56), (70, 168, 78), (176, 214, 112), (255, 236, 170)])


# ── 1 · árbol ─────────────────────────────────────────────
def arbol(lz, giro, construido=1.0):
    ang = TH + giro                                   # a dar vueltas como en la posada
    x, z = R * np.cos(ang), R * np.sin(ang)
    n = np.stack([np.cos(ang), NY, np.sin(ang)], 1)
    dif = np.clip(n @ LUZ / np.linalg.norm(n, axis=1), 0, 1)
    lum = np.clip(0.2 + 0.7 * dif + 0.12 * TEX + 0.1 * H, 0.08, 1)  # más luz cerca de la estrella
    punta = np.clip(1 - (construido - H) / 0.045, 0, 1) * (construido < 1)
    rgb = verde_dorado(lum) * (1 - punta[:, None]) + BLANCO * punta[:, None]   # brilla mientras crece
    m = H <= construido
    lz.solido(*proyectar(x[m], Y[m], z[m]), np.maximum(lum, punta)[m], rgb[m])
    if construido < 1:                                # disco brillante donde va "imprimiendo"
        rr, aa = DISCO_R * radio(construido, (construido * PISOS + .12) % 1), DISCO_A + giro
        lz.solido(*proyectar(rr * np.cos(aa), np.full(aa.size, Y0 + construido * ALTO), rr * np.sin(aa)),
                  np.full(aa.size, .95), np.tile(BLANCO, (aa.size, 1)))
    a = TRT + giro                                    # tronco
    lz.solido(*proyectar(.11 * np.cos(a), TRH, .11 * np.sin(a)), .35 + .3 * np.clip(-np.cos(a), 0, 1),
              np.tile([[130, 82, 40.0]], (a.size, 1)))


# Estrella: polígono de 5 picos muestreado en su plano
_eu, _ev = np.meshgrid(np.linspace(-.31, .31, 120), np.linspace(-.31, .31, 120))
_ea = np.arctan2(_ev, _eu) + np.pi / 2
_er = np.hypot(_eu, _ev)
_sector = (_ea % (2 * np.pi / 5)) / (2 * np.pi / 5)
_borde = np.where(_sector < .5, .30 + (.115 - .30) * _sector * 2, .115 + (.30 - .115) * (_sector - .5) * 2)
_dentro = _er <= _borde
EU, EV, ER = _eu[_dentro], _ev[_dentro], _er[_dentro]
YE = Y0 + ALTO + 0.17


# ── 2 · estrella ──────────────────────────────────────────
def estrella(lz, giro):
    giro = .55 * math.sin(giro)                       # se mece al ritmo del villancico
    c, s = math.cos(giro), math.sin(giro)
    for w in (-.018, .018):                           # dos capas: se ve aunque esté de canto
        x, z = EU * c + w * s, -EU * s + w * c
        frente = abs(c) ** .5
        lum = np.clip(.6 + .4 * frente * (1 - ER / .36) + .1 * np.sin(EU * 90), .55, 1)
        lz.solido(*proyectar(x, YE + EV, z), lum, dorado(lum), tag=1)


def _esparcir(n, hmin, hmax, sep, semilla):
    r = np.random.default_rng(semilla)
    pts = []
    while len(pts) < n:
        h, t = r.uniform(hmin, hmax) ** 1.25, r.uniform(0, 2 * np.pi)
        if all((h - a) ** 2 * 9 + (1 - h) * ((math.cos(t - b) - 1) ** 2 + math.sin(t - b) ** 2) > sep for a, b in pts):
            pts.append((h, t))
    return np.array(pts)


CREMA = np.array([250, 236, 200.0])
AMBAR = np.array([255, 150, 60.0])
_orn = _esparcir(72, .04, .93, .02, 7)
ORN_H, ORN_T = _orn[:, 0], _orn[:, 1]
ORN_R = radio(ORN_H, (ORN_H * PISOS + .12) % 1) * 1.12 + .02
ORN_C = rng.choice(3, size=len(_orn), p=[.5, .38, .12])
ORN_G = np.minimum((ORN_H * 4).astype(int), 3)       # aparecen de abajo hacia arriba


# ── 3 · esferas ───────────────────────────────────────────
def esferas(lz, giro):
    ang = ORN_T + giro
    col, fila, prof = proyectar(ORN_R * np.cos(ang), Y0 + ORN_H * ALTO, ORN_R * np.sin(ang))
    marcas = []
    for k in range(len(ang)):
        ci, ri = int(col[k]), int(fila[k])
        if 0 <= ci < COLS and 0 <= ri < FILAS and prof[k] >= lz.z[ri * COLS + ci] - .03:
            b = .45 + .55 * max(0.0, math.cos(ang[k]) * LUZ[0] + .35 * LUZ[1] + math.sin(ang[k]) * LUZ[2])
            base = (ROJO, ORO, CREMA)[ORN_C[k]]
            rgb = base * (.5 + .5 * b) + (BLANCO - base) * max(0, b - .85) * 3
            marcas.append((ci, ri, "@" if b > .6 else "%", rgb, "RYW"[ORN_C[k]], b, f"o{ORN_G[k]}"))
    return marcas


# Foquitos de hada (muchos, cálidos, cada uno titila a su ritmo) y dos guirnaldas doradas
_hadas = np.random.default_rng(24)
NHADAS = 190
HADA_H = _hadas.uniform(.03, .95, NHADAS) ** 1.2
HADA_T = _hadas.uniform(0, 2 * np.pi, NHADAS)
HADA_R = radio(HADA_H, (HADA_H * PISOS + .12) % 1) * 1.07
HADA_C = _hadas.choice(4, NHADAS, p=[.5, .2, .2, .1])           # oro, ámbar, crema, rojo
HADA_F = _hadas.uniform(0, 2 * np.pi, NHADAS)
HADA_V = _hadas.integers(1, 5, NHADAS)                          # vueltas de titileo por giro completo
_s = np.linspace(0, 1, 420)
GUIR = [(.06 + .84 * _s, _s * 2 * np.pi * 3.5 + desfase) for desfase in (0, np.pi)]


# ── 4 · luces ─────────────────────────────────────────────
def luces(lz, giro, cuadro):
    """Guirnaldas doradas y foquitos que titilan; regresa los halos de los más brillantes."""
    for gh, gt in GUIR:                               # las guirnaldas de oro dan la vuelta al árbol
        ang = gt + giro
        r = radio(gh, (gh * PISOS + .12) % 1) * 1.09
        frente = np.clip(np.sin(ang) * .6 + .5, .25, 1)
        lz.solido(*proyectar(r * np.cos(ang), Y0 + gh * ALTO, r * np.sin(ang)), frente,
                  dorado(frente), tag=3, car=np.where(frente > .55, "~", "-"))
    b = .5 + .5 * np.sin(HADA_F + 2 * np.pi * HADA_V * cuadro / N_BUCLE)   # la serie que sí prendió
    color = np.array([ORO, AMBAR, CREMA, ROJO])[HADA_C] * (.55 + .45 * b[:, None])
    ang = HADA_T + giro
    col, fila, prof = proyectar(HADA_R * np.cos(ang), Y0 + HADA_H * ALTO, HADA_R * np.sin(ang))
    lz.solido(col, fila, prof, b, color, tag=2, car=np.where(b > .72, "*", np.where(b > .4, "•", "·")))
    halos = []
    for k in np.nonzero(b > .68)[0]:
        ci, ri = int(col[k]), int(fila[k])
        if 0 <= ci < COLS and 0 <= ri < FILAS and lz.tag[ri * COLS + ci] == 2 and prof[k] >= lz.z[ri * COLS + ci] - 1e-9:
            halos.append((ci, ri, "YAWR"[HADA_C[k]], float(b[k])))
    return halos


# ── 5 · regalos ───────────────────────────────────────────
ORO_C = np.array([236, 190, 92.0])
ROJO_OSC = np.array([150, 30, 40.0])
VERDE_P = np.array([40, 120, 66.0])
REGALOS = [  # (x, z, ancho, fondo, alto, giro°, caja, listón): montoncito de regalos como en las pinturas
    (-.95, .30, .40, .34, .34, 18, ORO_C, ROJO),
    (.92, .32, .42, .36, .38, -22, ROJO_OSC, ORO),
    (-.48, .90, .32, .28, .25, -10, ROJO, ORO),
    (.06, 1.06, .26, .24, .20, 8, CREMA, ROJO),
    (.56, .88, .30, .28, .24, -18, VERDE_P, ORO),
]


def regalos(lz):
    for g, (x0, z0, w, d, alto, yaw, caja, liston) in enumerate(REGALOS):
        c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
        a, b = np.meshgrid(np.linspace(-.5, .5, 60), np.linspace(0, 1, 50))
        a, b = a.ravel(), b.ravel()
        caras = [  # (u, v, w) locales y normal local
            (a * w, np.full_like(a, alto), (b - .5) * d, (0, 1, 0)),
            (a * w, b * alto, np.full_like(a, d / 2), (0, 0, 1)),
            (np.full_like(a, w / 2), b * alto, a * d, (1, 0, 0)),
            (np.full_like(a, -w / 2), b * alto, a * d, (-1, 0, 0)),
        ]
        for lu, lv, lw, (nu, nv, nw) in caras:
            X, Z = x0 + lu * c + lw * s, z0 - lu * s + lw * c
            nx, nz = nu * c + nw * s, -nu * s + nw * c
            dif = max(0.0, nx * LUZ[0] + nv * LUZ[1] + nz * LUZ[2])
            en_liston = (np.abs(lu) < w * .09) | ((np.abs(lw) < d * .09) & (nv == 1)) | ((np.abs(lw) < d * .09) & (nu != 0))
            lum = np.clip(.32 + .62 * dif + .08 * np.sin(lu * 70) * np.sin(lv * 60), .22, 1)
            rgb = np.where(en_liston[:, None], liston * (.55 + .45 * lum[:, None]), caja * (.45 + .55 * lum[:, None]))
            lz.solido(*proyectar(X, lv, Z), lum, rgb, tag=g, car=np.where(en_liston, "#", ""))
        mo = np.linspace(0, 2 * np.pi, 40)             # moño
        for lado in (-1, 1):
            lz.solido(*proyectar(x0 + lado * .05 * c + .045 * np.cos(mo) * c, alto + .05 + .045 * np.sin(mo),
                                 z0 - lado * .05 * s), np.full(40, .92), np.tile(liston, (40, 1)), tag=g)


# ───────────────────────── fondo: luna llena, nubes, cielo y piso ─────────────────────────
LUNA = (15.0, 8.0, 112)                               # columna, fila y radio en px
ESC_TRINEO = 2.2                                      # tamaño del trineo (px por pixelito)


def luna(lz):
    r = np.random.default_rng(1)
    th, ph = np.meshgrid(np.linspace(0, np.pi, 90), np.linspace(0, 2 * np.pi, 180), indexing="ij")
    x, y, z = (np.sin(th) * np.cos(ph)).ravel(), np.cos(th).ravel(), (np.sin(th) * np.sin(ph)).ravel()
    luz = np.array([.25, .3, .92]) / np.linalg.norm([.25, .3, .92])
    crater = np.zeros(x.size)
    for _ in range(14):                               # cráteres suavecitos
        c = r.normal(size=3)
        c /= np.linalg.norm(c)
        crater += np.exp(-((x - c[0]) ** 2 + (y - c[1]) ** 2 + (z - c[2]) ** 2) / r.uniform(.01, .05)) * r.uniform(.15, .35)
    lum = np.clip(.35 + .65 * np.clip(x * luz[0] + y * luz[1] + z * luz[2], 0, 1) - crater, .15, 1)
    ccol, cfila, rpx = LUNA
    lz.solido(ccol + x * rpx / CW, cfila - y * rpx / CH, z, lum,
              mezcla(lum, [0, .6, 1], [(110, 96, 80), (232, 218, 188), (255, 248, 226)]))


def nubes():
    """Nubes esponjosas hechas de puntitos, iluminadas por la luna (cada una flota a su ritmo)."""
    r = np.random.default_rng(9)
    out = []
    for cx, cy, ancho, bultos in ((21, 15.6, 9, 4), (81, 4.5, 10, 4), (93, 13, 6, 3), (71, 17, 6, 3), (6, 22, 6, 3)):
        celdas = []
        centros = [(cx + (i - (bultos - 1) / 2) * ancho * .5, cy - (.9 if 0 < i < bultos - 1 else .2), ancho * .42)
                   for i in range(bultos)]
        for fila in range(int(cy - 4), int(cy + 3)):
            for col in range(int(cx - ancho * 1.4), int(cx + ancho * 1.4) + 1):
                l = max(1 - math.hypot((col - x) / rx, (fila - y) * 2 / rx) for x, y, rx in centros)
                if fila > cy + .6 or l <= 0 or r.random() > .9:
                    continue
                arriba = np.clip(cy - fila, 0, 3) / 3                       # la parte de arriba la pinta la luna
                celdas.append((col, fila, " .:-~="[min(5, 1 + int(l * 5))],
                               np.array([150, 120, 108.0]) * (1 - arriba) + np.array([236, 214, 186.0]) * arriba))
        out.append([(c, f, ch, rgb * (.55 + .3 * r.random())) for c, f, ch, rgb in celdas])
    return out


def fondo():
    """Capa fija: luna, cielo con puntitos, estrellas y el piso nevado en perspectiva."""
    lz = Lienzo()
    luna(lz)
    luna_cel = lz.celdas()

    piso = []
    for fila in range(int(FY) - 4, FILAS):
        for col in range(COLS):
            z = (fila + .5 - FY) * CH / (SA * K)
            x = (col + .5 - CX) * CW / K
            if abs(z) > 1.7:
                continue
            d = math.hypot(x / 3.3, z / 1.7)
            l = .62 * (1 - d) + .1 * math.sin(col * 1.7) * math.sin(fila * 2.3) + rng.normal(0, .07)
            if l > .04:
                car = ".,:"[min(int(l * 7), 2)]
                calor = max(0.0, 1 - math.hypot(x / 1.6, z / 1.2))           # la luz dorada del árbol en la nieve
                rgb = np.array([190, 168, 150.0]) * (1 - calor) + np.array([255, 206, 120.0]) * calor
                piso.append((col, fila, car, rgb * (.5 + l)))

    cielo = []
    for fila in range(int(FY) - 4):
        for col in range(COLS):
            v = math.sin(col * .31 + fila * .7) * math.sin(col * .13 - fila * .45) + rng.normal(0, .5)
            if v > .8:
                cielo.append((col, fila, ".:,'"[int(rng.integers(4))], np.array([120, 92, 82.0]) * (.8 + .3 * rng.random())))
    estrellas = []
    for _ in range(60):
        col, fila = int(rng.integers(COLS)), int(rng.integers(int(FY) - 6))
        estrellas.append((col, fila, "*+*.+"[int(rng.integers(5))], np.array([255, 236, 200.0]) * (.6 + .4 * rng.random()), int(rng.integers(3))))
    for _ in range(24):                               # destellos en la nieve
        col, fila = int(rng.integers(COLS)), int(rng.integers(int(FY) - 1, FILAS))
        estrellas.append((col, fila, "*", np.array([255, 240, 205.0]), int(rng.integers(3))))
    return luna_cel, piso, cielo, estrellas


def rayos_estrella():
    col, fila, _ = proyectar(0, YE, 0)
    out = []
    for dx, dy, largo in ((1, 0, 15), (-1, 0, 15), (0, -1, 6), (0, 1, 3), (1, -1, 6), (-1, -1, 6), (1, 1, 5), (-1, 1, 5)):
        for k in range(3 if dx and dy else 5 if dx else 3, largo + 1):
            l = 1 - k / (largo + 1.5)
            car = RAMPA[max(1, min(9, int(l * 9)))]
            out.append((int(col + dx * k * (2 if dx and dy else 1.0)), int(fila + dy * k * (.6 if dx else 1)),
                        car, dorado(np.array(.55 + .45 * l)), (dx + 2 * dy) % 3))
    return out


# ───────────────────────── cuadros de la animación ─────────────────────────
def cuadros():
    """Regresa los cuadros de la intro (el árbol crece) y del bucle (una vuelta completa)."""
    intro, bucle = [], []
    for i in range(N_INTRO):
        t = i / FPS
        lz = Lienzo()
        p = min(1.0, t / (T_ARBOL - .25))
        arbol(lz, math.radians(i * PASO), p * p * (3 - 2 * p))
        intro.append(dict(giro=i * PASO, arbol=lz.celdas()))
    for j in range(N_BUCLE):
        g = (N_INTRO + j) * PASO
        lz = Lienzo()
        arbol(lz, math.radians(g))
        sin_luces = lz.celdas()
        halos = luces(lz, math.radians(g), j)
        estrella(lz, math.radians(g))
        cel = lz.celdas()
        es_estrella, es_luz = cel[4] == 1, (cel[4] == 2) | (cel[4] == 3)
        tapadas = set(zip(cel[0][es_luz].tolist(), cel[1][es_luz].tolist()))
        debajo = np.array([(c, f) in tapadas for c, f in zip(sin_luces[0].tolist(), sin_luces[1].tolist())], bool)
        bucle.append(dict(
            giro=g % 360,
            arbol=tuple(a[~es_estrella & ~es_luz] for a in cel),
            luces=tuple(a[es_luz] for a in cel),
            debajo=tuple(a[debajo] for a in sin_luces),
            estrella=tuple(a[es_estrella] for a in cel),
            esferas=esferas(lz, math.radians(g)),
            halos=halos,
        ))
    return intro, bucle


def capa_regalos():
    lz = Lienzo()
    regalos(lz)
    return lz.celdas(rampa=" .:-=+*#%@", minimo=4)


# ═════════════════════════ exportar a SVG ═════════════════════════
W = COLS * CW + 48
X0, Y0_ESC = 24, 42
H_TOTAL = 1124
FONDO_ESC, FONDO_ED = "#22120f", "#2e1915"


def hexq(rgb):
    q = np.clip(np.rint(np.asarray(rgb, dtype=float) / 17), 0, 15).astype(int)
    return "#%x%x%x" % tuple(q)


def texto_celdas(cols, filas, cars, rgbs, extra=""):
    """Agrupa las celdas por color: un <text> por color con posiciones x/y por carácter."""
    grupos = {}
    for c, f, ch, rgb in zip(cols, filas, cars, rgbs):
        grupos.setdefault(hexq(rgb), []).append((int(c), int(f), ch))
    out = []
    for color, lst in grupos.items():
        xs = " ".join(str(c * CW) for c, _, _ in lst)
        ys = " ".join(str(f * CH + 13) for _, f, _ in lst)
        txt = "".join(ch for _, _, ch in lst).replace("&", "&amp;").replace("<", "&lt;")
        out.append(f'<text fill="{color}" x="{xs}" y="{ys}"{extra}>{txt}</text>')
    return "".join(out)


HALO = {"R": ROJO, "Y": ORO, "S": PLATA, "W": CALIDO, "B": AZUL, "G": VERDE, "P": ROSA, "A": np.array([255, 150, 60.0])}


def marcas_svg(marcas):
    """Esferas/luces: fondo que tapa la rama, halo de luz y el carácter encima."""
    por_grupo = {}
    for m in marcas:
        por_grupo.setdefault(m[6], []).append(m)
    out = []
    for grupo, lst in sorted(por_grupo.items()):
        rects = "".join(f'<rect x="{c * CW}" y="{f * CH}" width="{CW}" height="{CH}"/>' for c, f, *_ in lst)
        halos = "".join(
            f'<circle cx="{c * CW + 4.5}" cy="{f * CH + 9}" r="{8 + 9 * b:.0f}" fill="url(#h{k})" opacity="{min(1, .25 + .75 * b):.2f}"/>'
            for c, f, _, _, k, b, _ in lst if b > .45)
        txt = texto_celdas([m[0] for m in lst], [m[1] for m in lst], [m[2] for m in lst], [m[3] for m in lst])
        out.append(f'<g class="{grupo}"><g fill="{FONDO_ESC}">{rects}</g>{halos}{txt}</g>')
    return "".join(out)


def resaltar(linea):
    """Colorea una línea de Python como un editor (tema oscuro)."""
    patron = re.compile(r"(#.*$)|(f?\"[^\"]*\"|f?'[^']*')|(\b\d+\.?\d*\b|\.\d+)|"
                        r"\b(def|for|in|if|else|elif|return|import|from|while|try|except|finally|with|as|not|and|or|lambda|True|False|None|class)\b|"
                        r"([A-Za-z_]\w*)(?=\()")
    out, pos = [], 0
    for m in patron.finditer(linea):
        if m.start() > pos:
            out.append((linea[pos:m.start()], "#d4d4d4"))
        color = ["#6a9955", "#ce9178", "#b5cea8", "#c586c0", "#dcdcaa"][m.lastindex - 1]
        if m.lastindex == 4 and m.group(4) in ("def", "class", "lambda", "True", "False", "None", "and", "or", "not", "in"):
            color = "#569cd6"
        out.append((m.group(0), color))
        pos = m.end()
    if pos < len(linea):
        out.append((linea[pos:], "#d4d4d4"))
    return out


def paginas_codigo():
    """Toma fragmentos reales de este mismo archivo, uno por cada parte del dibujo."""
    lineas = Path(__file__).read_text(encoding="utf-8").splitlines()
    marcas = {m.group(1): i for i, l in enumerate(lineas) if (m := re.match(r"^# ── (\d) · ", l))}
    tiempos = [0.0, T_ESTRELLA, T_ESFERAS, T_LUCES, T_REGALOS, T_NIEVE, T_TRINEO, T_TERMINAL]
    paginas = []
    for n, t in enumerate(tiempos, start=1):
        i = marcas[str(n)]
        bloque = [(i + k + 1, lineas[i + k][:96].replace("─", "-")) for k in range(8) if i + k < len(lineas)]
        fin = tiempos[n] if n < len(tiempos) else None
        paginas.append((t, fin, bloque))
    return paginas


# ── 6 · nieve ─────────────────────────────────────────────
def nieve_svg(n=60):
    r = np.random.default_rng(6)
    copos = []
    for _ in range(n):
        dur = r.uniform(5, 11)
        x = r.uniform(0, COLS * CW)
        copos.append(f'<text class="cp" x="{x:.0f}" y="-8" fill="#fff" opacity="{r.uniform(.35, .95):.2f}" '
                     f'style="animation-duration:{dur:.2f}s;animation-delay:{-r.uniform(0, dur):.2f}s">{"*.*·"[r.integers(4)]}</text>')
    return f'<g class="nieve">{"".join(copos)}</g>'


# ── 7 · trineo ────────────────────────────────────────────
def trineo_silueta():
    """El trineo de Santa (el mismo del pixel art) como silueta contra la luna, en dos cuadros de galope."""
    import personajes
    t = personajes.trineo(con_contorno=False)
    cuadros_t = []
    for patas in ("patas0", "patas1"):                # las patitas de los renos van y vienen
        px = set(t.capas["base"]) | set(t.capas[patas])
        d = []
        for y in range(t.h):
            xs = sorted(x for x, yy in px if yy == y)
            if xs:
                ini = prev = xs[0]
                for x in xs[1:] + [None]:
                    if x is not None and x == prev + 1:
                        prev = x
                        continue
                    d.append(f"M{ini} {y}h{prev - ini + 1}v1h{ini - prev - 1}z")
                    if x is not None:
                        ini = prev = x
        cuadros_t.append("".join(d))
    return cuadros_t, t.w, t.h


def svg():
    intro, bucle = cuadros()
    luna_cel, piso, cielo, estrellas = fondo()
    cr, ff, cc, crgb, ctag = capa_regalos()
    patches = nubes()

    # Celdas que alguna vez ocupa el árbol/regalos: ahí no se dibuja fondo (no se encimen letras)
    ocupado = np.zeros((FILAS, COLS), bool)
    for q in intro + bucle:
        ocupado[q["arbol"][1], q["arbol"][0]] = True
        if "estrella" in q:
            ocupado[q["estrella"][1], q["estrella"][0]] = True
    ocupado[ff, cr] = True
    rayos = [r for r in rayos_estrella() if 0 <= r[0] < COLS and 0 <= r[1] < FILAS and not ocupado[r[1], r[0]]]
    for r in rayos:
        ocupado[r[1], r[0]] = True
    pl = [(c, f, ch, rgb) for c, f, ch, rgb, _ in zip(*luna_cel)]
    for c, f, *_ in pl:
        ocupado[f, c] = True
    luna_ocupa = ocupado.copy()
    for c, f, *_ in pl:
        for dc in (-2, -1, 0, 1, 2):
            if 0 <= c + dc < COLS:
                luna_ocupa[f, c + dc] = True
    patches = [[p for p in nube if 0 <= p[0] < COLS and 0 <= p[1] < FILAS and not luna_ocupa[p[1], p[0]]] for nube in patches]
    for nube in patches:
        for p in nube:
            ocupado[p[1], p[0]] = True
    piso = [p for p in piso if not ocupado[p[1], p[0]]]
    cielo = [p for p in cielo if not ocupado[p[1], p[0]]]
    estrellas = [p for p in estrellas if not ocupado[p[1], p[0]]]

    fd = 1 / FPS
    T_vuelta = N_BUCLE * fd
    css = [
        "@font-face{font-family:'JB';src:url(data:font/woff2;base64,"
        + base64.b64encode(FUENTE.read_bytes()).decode() + ") format('woff2');}",
        "text{font-family:'JB','JetBrains Mono','DejaVu Sans Mono',Menlo,monospace;white-space:pre}",
        ".fi,.fl{visibility:hidden}",
        f".fi{{animation:uno {fd:.4f}s linear}}@keyframes uno{{0%,100%{{visibility:visible}}}}",
        f".fl{{animation:vuelta {T_vuelta:.4f}s linear infinite}}"
        f"@keyframes vuelta{{0%{{visibility:visible}}{100 / N_BUCLE:.4f}%,100%{{visibility:hidden}}}}",
        ".ap{animation:ap .01s linear both}@keyframes ap{from{opacity:0}to{opacity:1}}",
        ".oc{animation:oc .01s linear both}@keyframes oc{from{opacity:1}to{opacity:0}}",
        f".es{{transform-origin:{proyectar(0, YE, 0)[0] * CW:.0f}px {proyectar(0, YE, 0)[1] * CH:.0f}px;"
        f"animation:pop .6s cubic-bezier(.3,1.6,.5,1) {T_ESTRELLA}s both}}"
        "@keyframes pop{from{transform:scale(0)}to{transform:scale(1)}}",
        f".rayos{{animation:ap .01s linear {T_ESTRELLA + .3}s both}}",
        ".ry0{animation:ry 1.3s ease-in-out infinite}.ry1{animation:ry 1.7s ease-in-out -.6s infinite}"
        ".ry2{animation:ry 1.1s ease-in-out -.3s infinite}@keyframes ry{50%{opacity:.35}}",
        ".tw0{animation:tw 2.4s ease-in-out infinite}.tw1{animation:tw 3.1s ease-in-out -1s infinite}"
        ".tw2{animation:tw 1.9s ease-in-out -.5s infinite}@keyframes tw{50%{opacity:.2}}",
        f".nieve{{animation:ap .01s linear {T_NIEVE}s both}}",
        ".cp{animation-name:cae;animation-timing-function:linear;animation-iteration-count:infinite}"
        f"@keyframes cae{{to{{transform:translate(18px,{FILAS * CH + 16}px)}}}}",
        f".trineo{{opacity:0;animation:trineo 18s linear {T_TRINEO}s infinite}}"
        "@keyframes trineo{0%{opacity:1;transform:translate(-250px,215px)}"
        f"32%{{opacity:1;transform:translate({LUNA[0] * CW + 4 - 50 * ESC_TRINEO:.0f}px,{LUNA[1] * CH - 4 - 14 * ESC_TRINEO:.0f}px)}}"
        "46%{opacity:1;transform:translate(230px,-95px)}46.1%,100%{opacity:0;transform:translate(230px,-95px)}}"
        ".bob{animation:bob 1.3s ease-in-out infinite alternate}@keyframes bob{to{transform:translateY(7px)}}",
        ".patA{animation:patA .36s steps(1) infinite}@keyframes patA{50%{opacity:0}}"
        ".patB{animation:patB .36s steps(1) infinite}@keyframes patB{0%{opacity:0}50%{opacity:1}}",
        ".nb0{animation:nube 38s ease-in-out infinite alternate}.nb1{animation:nube 31s ease-in-out -9s infinite alternate}"
        ".nb2{animation:nube 44s ease-in-out -20s infinite alternate}@keyframes nube{from{transform:translateX(-14px)}to{transform:translateX(14px)}}",
        f".hadas{{animation:ap .01s linear {T_LUCES}s both}}.sinluz{{animation:oc .01s linear {T_LUCES}s both}}",
        ".late{animation:lateE 2.2s ease-in-out infinite}@keyframes lateE{50%{opacity:.6;transform:scale(1.12)}}",
    ]
    for k in range(4):
        css.append(f".o{k}{{animation:ap .01s linear {T_ESFERAS + k * .3:.2f}s both}}")

    defs = [f'<clipPath id="esc"><rect width="{COLS * CW}" height="{FILAS * CH}"/></clipPath>',
            '<filter id="filo" x="-10%" y="-40%" width="120%" height="180%"><feMorphology in="SourceAlpha" operator="dilate" radius=".55" result="d"/>'
            '<feFlood flood-color="#ffd88a" flood-opacity=".75"/><feComposite in2="d" operator="in" result="o"/>'
            '<feGaussianBlur in="o" stdDeviation=".45" result="g"/><feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge></filter>']
    for k, c in HALO.items():
        defs.append(f'<radialGradient id="h{k}"><stop offset="0" stop-color="{hexq(c)}" stop-opacity=".7"/>'
                    f'<stop offset=".4" stop-color="{hexq(c)}" stop-opacity=".22"/>'
                    f'<stop offset="1" stop-color="{hexq(c)}" stop-opacity="0"/></radialGradient>')
    defs.append('<radialGradient id="brilloArbol"><stop offset="0" stop-color="#ffc04d" stop-opacity=".34"/>'
                '<stop offset=".55" stop-color="#ff9a3c" stop-opacity=".12"/>'
                '<stop offset="1" stop-color="#ff9a3c" stop-opacity="0"/></radialGradient>')
    defs.append('<radialGradient id="brilloLuna"><stop offset="0" stop-color="#fff3d6" stop-opacity=".38"/>'
                '<stop offset=".5" stop-color="#ffe2b0" stop-opacity=".1"/>'
                '<stop offset="1" stop-color="#ffe2b0" stop-opacity="0"/></radialGradient>')
    defs.append('<radialGradient id="brilloEstrella"><stop offset="0" stop-color="#ffe07a" stop-opacity=".7"/>'
                '<stop offset=".35" stop-color="#ffb52e" stop-opacity=".16"/>'
                '<stop offset="1" stop-color="#ffb52e" stop-opacity="0"/></radialGradient>')

    c_est, f_est, _ = proyectar(0, YE, 0)
    c_arb, f_arb, _ = proyectar(0, Y0 + ALTO * .4, 0)
    esc = [f'<g transform="translate({X0} {Y0_ESC})" clip-path="url(#esc)">',
           f'<ellipse cx="{c_arb * CW:.0f}" cy="{f_arb * CH:.0f}" rx="420" ry="400" fill="url(#brilloArbol)"/>',
           f'<circle cx="{LUNA[0] * CW:.0f}" cy="{LUNA[1] * CH:.0f}" r="250" fill="url(#brilloLuna)"/>',
           texto_celdas(*zip(*cielo)) if cielo else "",
           "".join(texto_celdas([c], [f], [ch], [rgb], f' class="tw{tw}"') for c, f, ch, rgb, tw in estrellas),
           texto_celdas(*zip(*pl)),
           "".join(f'<g class="nb{k % 3}">{texto_celdas(*zip(*nube))}</g>' for k, nube in enumerate(patches) if nube),
           texto_celdas(*zip(*piso))]
    # el trineo de Santa cruza frente a la luna: silueta con un filito de luz y estela de destellos
    (pata_a, pata_b), tw_, th_ = trineo_silueta()
    estela = "".join(f'<text class="tw{k % 3}" x="{-k * 15}" y="{44 + 9 * math.sin(k * 1.3):.0f}" fill="#ffe08a" '
                     f'opacity="{1 - k / 12:.2f}">{"*+.*"[k % 4]}</text>' for k in range(1, 11))
    esc.append(f'<g class="trineo"><g class="bob">{estela}<g transform="scale({ESC_TRINEO})" fill="#170b09" filter="url(#filo)">'
               f'<path class="patA" d="{pata_a}"/><path class="patB" d="{pata_b}"/></g></g></g>')
    esc.append(f'<g class="rayos"><circle class="late" style="transform-origin:{c_est * CW:.0f}px {f_est * CH:.0f}px" '
               f'cx="{c_est * CW:.0f}" cy="{f_est * CH:.0f}" r="125" fill="url(#brilloEstrella)"/>')
    for k in range(3):
        sel = [r for r in rayos if r[4] == k]
        if sel:
            esc.append(f'<g class="ry{k}">{texto_celdas(*zip(*[r[:4] for r in sel]))}</g>')
    esc.append("</g>")

    # Cuadros: la intro se ve una vez y el bucle da vueltas para siempre
    st_y = Y0_ESC + FILAS * CH + 22
    for i, q in enumerate(intro):
        esc.append(f'<g class="fi" style="animation-delay:{i * fd:.4f}s">{texto_celdas(*q["arbol"][:4])}</g>')
    giros = []
    for j, q in enumerate(bucle):
        esc.append(
            f'<g class="fl{" f0" if j == 0 else ""}" style="animation-delay:{T_ARBOL + j * fd:.4f}s">{texto_celdas(*q["arbol"][:4])}'
            f'<g class="sinluz">{texto_celdas(*q["debajo"][:4])}</g><g class="hadas">{texto_celdas(*q["luces"][:4])}</g>'
            f'<g class="es">{texto_celdas(*q["estrella"][:4])}</g>{marcas_svg(q["esferas"])}'
            f'<g class="hadas">{"".join(f"""<circle cx="{c * CW + 4.5}" cy="{f * CH + 9}" r="{7 + 9 * b:.0f}" fill="url(#h{k})" opacity="{b:.2f}"/>""" for c, f, k, b in q["halos"])}</g></g>')
    for i, q in enumerate(intro):
        giros.append(f'<text class="fi" style="animation-delay:{i * fd:.4f}s" x="{X0}" y="{st_y}" fill="#b08f78" font-size="13">giro {q["giro"]:5.1f}°</text>')
    for j, q in enumerate(bucle):
        giros.append(f'<text class="fl{" f0" if j == 0 else ""}" style="animation-delay:{T_ARBOL + j * fd:.4f}s" x="{X0}" y="{st_y}" fill="#b08f78" font-size="13">giro {q["giro"]:5.1f}°</text>')

    # Regalos que caen uno por uno (tapan lo que tengan detrás)
    for g in range(len(REGALOS)):
        m = ctag == g
        rects = "".join(f'<rect x="{c * CW}" y="{f * CH}" width="{CW}" height="{CH}"/>' for c, f in zip(cr[m], ff[m]))
        esc.append(f'<g style="animation:caida .9s cubic-bezier(.5,0,.7,1) {T_REGALOS + g * .28:.2f}s both">'
                   f'<g fill="{FONDO_ESC}">{rects}</g><g fill="{hexq(REGALOS[g][6])}" opacity=".26">{rects}</g>'
                   f'{texto_celdas(cr[m], ff[m], cc[m], crgb[m])}</g>')
    css.append("@keyframes caida{0%{transform:translateY(-460px);opacity:0}1%{opacity:1}"
               "70%{transform:translateY(0)}84%{transform:translateY(-12px)}100%{transform:translateY(0)}}")
    esc.append(nieve_svg() + "</g>")
    escena = esc

    # Barra de título y estado
    cab = (f'<rect width="{W}" height="{H_TOTAL}" rx="22" fill="{FONDO_ESC}"/>'
           f'<text x="{X0}" y="27" fill="#e2c3a4" font-size="14">arte.py  <tspan fill="#8a6452">·</tspan>  Christmas Tree</text>'
           f'<text x="{W - X0}" y="27" fill="#b08f78" font-size="14" text-anchor="end">Cheque2305</text>')
    hitos = [(0, 0)] + [(round(t, 2), int(45 * t / T_ARBOL)) for t in np.arange(.2, T_ARBOL, .2)] + [
        (T_ESTRELLA, 52), (T_ESFERAS, 66), (T_LUCES, 79), (T_REGALOS, 89), (T_NIEVE, 95), (T_TRINEO, 100)]
    cons = []
    for k, (t, p) in enumerate(hitos):
        fin = hitos[k + 1][0] if k + 1 < len(hitos) else None
        estilo = (f"animation:uno {fin - t:.2f}s linear {t:.2f}s" if fin else f"animation:ap .01s linear {t:.2f}s both")
        vis = "visibility:hidden;" if fin else ""
        cons.append(f'<text style="{vis}{estilo}" x="{X0 + 15 * 7.8:.0f}" y="{st_y}" fill="#b08f78" font-size="13">construido {p}%</text>')
    y2 = st_y + 28
    estado = (f'<text x="{X0}" y="{y2}" fill="#fff1e0">$ python3 arte.py</text>'
              f'<g class="oc" style="animation-delay:{T_LISTO}s"><circle cx="{W - X0 - 158}" cy="{y2 - 5}" r="4.5" fill="#ffb347"/>'
              f'<text x="{W - X0}" y="{y2}" fill="#d6b59a" font-size="13" text-anchor="end">decorando · {FPS} fps</text></g>'
              f'<g class="ap" style="animation-delay:{T_LISTO}s"><circle cx="{W - X0 - 205}" cy="{y2 - 5}" r="4.5" fill="#5fe07a"/>'
              f'<text x="{W - X0}" y="{y2}" fill="#d6b59a" font-size="13" text-anchor="end">¡quedó precioso! · {FPS} fps</text></g>')

    # Editor con el código tecleándose
    ye = y2 + 16
    ed = [f'<path d="M0 {ye}H{W}V{H_TOTAL - 22}a22 22 0 0 1-22 22H22a22 22 0 0 1-22-22Z" fill="{FONDO_ED}"/>',
          f'<text x="{X0 + 16}" y="{ye + 24}" fill="#f3e3d0" font-size="14">arte.py</text>',
          f'<rect x="{X0}" y="{ye + 32}" width="90" height="2" fill="#ffcf5a"/>',
          f'<line x1="0" y1="{ye + 38.5}" x2="{W}" y2="{ye + 38.5}" stroke="#4a2a22"/>']
    cwc = 8.4
    teclas_css = []
    for p, (t0, t1, bloque) in enumerate(paginas_codigo()):
        if t1 is None:
            vent = f"visibility:hidden;animation:ap2 .01s linear {t0:.2f}s both"
        else:
            vent = f"visibility:hidden;animation:uno {t1 - t0:.2f}s linear {t0:.2f}s"
        clase = ' class="ult"' if t1 is None else ""
        partes = [f'<g{clase} style="{vent}">',
                  f'<text x="{W - X0}" y="{ye + 24}" fill="#b08f78" font-size="13" text-anchor="end">Ln {bloque[-1][0]}</text>']
        n = len(bloque)
        for k, (num, linea) in enumerate(bloque):
            y = ye + 62 + k * 21
            tk = t0 + .07 * k
            partes.append(f'<text class="ap" style="animation-delay:{tk:.2f}s" x="{X0 + 30}" y="{y}" fill="#8a6a58" '
                          f'font-size="13" text-anchor="end">{num}</text>')
            tsp = "".join(f'<tspan fill="{c}">{s.replace("&", "&amp;").replace("<", "&lt;")}</tspan>' for s, c in resaltar(linea))
            largo = max(len(linea), 1)
            txt = (f'<text x="{X0 + 46}" y="{y}" font-size="14" textLength="{largo * cwc:.1f}" '
                   f'lengthAdjust="spacing">{tsp}</text>')
            if k < n - 1:
                partes.append(f'<g class="ap" style="animation-delay:{tk:.2f}s">{txt}</g>')
            else:  # la última línea se teclea letra por letra
                dur = min(.028 * largo, max(.3, (t1 or t0 + 1.6) - tk - .25))
                # un paso extra: así el redondeo al final del tecleo nunca deja la última letra tapada
                teclas_css.append(f"@keyframes tc{p}{{from{{transform:translateX(0)}}to{{transform:translateX({(largo + 1) * cwc:.1f}px)}}}}")
                xi = X0 + 46
                partes.append(
                    f'<g class="ap" style="animation-delay:{tk:.2f}s">{txt}'
                    f'<g style="animation:tc{p} {dur * (largo + 1) / largo:.2f}s steps({largo + 1},end) {tk:.2f}s both">'
                    f'<rect x="{xi + cwc:.1f}" y="{y - 15}" width="{largo * cwc + 20:.1f}" height="20" fill="{FONDO_ED}"/>'
                    f'<rect x="{xi:.1f}" y="{y - 13}" width="{cwc:.1f}" height="17" fill="#d4d4d4" opacity=".85"/></g></g>')
        partes.append("</g>")
        ed.append("".join(partes))
    css.append("@keyframes ap2{from{visibility:hidden}to{visibility:visible}}")
    css.extend(teclas_css)
    css.append("@media (prefers-reduced-motion: reduce){*{animation:none!important}.f0{visibility:visible}.ult{visibility:visible!important}}")

    doc = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H_TOTAL}" viewBox="0 0 {W} {H_TOTAL}" font-size="15" '
           f'role="img" aria-label="Christmas Tree: árbol de Navidad 3D en arte ASCII que gira, con luces, regalos, luna llena y el trineo de Santa">'
           f'<title>Christmas Tree</title><defs>{"".join(defs)}</defs><style>{"".join(css)}</style>'
           f'{cab}{"".join(escena)}{"".join(giros)}{"".join(cons)}{estado}{"".join(ed)}</svg>')
    return doc


# ── 8 · terminal ──────────────────────────────────────────
def en_terminal():
    intro, bucle = cuadros()
    luna_cel, piso, cielo, estrellas = fondo()
    regalo = capa_regalos()
    sys.stdout.write("\x1b[?25l\x1b[2J")
    t0, k = time.time(), 0
    try:
        while True:
            q = intro[k] if k < N_INTRO else bucle[(k - N_INTRO) % N_BUCLE]
            t = k / FPS
            celda = {}
            for c, f, ch, rgb, *_ in [*cielo, *estrellas, *piso, *zip(*luna_cel)]:
                celda[(f, c)] = (ch, rgb)
            for capa in [q["arbol"], q.get("estrella")] + ([regalo] if t > T_REGALOS else []):
                if capa is not None:
                    for c, f, ch, rgb, *_ in zip(*capa):
                        celda[(f, c)] = (ch, rgb)
            for m in q.get("esferas", []) * (t > T_ESFERAS):
                celda[(m[1], m[0])] = (m[2], m[3])
            out = ["\x1b[H"]
            for f in range(FILAS):
                for c in range(COLS):
                    ch, rgb = celda.get((f, c), (" ", None))
                    if rgb is None:
                        out.append(" ")
                        continue
                    r, g, b = (int(v) for v in np.clip(rgb, 0, 255))
                    out.append(f"\x1b[38;2;{r};{g};{b}m{ch}")
                out.append("\x1b[0m\n")
            out.append(f"giro {q['giro']:5.1f}°   t {t:5.2f}s   Ctrl+C para salir")
            sys.stdout.write("".join(out))
            sys.stdout.flush()
            k += 1
            time.sleep(max(0, k / FPS - (time.time() - t0)))
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\x1b[0m\x1b[?25h\n")


if __name__ == "__main__":
    if "--terminal" in sys.argv:
        en_terminal()
    else:
        ASSETS.mkdir(exist_ok=True)
        doc = svg()
        (ASSETS / "arbol-ascii.svg").write_text(doc, encoding="utf-8")
        print(f"assets/arbol-ascii.svg  ({len(doc.encode()) / 1e6:.2f} MB, {N_INTRO + N_BUCLE} cuadros)")
        # para la página: solo la escena (sin barra ni editor), como un cuadro
        ew, eh = COLS * CW, FILAS * CH
        escena = doc.replace(f'width="{W}" height="{H_TOTAL}" viewBox="0 0 {W} {H_TOTAL}"',
                             f'width="{ew}" height="{eh}" viewBox="{X0} {Y0_ESC} {ew} {eh}"', 1)
        (ASSETS / "arbol-escena.svg").write_text(escena, encoding="utf-8")
        print("assets/arbol-escena.svg  (solo la escena, para la página)")
