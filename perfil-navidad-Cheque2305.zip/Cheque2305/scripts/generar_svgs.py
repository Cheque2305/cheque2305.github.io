#!/usr/bin/env python3
"""Genera los SVG animados del perfil navideño (ceros y unos, pero calientito).

Edita la sección CONFIGURACIÓN y vuelve a correr:
    python3 scripts/generar_svgs.py

Crea en assets/: banner.svg, guirnalda.svg y serpiente-navidad.svg (marcador
temporal hasta que corra el Action). El Christmas Tree lo genera arte.py y
La Villa de Santa, personajes.py.
"""
import math
import random

from comun import (ASSETS, AZUL, BORDE, CW, FONDO, ORO, ROJO, ROSA, VERDE,
                   VERDE2, a_binario, ancho, esc, fuente_pixel_css, halos,
                   patron_scanlines, svg_doc)

# ───────────────────────── CONFIGURACIÓN ─────────────────────────
PROMPT = "cheque@navidad"
TITULO = "FELIZ NAVIDAD"
SUBTITULO = "QUE NO TE FALTEN LOS TAMALES NI LOS ABRAZOS"
LINEA_CODIGO = "while (haya_ponche) { abrazar(); brindar(); otro_tamal(); }"

# ──────────────────────────────────────────────────────────────────

COLORES_FOCO = [("R", ROJO), ("Y", ORO), ("G", VERDE), ("B", AZUL), ("P", ROSA)]


def guirnalda(W, y0, caida, tramo, por_tramo, escala=1.0, offset=0):
    """Cable con foquitos que cuelga en arcos. Regresa (svg, n_focos)."""
    xs = list(range(0, W + tramo, tramo))
    d = f"M{-20} {y0} L{xs[0]} {y0}"
    focos = []
    idx = offset
    for x0, x1 in zip(xs, xs[1:]):
        xm, ym = (x0 + x1) / 2, y0 + 2 * caida
        d += f" Q{xm} {ym} {x1} {y0}"
        for k in range(por_tramo):
            t = (k + 0.5) / por_tramo
            px = (1 - t) ** 2 * x0 + 2 * (1 - t) * t * xm + t * t * x1
            py = (1 - t) ** 2 * y0 + 2 * (1 - t) * t * ym + t * t * y0
            # inclinación siguiendo el cable
            dx = 2 * (1 - t) * (xm - x0) + 2 * t * (x1 - xm)
            dy = 2 * (1 - t) * (ym - y0) + 2 * t * (y0 - ym)
            ang = math.degrees(math.atan2(dy, dx)) * 0.5
            letra, color = COLORES_FOCO[idx % len(COLORES_FOCO)]
            s = escala
            focos.append(
                f'<g class="fq b{idx % 4}" transform="translate({px:.1f} {py:.1f}) rotate({ang:.1f})">'
                f'<circle cx="0" cy="{11*s:.1f}" r="{17*s:.1f}" fill="url(#halo{letra})"/>'
                f'<rect x="{-3*s:.1f}" y="-1" width="{6*s:.1f}" height="{5*s:.1f}" rx="1" fill="#2d3a2f"/>'
                f'<ellipse cx="0" cy="{11*s:.1f}" rx="{4.6*s:.1f}" ry="{7.2*s:.1f}" fill="{color}"/>'
                f'<ellipse cx="{-1.4*s:.1f}" cy="{8.5*s:.1f}" rx="{1.3*s:.1f}" ry="{2.4*s:.1f}" fill="#fff" opacity=".55"/>'
                "</g>"
            )
            idx += 1
    cable = f'<path d="{d}" fill="none" stroke="#2e6b3a" stroke-width="{2.2*escala:.1f}"/>'
    return cable + "".join(focos), idx - offset


CSS_FOCOS = (
    ".fq{animation:foco 1.8s ease-in-out infinite}"
    ".b1{animation-delay:-.45s}.b2{animation-delay:-.9s}.b3{animation-delay:-1.35s}"
    "@keyframes foco{0%,100%{opacity:1}50%{opacity:.22}}"
)


def nieve(rnd, W, H, n, y_ini=-10, op=(0.35, 0.9), r=(0.8, 2.3), dur=(7, 15)):
    out = []
    for _ in range(n):
        x = rnd.uniform(0, W)
        d = rnd.uniform(*dur)
        out.append(
            f'<g class="nv" style="animation-duration:{d:.2f}s;animation-delay:{-rnd.uniform(0, d):.2f}s">'
            f'<circle class="v{rnd.randint(1, 3)}" cx="{x:.1f}" cy="{y_ini}" r="{rnd.uniform(*r):.1f}" '
            f'fill="#fff" opacity="{rnd.uniform(*op):.2f}" '
            f'style="animation-duration:{rnd.uniform(2.2, 4.5):.2f}s"/></g>'
        )
    css = (
        ".nv{animation-name:nevar;animation-timing-function:linear;animation-iteration-count:infinite}"
        f"@keyframes nevar{{from{{transform:translateY(0)}}to{{transform:translateY({H - y_ini + 20}px)}}}}"
        ".v1,.v2,.v3{animation-timing-function:ease-in-out;animation-iteration-count:infinite;animation-direction:alternate}"
        ".v1{animation-name:va1}.v2{animation-name:va2}.v3{animation-name:va3}"
        "@keyframes va1{from{transform:translateX(-6px)}to{transform:translateX(6px)}}"
        "@keyframes va2{from{transform:translateX(10px)}to{transform:translateX(-10px)}}"
        "@keyframes va3{from{transform:translateX(-15px)}to{transform:translateX(15px)}}"
    )
    return "".join(out), css


# ═══════════════════════════ BANNER ═══════════════════════════
def banner():
    W, H = 1200, 340
    rnd = random.Random(2026)
    defs, css, cuerpo = [], [], []

    defs.append(f'<clipPath id="tarjeta"><rect width="{W}" height="{H}" rx="22"/></clipPath>')
    defs.append(patron_scanlines())
    defs.append(halos())
    for gid, color in (("gV", VERDE), ("gR", ROJO), ("gY", ORO), ("gC", "#fff1d6"),
                       ("gVb", "#c0603a"), ("gRb", "#d98a4a")):
        defs.append(
            f'<linearGradient id="{gid}" x1="0" y1="0" x2="0" y2="1">'
            f'<stop offset="0" stop-color="{color}" stop-opacity="0"/>'
            f'<stop offset=".55" stop-color="{color}" stop-opacity=".5"/>'
            f'<stop offset="1" stop-color="{color}"/></linearGradient>'
        )
    defs.append('<linearGradient id="cielo" x1="0" y1="0" x2="0" y2="1">'
                '<stop offset="0" stop-color="#6b1a26"/><stop offset="1" stop-color="#2c0a10"/></linearGradient>')
    defs.append('<radialGradient id="calor" cx=".5" cy=".6" r=".55">'
                '<stop offset="0" stop-color="#ffb347" stop-opacity=".28"/>'
                '<stop offset="1" stop-color="#ffb347" stop-opacity="0"/></radialGradient>')
    defs.append(
        '<radialGradient id="vineta" cx=".5" cy=".55" r=".5">'
        '<stop offset="0" stop-color="#2a070c" stop-opacity=".9"/>'
        '<stop offset=".62" stop-color="#2a070c" stop-opacity=".7"/>'
        '<stop offset="1" stop-color="#2a070c" stop-opacity="0"/></radialGradient>'
    )
    defs.append(
        '<linearGradient id="tit" x1="0" y1="0" x2="0" y2="1">'
        '<stop offset="0" stop-color="#fffaf0"/><stop offset="1" stop-color="#ffd98a"/></linearGradient>'
    )
    defs.append(
        '<filter id="brillo" x="-20%" y="-40%" width="140%" height="180%">'
        '<feGaussianBlur in="SourceAlpha" stdDeviation="6" result="b"/>'
        '<feFlood flood-color="#ff7a45" flood-opacity=".9"/>'
        '<feComposite in2="b" operator="in" result="g"/>'
        '<feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge></filter>'
    )

    cuerpo.append(f'<g clip-path="url(#tarjeta)"><rect width="{W}" height="{H}" fill="url(#cielo)"/>'
                  f'<rect width="{W}" height="{H}" fill="url(#calor)"/>')

    # ── Lluvia de ceros y unos en colores cálidos (dos capas para dar profundidad)
    capas = [
        dict(fs=12, dx=15, fila=14, Lmax=26, op=0.35, dur=(11, 20),
             colores=[("gVb", 0.6), ("gRb", 0.4)]),
        dict(fs=18, dx=25, fila=21, Lmax=20, op=0.6, dur=(7, 13),
             colores=[("gY", 0.35), ("gV", 0.3), ("gC", 0.2), ("gR", 0.15)]),
    ]
    for n, c in enumerate(capas):
        recorrido = H + c["Lmax"] * c["fila"]
        css.append(
            f".c{n}{{animation-name:caer{n};animation-timing-function:linear;animation-iteration-count:infinite}}"
            f"@keyframes caer{n}{{from{{transform:translateY(0)}}to{{transform:translateY({recorrido}px)}}}}"
        )
        cuerpo.append(f'<g opacity="{c["op"]}">')
        x = rnd.uniform(0, c["dx"] / 2)
        while x < W:
            L = rnd.randint(7, c["Lmax"])
            gid = rnd.choices([k for k, _ in c["colores"]], [w for _, w in c["colores"]])[0]
            d = rnd.uniform(*c["dur"])
            bits = "".join(rnd.choice("01") for _ in range(L))
            ys = " ".join(str(-(L - 1 - i) * c["fila"]) for i in range(L - 1))
            xs = " ".join([f"{x:.0f}"] * (L - 1))
            cuerpo.append(
                f'<g class="c{n}" style="animation-duration:{d:.2f}s;animation-delay:{-rnd.uniform(0, d):.2f}s">'
                f'<text class="m" font-size="{c["fs"]}" x="{xs}" y="{ys}" fill="url(#{gid})">{bits[:-1]}</text>'
                f'<text class="m" font-size="{c["fs"]}" x="{x:.0f}" y="0" fill="#fff6e0">{bits[-1]}</text></g>'
            )
            x += c["dx"] + rnd.uniform(-3, 3)
        cuerpo.append("</g>")

    # ── Nieve
    s, s_css = nieve(rnd, W, H, 52)
    css.append(s_css)
    cuerpo.append(s)

    # ── Viñeta cálida para que el título se lea
    cuerpo.append('<ellipse cx="600" cy="205" rx="560" ry="160" fill="url(#vineta)"/>')

    # ── Línea de comando con cursor
    cmd = "cheque@polo-norte:~$ sudo apt install espíritu-navideño"
    fs = 15
    w_cmd = ancho(len(cmd), fs)
    x_cmd = 600 - w_cmd / 2
    cuerpo.append(
        f'<text class="m" x="{x_cmd:.1f}" y="108" font-size="{fs}" textLength="{w_cmd:.1f}" '
        f'fill="{VERDE2}">{esc(cmd)}</text>'
        f'<rect class="cur" x="{x_cmd + w_cmd + 3:.1f}" y="{108 - fs * 0.78:.1f}" width="{CW*fs:.1f}" '
        f'height="{fs*0.95:.1f}" fill="{ORO}"/>'
    )
    css.append(".cur{animation:cur 1.05s steps(1) infinite}@keyframes cur{0%{opacity:1}50%{opacity:0}}")

    # ── Título en letras pixel que brincan una por una (ola)
    fs_t = 62
    y_t = 214
    paso = fs_t * 1.04
    w_t = paso * len(TITULO)
    x0 = 600 - w_t / 2
    css.append(fuente_pixel_css())
    letras = []
    for i, ch in enumerate(TITULO):
        if ch == " ":
            continue
        letras.append(
            f'<text class="px ola" style="animation-delay:{i * .09:.2f}s" x="{x0 + i * paso:.1f}" y="{y_t}" '
            f'font-size="{fs_t}">{esc(ch)}</text>')
    cuerpo.append(f'<g fill="#b3202f" transform="translate(5 5)">{"".join(letras)}</g>')
    cuerpo.append(f'<g fill="url(#tit)" filter="url(#brillo)">{"".join(letras)}</g>')
    css.append(".ola{animation:ola 2.6s ease-in-out infinite}"
               "@keyframes ola{0%,40%,100%{transform:translateY(0)}20%{transform:translateY(-10px)}}")

    # ── Gorrito de Santa en pixel art sobre la "F"
    gorro = [
        "........WW",
        "......RRWW",
        ".....RRRr.",
        "....RRRRr.",
        "...RRRRRr.",
        "..RRRRRRr.",
        ".RRRRRRRRr",
        "WWWWWWWWWW",
        "wWWWWWWWWw",
    ]
    px = 5.2
    x_g = x0 - 8
    y_g = y_t - fs_t * .875 - len(gorro) * px + 14
    pix = []
    for fy, fila in enumerate(gorro):
        for fx, ch in enumerate(fila):
            col = {"R": "#e3172f", "r": "#b80f24", "W": "#ffffff", "w": "#f3dccb"}.get(ch)
            if col:
                pix.append(f'<rect x="{fx*px:.1f}" y="{fy*px:.1f}" width="{px+.3:.1f}" height="{px+.3:.1f}" fill="{col}"/>')
    cuerpo.append(
        f'<g class="ola" style="animation-delay:0s"><g transform="translate({x_g:.1f} {y_g:.1f}) rotate(-14 0 {len(gorro)*px:.1f})">'
        f'{"".join(pix)}</g></g>'
    )

    # ── Destellos dorados alrededor del título
    for k in range(12):
        sx, sy = rnd.uniform(120, 1080), rnd.choice([rnd.uniform(70, 125), rnd.uniform(240, 300)])
        r = rnd.uniform(5, 9)
        cuerpo.append(
            f'<path class="tw" style="animation-delay:{-rnd.uniform(0, 2.4):.2f}s;transform-origin:{sx:.0f}px {sy:.0f}px" '
            f'd="M{sx:.0f} {sy - r:.0f}Q{sx:.0f} {sy:.0f} {sx + r:.0f} {sy:.0f}Q{sx:.0f} {sy:.0f} {sx:.0f} {sy + r:.0f}'
            f'Q{sx:.0f} {sy:.0f} {sx - r:.0f} {sy:.0f}Q{sx:.0f} {sy:.0f} {sx:.0f} {sy - r:.0f}Z" fill="{ORO}"/>')
    css.append(".tw{animation:tw 2.4s ease-in-out infinite}@keyframes tw{0%,100%{opacity:.15;transform:scale(.5)}50%{opacity:1;transform:scale(1)}}")

    # ── Subtítulo que alterna entre texto y binario
    fs_s = 20
    w_s = ancho(len(SUBTITULO), fs_s)
    binario = a_binario(TITULO)
    fs_b = 12
    w_b = ancho(len(binario), fs_b)
    cuerpo.append(
        f'<text class="m ciA" x="600" y="262" font-size="{fs_s}" text-anchor="middle" '
        f'textLength="{w_s:.1f}" fill="{ORO}">{esc(SUBTITULO)}</text>'
        f'<text class="m ciB" x="600" y="260" font-size="{fs_b}" text-anchor="middle" '
        f'textLength="{w_b:.1f}" fill="#ffe6c7">{binario}</text>'
    )
    css.append(
        ".ciA{animation:ciA 9s ease-in-out infinite}.ciB{animation:ciB 9s ease-in-out infinite}"
        "@keyframes ciA{0%,44%{opacity:1}50%,94%{opacity:0}100%{opacity:1}}"
        "@keyframes ciB{0%,44%{opacity:0}50%,94%{opacity:1}100%{opacity:0}}"
    )

    # ── Línea de código
    fs_c = 14
    w_c = ancho(len(LINEA_CODIGO), fs_c)
    cuerpo.append(
        f'<text class="m" x="600" y="302" font-size="{fs_c}" text-anchor="middle" textLength="{w_c:.1f}" '
        f'fill="{VERDE2}" opacity=".9">{esc(LINEA_CODIGO)}</text>'
    )

    # ── Guirnalda superior
    g, _ = guirnalda(W, 4, 15, 200, 4, escala=1.0)
    cuerpo.append(g)
    css.append(CSS_FOCOS)
    cuerpo.append(f'<rect width="{W}" height="{H}" fill="url(#scan)" opacity=".25"/>')
    cuerpo.append("</g>")
    cuerpo.append(
        f'<rect x="1.5" y="1.5" width="{W-3}" height="{H-3}" rx="21" fill="none" stroke="{ORO}" stroke-opacity=".6" stroke-width="3"/>'
    )

    return svg_doc(W, H, "".join(defs), "".join(css), "".join(cuerpo), "Feliz Navidad en ceros y unos")


# ═══════════════════════════ GUIRNALDA ═══════════════════════════
def guirnalda_svg():
    W, H = 1200, 56
    g, _ = guirnalda(W, 6, 12, 150, 4, escala=1.0)
    return svg_doc(W, H, halos(), CSS_FOCOS, g, "Guirnalda de luces")


# ═══════════════════ SERPIENTE (marcador temporal) ═══════════════════
def serpiente_temporal():
    W, H = 1200, 150
    l1 = f"{PROMPT}:~$ ./serpiente --modo navidad"
    l2 = "esperando la primera corrida del Action (pestaña Actions › Perfil navideño › Run workflow)"
    cuerpo = (
        f'<rect x="1.5" y="1.5" width="{W-3}" height="{H-3}" rx="18" fill="{FONDO}" stroke="{BORDE}" stroke-width="3"/>'
        f'<text class="m" x="40" y="64" font-size="20" textLength="{ancho(len(l1), 20):.1f}" fill="{VERDE}">{esc(l1)}</text>'
        f'<text class="m" x="40" y="100" font-size="15" textLength="{ancho(len(l2), 15):.1f}" fill="{ORO}">{esc(l2)}</text>'
    )
    return svg_doc(W, H, "", "", cuerpo, "Serpiente navideña (pendiente)")


if __name__ == "__main__":
    ASSETS.mkdir(exist_ok=True)
    salida = {
        "banner.svg": banner(),
        "guirnalda.svg": guirnalda_svg(),
    }
    serp = ASSETS / "serpiente-navidad.svg"
    if not serp.exists():
        salida["serpiente-navidad.svg"] = serpiente_temporal()
    for nombre, contenido in salida.items():
        (ASSETS / nombre).write_text(contenido, encoding="utf-8")
        print(f"assets/{nombre}  ({len(contenido.encode()) // 1024} KB)")
