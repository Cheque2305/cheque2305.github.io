#!/usr/bin/env python3
"""Arma la página navideña (cheque2305.github.io) en UN SOLO archivo: pagina/index.html.

    python3 scripts/pagina.py

Mete adentro (como data URI) las fuentes y todos los SVG de assets/, así que para
publicarla basta con subir ese index.html al repo cheque2305.github.io.
Antes corre generar_svgs.py, arte.py y personajes.py si cambiaste algo.
"""
import base64
import json
from pathlib import Path

import ballet
import personajes as P

AQUI = Path(__file__).resolve().parent
ASSETS = AQUI.parent / "assets"
SALIDA = AQUI.parent / "pagina" / "index.html"
VIDEO = "wp7TiyoNwy8"   # Peggy Lee – Santa Claus Is Comin' To Town (de repuesto, si la lista no carga)
LISTA = "PLRkNYszL_6gw"  # la playlist de la Radio Polo Norte (YouTube). Vacía ("") = solo el video de arriba.


def uri(ruta, tipo):
    return f"data:{tipo};base64," + base64.b64encode(Path(ruta).read_bytes()).decode()


def svg(nombre):
    return uri(ASSETS / nombre, "image/svg+xml")


# Personajes de La Villa de Santa: dónde caminan y qué dicen al darles clic
FRASES = {
    "muneco": ["¡Brrr! Pero qué bonito está todo", "¿Alguien ha visto mi zanahoria?",
               "Abrázame, pero poquito, que me derrito", "Aquí nomás, haciéndome bolita"],
    "oso": ["¿Un chocolatito calientito?", "¡Abrazo de oso, ven!", "Hiberno después de la posada, lo prometo",
            "Este gorro me lo tejió mi abuelita"],
    "reno": ["¡Ding, ding! ¿Escuchaste mi campana?", "Ya estiré para el vuelo del 24",
             "¿Me regalas una zanahoria?", "Sí vuelo… pero solo con escalas"],
    "pinguino": ["¡Abrazo de pingüino!", "¡Wiii! Me resbalé otra vez", "Vengo del Polo Sur, ¡qué calorcito!",
                 "¿Ya sirvieron los romeritos?"],
    "santa": ["¡JO JO JO!", "¿Te portaste bien este año?", "Ya revisé mi lista… dos veces",
              "Guárdame un tamal de dulce, porfa", "¡Feliz Navidad!"],
    "galleta": ["¡No me comas!", "¡Atrápame si puedes!", "Huelo a canela, ¿verdad?",
                "Mejor cómete un buñuelo, ¿no?"],
}


def datos_pueblo():
    datos = []
    for f in P.PERSONAJES:
        sp, _ = f()
        nombre = f.__name__
        fila, cx, d, _, _ = P.MOVIMIENTO[nombre]
        escala = 4 if fila == "atras" else 5
        datos.append({
            "id": nombre, "src": svg(f"personajes/{nombre}.svg"),
            "w": sp.w * escala, "h": sp.h * escala,
            "piso": P.PISO_ATRAS if fila == "atras" else P.PISO_FRENTE,
            "z": 1 if fila == "atras" else 3,
            "min": cx - d * 1.6, "max": cx + d * 1.6, "x": cx,
            "frases": FRASES[nombre],
        })
    return datos


PLANTILLA = r"""<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Feliz Navidad · cheque@polo-norte</title>
<meta name="description" content="La Navidad de Cheque en modo terminal: un Christmas Tree hecho de puras letras, La Villa de Santa en pixel art bailando al ritmo, radio navideña y cuenta regresiva.">
<meta name="theme-color" content="#2a0a10">
<link rel="icon" href="@@ICONO@@">
<style>
  @font-face { font-family: 'PS2P'; src: url(@@PS2P@@) format('woff2'); font-display: swap; }
  @font-face { font-family: 'JetBrains Mono'; src: url(@@F_MONO@@) format('woff2'); font-display: swap; }
  @font-face { font-family: 'Fredoka'; src: url(@@F_FREDOKA@@) format('woff2'); font-weight: 600; font-display: swap; }
  :root {
    --vino: #5a1620; --vino-osc: #2a0a10; --panel: #1f0c0d; --barra: #36140f;
    --crema: #fff4e6; --crema2: #f3d9bf; --tenue: #c9a78a;
    --rojo: #ff4d5e; --rojo2: #e63946; --rojo-osc: #a4161a; --verde: #5fe07a; --verde2: #2f9e5a;
    --oro: #ffcf5a; --oro2: #e8a33a; --azul: #7cc8ff; --rosa: #ff8fb8;
    --mono: 'JetBrains Mono', ui-monospace, Menlo, Consolas, monospace;
    --pixel: 'PS2P', monospace;
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; }
  body {
    min-height: 100vh; font-family: 'Fredoka', 'Trebuchet MS', system-ui, sans-serif; font-size: 18px; line-height: 1.5; color: var(--crema);
    background-color: #2a0a10;
    background-image:
      radial-gradient(900px 500px at 15% 0%, rgba(255, 207, 90, .16), transparent 70%),
      radial-gradient(800px 600px at 90% 20%, rgba(255, 143, 184, .10), transparent 70%),
      radial-gradient(1000px 700px at 50% 100%, rgba(255, 140, 70, .12), transparent 70%),
      linear-gradient(180deg, #6b1a26 0%, #4a0f17 45%, #2a0a10 100%);
    background-attachment: scroll;
  }
  body::after {                                    /* líneas de monitor, apenitas */
    content: ""; position: fixed; inset: 0; z-index: 45; pointer-events: none; opacity: .05;
    background: repeating-linear-gradient(180deg, #000 0 1px, transparent 1px 3px);
  }
  body.bloqueado { overflow: hidden; }
  a { color: var(--oro); }
  button { font-family: inherit; cursor: pointer; }
  #lluvia { position: fixed; inset: 0; width: 100%; height: 100%; z-index: -1; pointer-events: none; }
  #nieve { position: fixed; inset: 0; width: 100%; height: 100%; z-index: 40; pointer-events: none; }
  .mono { font-family: var(--mono); }
  .cursor { display: inline-block; width: .6em; height: 1.05em; margin-left: 2px; vertical-align: -.15em; background: var(--oro); animation: parpadeo 1s steps(1) infinite; }
  @keyframes parpadeo { 50% { opacity: 0; } }

  /* ── Serie de foquitos (se arma con JS; con música parpadean al ritmo) ── */
  .foquitos { position: relative; height: 62px; width: 100%; pointer-events: none; }
  .foquitos svg { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }
  .foco { position: absolute; width: 14px; height: 22px; margin-left: -7px; transform-origin: 50% 0; }
  .foco::before { content: ""; position: absolute; left: 3px; top: 0; width: 8px; height: 6px; border-radius: 2px; background: #3b4a3a; }
  .foco::after {
    content: ""; position: absolute; left: 0; top: 5px; width: 14px; height: 17px; border-radius: 50% 50% 46% 46% / 40% 40% 60% 60%;
    background: radial-gradient(circle at 35% 30%, #fff 0 12%, var(--c) 45%); box-shadow: 0 0 10px 2px var(--c), 0 0 26px 6px var(--c);
    opacity: .95; transition: opacity .12s, filter .12s;
  }
  .foco.apagado::after { opacity: .28; box-shadow: 0 0 4px var(--c); }
  .foco.titila::after { animation: titila var(--d, 2.4s) ease-in-out infinite; }
  @keyframes titila { 50% { opacity: .35; box-shadow: 0 0 4px var(--c); } }

  /* ── Pantalla de arranque ── */
  #inicio {
    position: fixed; inset: 0; z-index: 50; overflow: auto; cursor: pointer; text-align: center;
    display: flex; flex-direction: column; align-items: center; padding: 0 14px 24px;
    background: radial-gradient(ellipse at 50% 35%, rgba(138, 36, 51, .85) 0%, rgba(90, 22, 32, .8) 45%, rgba(42, 10, 16, .92) 100%);
  }
  #inicio.fuera { animation: fuera .8s ease-in forwards; pointer-events: none; }
  @keyframes fuera { to { opacity: 0; transform: scale(1.05); filter: blur(3px); } }
  #inicio .foquitos { flex: none; }
  .arranque { position: relative; width: min(920px, 100%); margin: auto; padding: 8px 0; }
  .boot {
    margin: 0 auto 18px; width: min(640px, 100%); min-height: 9.2em; text-align: left; white-space: pre-wrap;
    font: 14px/1.6 var(--mono); color: var(--verde); text-shadow: 0 0 8px rgba(95, 224, 122, .45);
    padding: 14px 18px; border-radius: 10px; background: rgba(20, 6, 8, .72); border: 1px solid rgba(255, 207, 90, .35);
  }
  .boot .ok { color: var(--oro); }
  .titulo-pixel {
    margin: 4px 0 0; font: clamp(34px, 8.6vw, 92px)/1.18 var(--pixel); color: var(--crema);
    text-shadow: 0 4px 0 var(--rojo-osc), 0 8px 0 #6b1220, 0 0 34px rgba(255, 207, 90, .45);
  }
  .titulo-pixel span { display: inline-block; animation: brinca 2.4s ease-in-out infinite; }
  .titulo-pixel span.oro { color: var(--oro); }
  @keyframes brinca { 0%, 45%, 100% { transform: translateY(0) rotate(0); } 22% { transform: translateY(-14px) rotate(-3deg); } }
  .sub { margin: 18px 0 0; font: 15px var(--mono); color: var(--oro); }
  .start {
    margin-top: 28px; font: clamp(13px, 2vw, 17px)/1.4 var(--pixel); color: #fff; background: var(--rojo2); border: 0;
    border-radius: 999px; padding: 18px 34px 16px;
    box-shadow: 0 0 0 6px #fff, 0 0 0 12px var(--rojo2), 0 10px 0 12px var(--rojo-osc), 0 16px 34px 12px rgba(0, 0, 0, .4), 0 0 60px 20px rgba(255, 207, 90, .25);
    animation: late 1.4s ease-in-out infinite;
  }
  .start:hover, .start:focus-visible { background: var(--verde2); outline: none; }
  @keyframes late { 50% { transform: scale(1.06); } }
  .pista { margin: 30px 0 0; font: 13px var(--mono); color: var(--crema2); opacity: .8; }
  .acebo { position: absolute; pointer-events: none; height: auto; filter: drop-shadow(0 4px 8px rgba(0, 0, 0, .35)); }
  .acebo.ai { left: -10px; top: -10px; }
  .acebo.ad { right: -10px; top: -10px; transform: scaleX(-1); }
  .arranque .acebo { width: clamp(90px, 14vw, 160px); }

  /* ── Página ── */
  #pagina { opacity: 0; transition: opacity .7s ease; overflow-x: clip; }
  #pagina.visible { opacity: 1; }
  .barra {
    position: sticky; top: 0; z-index: 30; display: flex; flex-wrap: wrap; gap: 10px 14px; align-items: center; justify-content: space-between;
    padding: 9px clamp(12px, 3vw, 28px); background: rgba(31, 12, 13, .92); backdrop-filter: blur(6px); -webkit-backdrop-filter: blur(6px);
    border-bottom: 1px solid rgba(255, 207, 90, .45); box-shadow: 0 3px 0 var(--rojo-osc), 0 10px 24px rgba(0, 0, 0, .35);
  }
  .prompt { font: 14px var(--mono); color: var(--crema2); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0; }
  .prompt b { color: var(--verde); font-weight: 400; } .prompt i { color: var(--azul); font-style: normal; } .prompt em { color: var(--oro); font-style: normal; }
  .acciones { display: flex; gap: 8px; flex: none; }
  .boton {
    display: inline-flex; align-items: center; gap: 7px; font: 13px var(--mono); color: var(--crema); text-decoration: none;
    padding: 7px 14px; border-radius: 8px; background: rgba(255, 207, 90, .07); border: 1px solid rgba(255, 207, 90, .6); white-space: nowrap; transition: .2s;
  }
  .boton svg { width: 11px; height: 11px; fill: currentColor; }
  .boton:hover, .boton:focus-visible { background: rgba(255, 207, 90, .18); outline: none; box-shadow: 0 0 14px rgba(255, 207, 90, .35); }
  .boton.on { background: var(--verde2); border-color: var(--verde); color: #fff; box-shadow: 0 0 16px rgba(95, 224, 122, .45); }

  .portada { text-align: center; }
  .portada .banner { width: min(1180px, calc(100% - 24px)); margin: 26px auto 0; display: block; filter: drop-shadow(0 18px 30px rgba(0, 0, 0, .45)) drop-shadow(0 0 30px rgba(255, 170, 80, .15)); }
  .linea { margin: 14px auto 0; font: 14px var(--mono); color: var(--crema2); }
  .linea b { color: var(--verde); font-weight: 400; }

  main { max-width: 1180px; margin: 0 auto; padding: 30px clamp(12px, 2.4vw, 24px) 50px; display: grid; grid-template-columns: minmax(0, 1fr); gap: clamp(46px, 6.5vw, 76px); }
  .acto { display: grid; grid-template-columns: minmax(0, 1fr); gap: 18px; justify-items: center; }
  .acto > .cab { width: 100%; }
  .cab { text-align: center; }
  .cab .comentario { margin: 0; font: 13px var(--mono); color: var(--tenue); }
  .cab .comentario b { color: var(--oro); font-weight: 400; }
  .cab h2 {
    margin: 10px 0 0; font: clamp(22px, 4.4vw, 44px)/1.3 var(--pixel); color: var(--oro);
    text-shadow: 0 3px 0 var(--rojo-osc), 0 6px 0 #5a0f18, 0 0 26px rgba(255, 207, 90, .35);
  }
  .cab h2 .blanco { color: var(--crema); }
  .cab p.texto { margin: 12px auto 0; max-width: 680px; color: var(--crema2); }
  .cab p.texto b { color: var(--oro); font-weight: 600; }

  /* Ventana de terminal navideña */
  .ventana {
    position: relative; width: 100%; border-radius: 14px; background: var(--panel); overflow: visible;
    border: 1px solid rgba(255, 207, 90, .55);
    box-shadow: 0 0 0 4px rgba(90, 22, 32, .7), 0 0 50px rgba(255, 170, 80, .16), 0 26px 50px rgba(0, 0, 0, .5);
  }
  .ventana.arbol { width: min(1000px, 100%); margin-top: 30px; }
  .ventana-barra {
    position: relative; display: flex; align-items: center; gap: 12px; padding: 10px 16px; border-radius: 13px 13px 0 0;
    background: linear-gradient(180deg, #45201a, #2f1410); font: 13px var(--mono); color: var(--crema2);
  }
  .esferas { display: flex; gap: 8px; flex: none; }
  .esferas i { position: relative; display: block; width: 13px; height: 13px; border-radius: 50%; }
  .esferas i::before { content: ""; position: absolute; left: 4px; top: -4px; width: 5px; height: 4px; border-radius: 1px; background: #d9b26a; }
  .esferas i:nth-child(1) { background: radial-gradient(circle at 35% 30%, #ffd0d4, #e63946 55%, #8e1220); }
  .esferas i:nth-child(2) { background: radial-gradient(circle at 35% 30%, #fff1c4, #ffcf5a 55%, #b7861f); }
  .esferas i:nth-child(3) { background: radial-gradient(circle at 35% 30%, #d6ffe0, #3fbf68 55%, #1d6b3a); }
  .ventana-titulo { flex: 1; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .ventana-titulo b { color: var(--oro); font-weight: 400; }
  .ventana-extra { flex: none; color: var(--verde); font-size: 12px; }
  .ventana-extra::before { content: "● "; animation: parpadeo 1.6s steps(1) infinite; }
  .baston { height: 6px; background: repeating-linear-gradient(-45deg, var(--rojo2) 0 10px, #fff 10px 20px); background-size: 28px 28px; animation: avanza 1.2s linear infinite; opacity: .9; }
  @keyframes avanza { to { background-position: 28px 0; } }
  .ventana-cuerpo { position: relative; overflow: hidden; background: #22120f; }
  .ventana-estado {
    display: flex; flex-wrap: wrap; gap: 6px 18px; align-items: center; justify-content: space-between; padding: 9px 16px;
    border-radius: 0 0 13px 13px; background: #2a1210; border-top: 1px solid rgba(255, 207, 90, .2); font: 12.5px var(--mono); color: var(--tenue);
  }
  .ventana-estado b { color: var(--verde); font-weight: 400; } .ventana-estado em { color: var(--oro); font-style: normal; }
  .ventana .acebo { width: clamp(62px, 7.4vw, 100px); z-index: 3; }
  .ventana .acebo.ai { left: -34px; top: -30px; }
  .ventana .acebo.ad { right: -34px; top: -30px; }
  .ventana .foquitos.sobre { position: absolute; left: 7%; right: 7%; width: auto; top: -46px; height: 50px; z-index: 4; }
  .ventana .ventana-barra { padding-left: 30px; padding-right: 30px; }

  /* Medidor de compás de la villa */
  .compas { display: inline-flex; align-items: flex-end; gap: 3px; height: 16px; }
  .compas i { display: block; width: 5px; height: 4px; border-radius: 1px; background: var(--oro); opacity: .5; transition: height .08s; }
  .modo-baile .compas i { opacity: 1; box-shadow: 0 0 6px rgba(255, 207, 90, .7); }

  /* ── La Villa de Santa ── */
  .marco-pueblo { position: relative; width: 100%; }
  .escenario { position: absolute; left: 0; top: 0; width: 1200px; height: 470px; transform-origin: 0 0; }
  .escenario > img.fondo { position: absolute; inset: 0; width: 1200px; height: 470px; }
  .pino { position: absolute; z-index: 0; transform-origin: 50% 100%; pointer-events: none; }
  .pino img { display: block; width: 100%; height: 100%; image-rendering: pixelated; }
  .luces-baile {
    position: absolute; inset: 0; z-index: 0; pointer-events: none; opacity: 0; mix-blend-mode: screen;
    background: radial-gradient(circle at 18% 34%, rgba(255, 207, 90, .6), transparent 34%),
                radial-gradient(circle at 52% 22%, rgba(255, 77, 94, .5), transparent 34%),
                radial-gradient(circle at 84% 36%, rgba(95, 224, 122, .4), transparent 34%);
  }
  .pj { position: absolute; cursor: pointer; will-change: transform; transform-origin: 50% 100%; }
  .pj img { display: block; width: 100%; height: 100%; image-rendering: pixelated; user-select: none; -webkit-user-drag: none; }
  .pj .sombra { position: absolute; left: 14%; right: 14%; bottom: -6px; height: 12px; border-radius: 50%; background: rgba(90, 40, 70, .35); }
  .globo {
    position: absolute; left: 0; bottom: 100%; transform: translateY(-6px); z-index: 9; pointer-events: none;
    padding: calc(10px * var(--inv, 1)) calc(14px * var(--inv, 1)); width: max-content; max-width: calc(320px * var(--inv, 1));
    white-space: normal; text-align: center; text-transform: uppercase;
    font: calc(13px * var(--inv, 1))/1.55 var(--pixel); color: #a4161a;
    background: #fff; box-shadow: 0 calc(4px * var(--inv, 1)) 0 rgba(40, 10, 30, .25);
    animation: globo 2.8s steps(14) forwards;
  }
  .globo::after { content: ""; position: absolute; left: var(--cola, 50%); top: 100%; margin-left: calc(-8px * var(--inv, 1)); border: calc(8px * var(--inv, 1)) solid transparent; border-top-color: #fff; border-left-width: 0; }
  .globo.abajo::after { display: none; }
  @keyframes globo { 0% { opacity: 0; transform: translateY(6px) scale(.6); } 12%, 80% { opacity: 1; transform: translateY(-6px) scale(1); } 100% { opacity: 0; transform: translateY(-16px); } }
  .corazon { position: absolute; width: 22px; height: 19px; pointer-events: none; z-index: 8; animation: sube 1.6s ease-out forwards; }
  @keyframes sube { from { opacity: 1; transform: translate(0, 0) scale(.6); } to { opacity: 0; transform: translate(var(--dx), -90px) scale(1.2); } }
  .notita { position: absolute; width: 34px; height: auto; pointer-events: none; z-index: 8; animation: flota 2.8s ease-out forwards; filter: drop-shadow(0 0 6px rgba(255, 200, 110, .6)); }
  @keyframes flota { 0% { opacity: 0; transform: translate(0, 0) rotate(-12deg) scale(.6); } 15% { opacity: 1; } 100% { opacity: 0; transform: translate(var(--dx), -120px) rotate(14deg) scale(1.15); } }

  /* ── El Cascanueces: teatrito ── */
  .teatro { position: relative; width: 100%; aspect-ratio: 1200 / 522; overflow: hidden; background: #0a1230; }
  .teatro-esc { position: absolute; left: 0; top: 0; width: 1200px; height: 522px; transform-origin: 0 0; }
  .teatro-esc > img.fondo { position: absolute; inset: 0; width: 1200px; height: 522px; image-rendering: pixelated; }
  .bailarin { position: absolute; left: 0; top: 0; width: 228px; height: 312px; cursor: pointer; will-change: transform; }
  .bailarin img { position: absolute; inset: 0; width: 100%; height: 100%; display: none; image-rendering: pixelated; user-select: none; -webkit-user-drag: none; }
  .bailarin img.on { display: block; }
  .bailarin img.voltea { transform: scaleX(-1); }
  .reflector { position: absolute; left: 0; top: 0; width: 240px; height: 60px; margin-left: -120px; pointer-events: none;
    background: radial-gradient(ellipse at center, rgba(255, 246, 208, .5), rgba(255, 246, 208, 0) 70%); will-change: transform; }
  .haz { position: absolute; top: 0; width: 300px; height: 470px; margin-left: -150px; pointer-events: none; opacity: 0; transition: opacity .6s;
    background: linear-gradient(180deg, rgba(255, 246, 208, 0), rgba(255, 246, 208, .16)); clip-path: polygon(42% 0, 58% 0, 100% 100%, 0 100%); }
  .teatro.funcion .haz { opacity: 1; }
  .candileja { position: absolute; top: 504px; width: 18px; height: 14px; margin-left: -9px; border-radius: 50%; pointer-events: none;
    background: radial-gradient(circle, #fff6c8 0 30%, rgba(255, 207, 90, .6) 50%, rgba(255, 207, 90, 0) 72%); opacity: .55; transition: opacity .08s; }
  .teatro.funcion .candileja.on { opacity: 1; }
  .pendulo { position: absolute; left: 906px; top: 240px; width: 90px; height: 138px; margin-left: -45px; transform-origin: 50% 0; pointer-events: none; image-rendering: pixelated; }
  .globo-t {
    position: absolute; z-index: 9; pointer-events: none; padding: 10px 14px; width: max-content; max-width: 300px; text-align: center; text-transform: uppercase;
    font: 13px/1.55 var(--pixel); color: #a4161a; background: #fff; box-shadow: 0 4px 0 rgba(40, 10, 30, .25); animation: globo 2.6s steps(14) forwards;
  }
  .chispa { position: absolute; width: 12px; height: 12px; pointer-events: none; z-index: 8; animation: chispa 1.4s ease-out forwards;
    background: radial-gradient(circle, #fff 0 25%, rgba(255, 220, 140, .8) 40%, rgba(255, 220, 140, 0) 70%); }
  @keyframes chispa { from { opacity: 1; transform: translate(0, 0) scale(.6); } to { opacity: 0; transform: translate(var(--dx), var(--dy)) scale(1.3); } }
  .boton.chico { font-size: 12px; padding: 4px 10px; }
  .boton.tap.golpe { background: rgba(255, 207, 90, .45); }

  /* ── Noche de paz ── */
  .ventana.belen { width: min(800px, 100%); }
  .ventana.belen .ventana-cuerpo { background: #050817; }

  /* ── Radio y reloj ── */
  .dos { display: grid; grid-template-columns: minmax(0, 1fr); gap: 28px; width: 100%; align-items: start; }
  @media (min-width: 980px) { .dos { grid-template-columns: minmax(0, 1.35fr) minmax(0, 1fr); } }
  .radio-cuerpo {
    padding: 16px 16px 14px;
    background: repeating-linear-gradient(90deg, rgba(0, 0, 0, .07) 0 3px, transparent 3px 9px), linear-gradient(180deg, #8b5a3c, #6a3f26 60%, #4a2a18);
  }
  .pantalla { position: relative; aspect-ratio: 16 / 9; border-radius: 10px; overflow: hidden; background: #140a06; border: 3px solid #2a1208; box-shadow: 0 0 0 2px var(--oro2), 0 0 24px rgba(255, 207, 90, .25); }
  .pantalla iframe, .pantalla > div { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; }
  .pantalla::after { content: ""; position: absolute; inset: 0; pointer-events: none; background: repeating-linear-gradient(180deg, rgba(0, 0, 0, .12) 0 1px, transparent 1px 3px); }
  .tablero { display: flex; align-items: center; gap: 14px; margin-top: 12px; padding: 8px 12px; border-radius: 8px; background: rgba(30, 12, 6, .55); border: 1px solid rgba(255, 207, 90, .4); }
  .ecualizador { flex: 1; display: flex; align-items: flex-end; gap: 3px; height: 30px; }
  .ecualizador i { flex: 1; height: 15%; border-radius: 2px 2px 0 0; background: linear-gradient(0deg, var(--verde2), var(--oro) 70%, var(--rojo)); opacity: .55; }
  .sonando .ecualizador i { opacity: 1; animation: eq .5s ease-in-out infinite alternate; }
  @keyframes eq { from { height: 15%; } to { height: 100%; } }
  .perilla { width: 26px; height: 26px; border-radius: 50%; background: radial-gradient(circle at 35% 35%, #fff3c4, #d9b26a 45%, #7a5420); box-shadow: 0 2px 4px rgba(0, 0, 0, .4); }
  .dial { font: 13px var(--mono); color: var(--oro); }
  .nota { margin: 10px 2px 0; font-size: 15px; line-height: 1.4; color: var(--crema); }
  .nota[hidden] { display: none; }

  .reloj-cuerpo { padding: 26px 16px 22px; text-align: center; background: radial-gradient(ellipse at 50% 0%, rgba(255, 207, 90, .12), transparent 70%), #22120f; }
  .reloj-cuerpo .comando { margin: 0 0 6px; font: 13px var(--mono); color: var(--crema2); text-align: left; }
  .reloj-cuerpo .comando b { color: var(--verde); font-weight: 400; }
  .reloj-cuerpo h3 { margin: 6px 0 2px; font: clamp(14px, 2vw, 18px)/1.5 var(--pixel); color: var(--crema); }
  #cuenta-titulo { margin: 0 0 6px; color: var(--tenue); font-size: 15px; }
  .regalos { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: clamp(10px, 1.8vw, 18px); padding-top: 22px; }
  .regalo { display: grid; gap: 10px; justify-items: center; }
  .caja {
    position: relative; width: 100%; padding: 20px 4px 14px; border-radius: 10px; text-align: center;
    font: clamp(18px, 3vw, 30px)/1 var(--pixel); color: #fff; text-shadow: 0 3px 0 rgba(0, 0, 0, .3);
    background: var(--c1); box-shadow: inset 0 -8px 0 rgba(0, 0, 0, .18), 0 6px 0 var(--c2), 0 0 22px var(--c3);
  }
  .caja::before { content: ""; position: absolute; left: 50%; top: 0; bottom: 0; width: 9px; margin-left: -4.5px; background: var(--oro); opacity: .85; }
  .caja::after { content: ""; position: absolute; left: 50%; top: -15px; width: 34px; height: 17px; margin-left: -17px;
    background: radial-gradient(circle at 25% 60%, var(--oro) 0 38%, transparent 40%), radial-gradient(circle at 75% 60%, var(--oro) 0 38%, transparent 40%); }
  .caja span { position: relative; }
  .regalo:nth-child(1) .caja { --c1: #e63946; --c2: #a4161a; --c3: rgba(230, 57, 70, .35); }
  .regalo:nth-child(2) .caja { --c1: #2f9e5a; --c2: #1d6b3a; --c3: rgba(47, 158, 90, .35); }
  .regalo:nth-child(3) .caja { --c1: #c98a22; --c2: #8a5a10; --c3: rgba(255, 207, 90, .35); }
  .regalo:nth-child(4) .caja { --c1: #d94f7c; --c2: #9a2a52; --c3: rgba(255, 143, 184, .35); }
  .etq { font: 12px var(--mono); color: var(--tenue); }
  .pie-reloj { margin: 22px 0 0; font: 13px var(--mono); color: var(--verde); }

  footer { text-align: center; padding: 10px 18px 50px; font: 13.5px/1.8 var(--mono); color: var(--crema2); }
  footer .adios { margin: 0 0 8px; font: clamp(13px, 2vw, 18px)/1.6 var(--pixel); color: var(--oro); text-shadow: 0 3px 0 var(--rojo-osc); }
  footer b { color: var(--verde); font-weight: 400; }

  @media (max-width: 640px) {
    body { font-size: 16.5px; }
    .ventana .acebo.ai { left: -18px; top: -18px; } .ventana .acebo.ad { right: -18px; top: -18px; }
    .ventana .ventana-barra { padding-left: 22px; padding-right: 22px; }
    .ventana .foquitos.sobre { top: -38px; }
    .ventana.arbol { margin-top: 22px; }
    .cab h2 { font-size: 20px; }
    .prompt { font-size: 12px; }
    .prompt .largo { display: none; }
    .boton { font-size: 11.5px; padding: 6px 9px; }
    .ventana-barra { font-size: 11.5px; padding: 9px 10px; }
    .ventana-extra { display: none; }
    .ventana-estado { font-size: 11px; }
    .boot { font-size: 11.5px; }
    .regalos { gap: 8px; }
    .caja { font-size: 15px; padding: 18px 2px 12px; }
    .etq { font-size: 10.5px; }
  }
  @media (prefers-reduced-motion: reduce) { .titulo-pixel span, .start, .baston, .cursor { animation: none; } }
</style>
</head>
<body class="bloqueado">
<canvas id="lluvia" aria-hidden="true"></canvas>
<canvas id="nieve" aria-hidden="true"></canvas>

<!-- Pantalla de arranque: el clic en START es lo que permite que el navegador deje sonar la música -->
<section id="inicio" role="button" tabindex="0" aria-label="Iniciar la fiesta con música">
  <div class="foquitos" data-focos="34"></div>
  <div class="arranque">
    <img class="acebo ai" src="@@ACEBO@@" alt=""><img class="acebo ad" src="@@ACEBO@@" alt="">
    <pre class="boot" id="boot" aria-hidden="true"></pre>
    <h1 class="titulo-pixel" aria-label="Feliz Navidad">@@TITULO@@</h1>
    <p class="sub">// de parte de Cheque y sus elfos programadores</p>
    <button class="start" id="start" type="button">▶ ¡QUE EMPIECE LA FIESTA!</button>
    <p class="pista">súbele al volumen 🔊 · o presiona Enter</p>
  </div>
</section>

<div id="pagina" aria-hidden="true">
  <header class="barra">
    <span class="prompt"><b>cheque@polo-norte</b>:<i>~</i>$ <em>./navidad</em> <span class="largo">--modo fiesta</span><span class="cursor"></span></span>
    <span class="acciones">
      <button class="boton" id="musica" type="button" aria-pressed="false">afinando…</button>
      <a class="boton" href="https://github.com/Cheque2305">github ›</a>
    </span>
  </header>

  <section class="portada">
    <img class="banner" src="@@BANNER@@" alt="Feliz Navidad en pixel art con lluvia de ceros y unos">
    <p class="linea"><b>cheque@polo-norte:~$</b> ./navidad --todos-a-bailar<span class="cursor"></span></p>
  </section>

  <main>
    <section class="acto">
      <div class="cab">
        <p class="comentario"><b>#</b> acto 1 · python3 arte.py</p>
        <h2>CHRISTMAS <span class="blanco">TREE</span></h2>
        <p class="texto">Un árbol 3D hecho de puras letras: crece, se ilumina, le llueven regalos y, si te fijas bien, <b>Santa cruza la luna en su trineo</b>.</p>
      </div>
      <div class="ventana arbol">
        <div class="foquitos sobre" data-focos="22"></div>
        <img class="acebo ai" src="@@ACEBO@@" alt=""><img class="acebo ad" src="@@ACEBO@@" alt="">
        <div class="ventana-barra"><span class="esferas"><i></i><i></i><i></i></span><span class="ventana-titulo"><b>arte.py</b> — Christmas Tree</span><span class="ventana-extra">en vivo</span></div>
        <div class="baston"></div>
        <div class="ventana-cuerpo" id="arbol-lugar" style="aspect-ratio:900/792"></div>
        <div class="ventana-estado"><span><b>$</b> python3 arte.py --que-gire</span><span><em>15 fps</em> · 100% letras · 0% pixeles</span></div>
      </div>
    </section>

    <section class="acto">
      <div class="cab">
        <p class="comentario"><b>#</b> acto 2 · ./villa --todos-a-bailar</p>
        <h2>LA VILLA <span class="blanco">DE SANTA</span></h2>
        <p class="texto">Salúdalos con un clic (son bien platicadores). <b>Dale play a la música</b> y se arma el bailongo al ritmo; si la pausas, vuelven a pasear como si nada.</p>
      </div>
      <div class="ventana" id="ventana-villa">
        <img class="acebo ai" src="@@ACEBO@@" alt=""><img class="acebo ad" src="@@ACEBO@@" alt="">
        <div class="ventana-barra"><span class="esferas"><i></i><i></i><i></i></span><span class="ventana-titulo"><b>villa_de_santa.exe</b> — 6 personajes conectados</span><span class="ventana-extra">en línea</span></div>
        <div class="baston"></div>
        <div class="ventana-cuerpo"><div class="marco-pueblo" data-pueblo></div></div>
        <div class="ventana-estado"><span id="modo-villa">♪ modo: <em>paseo</em> · dale play para el bailongo</span>
          <span class="compas" id="compas" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span></div>
      </div>
    </section>

    <section class="acto">
      <div class="cab">
        <p class="comentario"><b>#</b> acto 3 · ./cascanueces --funcion-de-medianoche</p>
        <h2>EL <span class="blanco">CASCANUECES</span></h2>
        <p class="texto">Cuando el reloj da las doce, el Cascanueces y la bailarina salen a escena. <b>Con música bailan al compás de la canción que esté sonando</b>; sin música, ensayan tranquilitos.</p>
      </div>
      <div class="ventana" id="ventana-teatro">
        <img class="acebo ai" src="@@ACEBO@@" alt=""><img class="acebo ad" src="@@ACEBO@@" alt="">
        <div class="ventana-barra"><span class="esferas"><i></i><i></i><i></i></span><span class="ventana-titulo"><b>cascanueces.exe</b> — función de medianoche</span><span class="ventana-extra">en escena</span></div>
        <div class="baston"></div>
        <div class="ventana-cuerpo"><div class="teatro" data-teatro></div></div>
        <div class="ventana-estado"><span id="modo-teatro">♪ ensayo · dale play para la función</span>
          <span><button class="boton chico tap" type="button" title="Toca al ritmo de la canción (o presiona T) para que bailen exacto">♪ marcar ritmo</button> <em class="bpm-txt">120 bpm</em></span></div>
      </div>
    </section>

    <section class="acto">
      <div class="cab">
        <p class="comentario"><b>#</b> acto 4 · radio + reloj</p>
        <h2>RADIO <span class="blanco">POLO NORTE</span></h2>
        <p class="texto">La estación oficial del Polo Norte: villancicos uno tras otro y todos bailan al ritmo del que esté sonando. Si no suena, <b>dale play aquí mismo</b>.</p>
      </div>
      <div class="dos">
        <div class="ventana" id="tele">
          <div class="ventana-barra"><span class="esferas"><i></i><i></i><i></i></span><span class="ventana-titulo"><b>radio.fm</b> — 24.12 FM</span><span class="ventana-extra">al aire</span></div>
          <div class="radio-cuerpo">
            <div class="pantalla"><div id="yt"></div></div>
            <div class="tablero"><span class="perilla"></span><span class="ecualizador" aria-hidden="true">@@ECUALIZADOR@@</span><span class="dial">24.12 FM</span><span class="perilla"></span></div>
            <p class="nota" id="nota-toca" hidden>¿No suena? Dale un toquecito al video: a veces los duendes de la radio se quedan dormidos.</p>
            <p class="nota" id="nota-falla" hidden>Los renos se comieron el cable de la radio.
              <a href="https://www.youtube.com/watch?v=@@VIDEO@@" target="_blank" rel="noopener">Escúchala en YouTube ›</a></p>
          </div>
        </div>
        <div class="ventana">
          <div class="ventana-barra"><span class="esferas"><i></i><i></i><i></i></span><span class="ventana-titulo"><b>reloj.exe</b> — cuenta regresiva</span></div>
          <div class="reloj-cuerpo">
            <p class="comando"><b>$</b> date --hasta=navidad</p>
            <h3>¿CUÁNTO FALTA?</h3>
            <p id="cuenta-titulo">(sí, ya sé que lo preguntas cada cinco minutos)</p>
            <div class="regalos" aria-live="polite">
              <div class="regalo"><div class="caja"><span id="d">--</span></div><span class="etq">días</span></div>
              <div class="regalo"><div class="caja"><span id="h">--</span></div><span class="etq">horas</span></div>
              <div class="regalo"><div class="caja"><span id="m">--</span></div><span class="etq">min</span></div>
              <div class="regalo"><div class="caja"><span id="s">--</span></div><span class="etq">seg</span></div>
            </div>
            <p class="pie-reloj" id="cuenta-pie">para que llegue Santa · hora del centro de México</p>
          </div>
        </div>
      </div>
    </section>

    <section class="acto">
      <div class="cab">
        <p class="comentario"><b>#</b> acto final · node belen.js</p>
        <h2>NOCHE <span class="blanco">DE PAZ</span></h2>
        <p class="texto">Aquí empezó todo: en un pesebre humilde, donde Dios se hizo hombre y una estrella alumbró el lugar. Hecho con puras letras de código… y con todo el corazón.</p>
      </div>
      <div class="ventana belen">
        <div class="ventana-barra"><span class="esferas"><i></i><i></i><i></i></span><span class="ventana-titulo"><b>belen.js</b> — noche de paz</span><span class="ventana-extra">en vivo</span></div>
        <div class="baston"></div>
        <div class="ventana-cuerpo" id="belen-lugar" style="aspect-ratio:960/1190"></div>
        <div class="ventana-estado"><span><b>$</b> node belen.js --con-todo-el-corazon</span><span><em>Lc 2, 7</em> · lo acostó en un pesebre</span></div>
      </div>
    </section>
  </main>

  <footer>
    <div class="foquitos" data-focos="24"></div>
    <p class="adios">¡FELIZ NAVIDAD!</p>
    <b>$</b> exit 0 · y que tu 2027 compile a la primera ♥<br>
    Hecho con ceros, unos, pixeles y harto ponche por Cheque · <a href="https://github.com/Cheque2305">github.com/Cheque2305</a><br>
    Música: la playlist navideña de la Radio Polo Norte (suena desde YouTube; los derechos son de sus dueños).
  </footer>
</div>

<script>
(() => {
  const VIDEO = '@@VIDEO@@';
  const PERSONAJES = @@PERSONAJES@@;
  const PINOS = @@PINOS@@;
  const ARBOL_ASCII = '@@ASCII@@';
  const CORAZON = '@@CORAZON@@';
  const NOTAS = ['@@NOTA1@@', '@@NOTA2@@'];
  const LISTA = '@@LISTA@@';
  const COREO = @@COREO@@;
  const POSES = @@POSES@@;
  const ESCENARIO = '@@ESCENARIO@@', PENDULO = '@@PENDULO@@';
  const BELEN = '@@BELEN@@';
  // Tempo de cada canción (aproximado, por el título). Si no está aquí: 120, y con "marcar ritmo" se afina exacto.
  const RITMOS = [[/all i want for christmas/i, 150], [/last christmas/i, 107], [/jingle bell rock/i, 119],
    [/rockin.{0,4}around/i, 134], [/feliz navidad/i, 149], [/santa claus is comin/i, 122], [/holly jolly/i, 140],
    [/underneath the tree/i, 160]];
  let bpm = 120, fase = 0, videoActual = '';
  const ICONO_NOTA = '<svg viewBox="0 0 28 38" aria-hidden="true"><path d="M14.6 30V2h2.8c.6 6 9.4 8.6 7.6 19 1-8-3.5-11.3-7.6-12.3V30z"/><ellipse cx="9" cy="31" rx="7.5" ry="5.4" transform="rotate(-22 9 31)"/></svg>';
  const $ = (id) => document.getElementById(id);
  const azar = (lista) => lista[Math.floor(Math.random() * lista.length)];
  const inicio = $('inicio'), pagina = $('pagina'), botonMusica = $('musica');
  let player = null, listo = false, pedido = false, fallo = false, sonando = false, entrado = false;

  // ── Música con el reproductor de YouTube (solo arranca después del clic en "Entrar")
  window.onYouTubeIframeAPIReady = () => {
    const vars = LISTA ? { playsinline: 1, rel: 0, listType: 'playlist', list: LISTA }
                       : { playsinline: 1, loop: 1, playlist: VIDEO, rel: 0 };
    player = new YT.Player('yt', {
      width: '100%', height: '100%', ...(LISTA ? {} : { videoId: VIDEO }),
      playerVars: vars,
      events: {
        onReady: () => { listo = true; try { if (LISTA) player.setLoop(true); } catch (e) {} if (pedido) sonar(); pintarBoton(); },
        onStateChange: (e) => {
          const antes = sonando;
          sonando = e.data === YT.PlayerState.PLAYING;
          if (sonando) $('nota-toca').hidden = true;
          document.body.classList.toggle('sonando', sonando);
          pintarModo();
          if (sonando) cancionNueva();
          if (sonando && !antes) { try { tMusica = player.getCurrentTime(); } catch (err) {} festejar(); }
          if (!sonando && antes && e.data === YT.PlayerState.PAUSED) seAcabo();
          pintarBoton();
        },
        onError: () => {                                // una canción que no se deja: a la siguiente
          errores++;
          if (LISTA && errores < 4) { try { player.nextVideo(); return; } catch (e) {} }
          falla();
        },
      },
    });
  };
  const api = document.createElement('script');
  api.src = 'https://www.youtube.com/iframe_api';
  api.onerror = () => falla();
  document.head.appendChild(api);

  let errores = 0;
  function cancionNueva() {                          // cambió la canción: su tempo y desde el tiempo cero
    let datos = {};
    try { datos = player.getVideoData() || {}; } catch (e) {}
    if (!datos.video_id || datos.video_id === videoActual) return;
    videoActual = datos.video_id;
    errores = 0;
    const r = RITMOS.find(([re]) => re.test(datos.title || ''));
    bpm = r ? r[1] : 120;
    fase = 0;
    pintarModo();
  }
  // "Marcar ritmo": tocas al compás y todos se sincronizan exacto (tempo y golpe)
  let toques = [];
  function marcarRitmo() {
    const ahora = performance.now();
    toques = toques.filter((t) => ahora - t.real < 3200);
    toques.push({ real: ahora, cancion: tMusica });
    document.querySelectorAll('.tap').forEach((b) => { b.classList.add('golpe'); setTimeout(() => b.classList.remove('golpe'), 120); });
    if (toques.length >= 3) {
      const difs = toques.slice(1).map((t, i) => (t.real - toques[i].real) / 1000);
      const prom = difs.reduce((a, c) => a + c, 0) / difs.length;
      bpm = Math.round(Math.max(60, Math.min(200, 60 / prom)));
      fase = tMusica;                                // este toque es un golpe
      pintarModo();
    }
  }
  document.querySelectorAll('.tap').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); marcarRitmo(); }));
  document.addEventListener('keydown', (e) => { if (entrado && (e.key === 't' || e.key === 'T') && !e.repeat) marcarRitmo(); });

  function sonar() {
    if (!player || fallo) return;
    try { player.unMute(); player.setVolume(65); player.playVideo(); } catch (e) { falla(); return; }
    setTimeout(() => { if (!sonando && !fallo) $('nota-toca').hidden = false; }, 3500);
  }
  function falla() {
    fallo = true;
    $('nota-falla').hidden = false;
    $('nota-toca').hidden = true;
    pintarBoton();
  }
  function pintarBoton() {
    if (fallo) { botonMusica.innerHTML = ICONO_NOTA + 'oír en youtube'; botonMusica.classList.remove('on'); return; }
    if (!listo) { botonMusica.innerHTML = ICONO_NOTA + 'afinando…'; return; }
    botonMusica.innerHTML = ICONO_NOTA + (sonando ? 'música: on' : 'música: off');
    botonMusica.classList.toggle('on', sonando);
    botonMusica.setAttribute('aria-pressed', String(sonando));
  }
  botonMusica.addEventListener('click', () => {
    if (fallo) { window.open(LISTA ? 'https://www.youtube.com/playlist?list=' + LISTA : 'https://www.youtube.com/watch?v=' + VIDEO, '_blank', 'noopener'); return; }
    if (!listo) return;
    if (sonando) player.pauseVideo(); else sonar();
  });
  pintarBoton();
  function pintarModo() {
    const m = $('modo-villa');
    if (!m) return;
    m.innerHTML = sonando ? '♪ modo: <em>¡bailongo!</em> · ' + bpm + ' BPM al compás' : '♪ modo: <em>paseo</em> · dale play para el bailongo';
    m.closest('.ventana').classList.toggle('modo-baile', sonando);
    const t = $('modo-teatro');
    if (t) t.innerHTML = sonando ? '♪ <em>¡función!</em> bailando al compás' : '♪ ensayo · dale play para la función';
    document.querySelectorAll('.bpm-txt').forEach((e) => { e.textContent = bpm + ' bpm'; });
  }

  // ── Arranque: la terminal "prende" la Navidad
  const LINEAS = [
    ['> iniciando navidad.exe v24.12', ''],
    ['> cargando villancicos ............ ', '[OK]'],
    ['> calentando el ponche ............ ', '[OK]'],
    ['> desenredando la serie de luces .. ', '[OK]'],
    ['> despertando a los renos ......... ', '[OK]'],
    ['> todo listo. presiona START', ''],
  ];
  (async () => {
    const boot = $('boot');
    for (const [txt, ok] of LINEAS) {
      for (let i = 0; i <= txt.length; i += 2) { boot.innerHTML = (boot.dataset.previo || '') + txt.slice(0, i) + '<span class="cursor"></span>'; await new Promise((r) => setTimeout(r, 14)); }
      boot.dataset.previo = (boot.dataset.previo || '') + txt + (ok ? '<span class="ok">' + ok + '</span>' : '') + '\n';
      boot.innerHTML = boot.dataset.previo + '<span class="cursor"></span>';
      await new Promise((r) => setTimeout(r, 220));
    }
  })();

  // ── Entrar a la fiesta
  function entrar() {
    if (entrado) return;
    entrado = true;
    pedido = true;
    if (listo) sonar();
    else setTimeout(() => { if (!listo) falla(); }, 8000);
    inicio.classList.add('fuera');
    document.body.classList.remove('bloqueado');
    pagina.classList.add('visible');
    pagina.removeAttribute('aria-hidden');
    const arbol = new Image();                       // el Christmas Tree empieza a crecer al entrar
    arbol.className = 'ancho';
    arbol.alt = 'Christmas Tree: árbol de Navidad 3D en arte ASCII que gira, con luces, regalos, luna llena y el trineo de Santa';
    arbol.style.cssText = 'width:100%;height:100%;display:block';
    arbol.src = ARBOL_ASCII;
    $('arbol-lugar').appendChild(arbol);
    const belen = $('belen-lugar');
    const verBelen = new IntersectionObserver((ents) => {
      if (!ents.some((e) => e.isIntersecting)) return;
      verBelen.disconnect();
      const img = new Image();
      img.alt = 'Noche de paz: Belén de noche, la estrella y su luz sobre el pesebre con María, José y el Niño, hecho de letras de código';
      img.style.cssText = 'width:100%;height:100%;display:block';
      img.src = BELEN;
      belen.appendChild(img);
    }, { threshold: .25 });
    verBelen.observe(belen);
    setTimeout(() => inicio.remove(), 950);
  }
  inicio.addEventListener('click', entrar);
  document.addEventListener('keydown', (e) => {
    if (!entrado && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); entrar(); }
  });

  // ── Cuenta regresiva en vivo (centro de México = UTC-6 todo el año)
  const MX = -6 * 3600 * 1000;
  const dos = (n) => String(n).padStart(2, '0');
  function tic() {
    const ahora = Date.now();
    const local = new Date(ahora + MX);
    const anio = local.getUTCFullYear(), mes = local.getUTCMonth(), dia = local.getUTCDate();
    let meta, texto, titulo = '(sí, ya sé que lo preguntas cada cinco minutos)';
    if (mes === 11 && dia === 24) titulo = '¡Hoy es Nochebuena! Ya huele a ponche';
    if (mes === 11 && dia === 25) { titulo = '¡HOY ES NAVIDAD! Ve a darle un abrazo a alguien'; meta = Date.UTC(anio + 1, 0, 1) - MX; texto = 'para el Año Nuevo (y el recalentado sigue)'; }
    else if (mes === 11 && dia > 25) { titulo = 'Ya pasó Navidad… pero el recalentado sigue'; meta = Date.UTC(anio + 1, 0, 1) - MX; texto = 'para darle la bienvenida al ' + (anio + 1); }
    else { if (mes === 0 && dia === 1) titulo = '¡Feliz ' + anio + '! Y ya empezó la cuenta para la próxima Navidad';
           meta = Date.UTC(anio, 11, 25) - MX; texto = 'para que llegue Santa'; }
    let r = Math.max(0, Math.floor((meta - ahora) / 1000));
    $('d').textContent = Math.floor(r / 86400); r %= 86400;
    $('h').textContent = dos(Math.floor(r / 3600)); r %= 3600;
    $('m').textContent = dos(Math.floor(r / 60));
    $('s').textContent = dos(r % 60);
    $('cuenta-titulo').textContent = titulo;
    $('cuenta-pie').textContent = texto + ' · hora del centro de México';
  }
  tic();
  setInterval(tic, 1000);

  // ── La Villa de Santa: pasean, platican, brincan al clic… y con música bailan al ritmo
  const quieto = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const villas = [];
  document.querySelectorAll('[data-pueblo]').forEach((marco) => {
    marco.style.aspectRatio = '1200 / 470';
    const esc = document.createElement('div');
    esc.className = 'escenario';
    esc.innerHTML = '<img class="fondo" alt="" src="@@FONDO@@">';
    marco.appendChild(esc);
    const pinos = PINOS.map((p, i) => {
      const el = document.createElement('div');
      el.className = 'pino';
      el.style.cssText = `left:${p.x}px;top:${p.y}px;width:${p.w}px;height:${p.h}px`;
      el.innerHTML = `<img alt="" src="${p.src}">`;
      esc.appendChild(el);
      return { el, i };
    });
    const luces = document.createElement('div');
    luces.className = 'luces-baile';
    esc.appendChild(luces);
    const gente = PERSONAJES.map((p) => {
      const el = document.createElement('div');
      el.className = 'pj';
      el.style.cssText = `width:${p.w}px;height:${p.h}px;top:${p.piso - p.h + 4}px;z-index:${p.z}`;
      el.innerHTML = `<span class="sombra"></span><img alt="${p.id}" src="${p.src}">`;
      esc.appendChild(el);
      const s = { p, el, img: el.querySelector('img'), x: p.x, dir: Math.random() < .5 ? 1 : -1,
                  vel: 22 + Math.random() * 22, pausa: Math.random() * 2, brinco: 0, t: Math.random() * 10 };
      el.addEventListener('click', (e) => { e.stopPropagation(); tocar(s, esc); });
      return s;
    });
    const ajustar = () => {
      const k = marco.clientWidth / 1200;
      esc.style.transform = `scale(${k})`;
      esc.style.setProperty('--inv', Math.min(2.4, Math.max(1, .8 / k)).toFixed(2));   // globitos legibles en celular
    };
    new ResizeObserver(ajustar).observe(marco);
    ajustar();
    villas.push({ esc, gente, pinos, luces });
  });

  function decir(s, texto) {
    s.pausa = Math.max(s.pausa, 2.8);                  // se detiene a platicar
    const viejo = s.el.querySelector('.globo');
    if (viejo) viejo.remove();
    const g = document.createElement('span');
    g.className = 'globo';
    g.textContent = texto;
    s.el.appendChild(g);
    // que el globo no se salga del escenario: lo recorre a los lados y, si no cabe arriba, lo baja
    const w = g.offsetWidth, h = g.offsetHeight, izq = s.x - s.p.w / 2;
    const x = Math.max(8, Math.min(1192 - w, s.x - w / 2));
    g.style.left = (x - izq) + 'px';
    g.style.setProperty('--cola', (s.x - x) + 'px');
    const arriba = s.p.piso - s.p.h + 4;
    if (arriba - h - 14 < 6) { g.style.bottom = 'auto'; g.style.top = (6 - arriba) + 'px'; g.classList.add('abajo'); }
    setTimeout(() => g.remove(), 2900);
  }
  function festejar() {                              // cuando arranca la música, alguien lo celebra
    const gritos = ['¡Esa rola me encanta!', '¡A bailar se ha dicho!', '¡Súbele, súbele!', '¡Que viva la gala!'];
    for (const v of villas) decir(azar(v.gente), azar(gritos));
  }
  function seAcabo() {                               // y si alguien la pausa, también opinan
    const quejas = ['¡Ay! Me quedé a medio paso', '¿Y la música? ¿Quién la pausó?', 'Bueno, a pasear se ha dicho', 'Uff, un descansito para el ponche'];
    for (const v of villas) decir(azar(v.gente), azar(quejas));
  }
  function tocar(s, esc) {
    s.brinco = 0.7;
    const frases = s.p.frases.filter((f) => f !== s.ultima);
    s.ultima = azar(frases);
    decir(s, s.ultima);
    for (let i = 0; i < 4; i++) {
      const c = document.createElement('img');
      c.className = 'corazon';
      c.src = CORAZON;
      c.alt = '';
      c.style.left = (s.x - 11 + (Math.random() * 40 - 20)) + 'px';
      c.style.top = (s.p.piso - s.p.h - 10) + 'px';
      c.style.setProperty('--dx', (Math.random() * 60 - 30) + 'px');
      c.style.animationDelay = (i * .12) + 's';
      esc.appendChild(c);
      setTimeout(() => c.remove(), 2000 + i * 120);
    }
  }
  // Como en la villa original: corazoncitos que salen solos y Santa que pregunta cada rato
  const FRASES_SANTA = ['¡Jo jo jo!', '¿Te portaste bien?', '¡Estás en mi lista!', '¡Guárdame un tamal!'];
  function corazonSuelto(v) {
    const s = azar(v.gente);
    const c = document.createElement('img');
    c.className = 'corazon';
    c.src = CORAZON;
    c.alt = '';
    c.style.left = (s.x - 11 + (Math.random() * 30 - 15)) + 'px';
    c.style.top = (s.p.piso - s.p.h - 6) + 'px';
    c.style.setProperty('--dx', (Math.random() * 40 - 20) + 'px');
    v.esc.appendChild(c);
    setTimeout(() => c.remove(), 1800);
  }
  let fraseSanta = 0;
  if (!quieto) {
    setInterval(() => { for (const v of villas) corazonSuelto(v); }, 2300);
    setInterval(() => {
      for (const v of villas) {
        const santa = v.gente.find((s) => s.p.id === 'santa');
        if (santa && !santa.el.querySelector('.globo')) decir(santa, FRASES_SANTA[fraseSanta % FRASES_SANTA.length]);
      }
      fraseSanta++;
    }, 11000);
  }

  function notita(v) {                               // notas musicales que salen de los que bailan
    const s = azar(v.gente);
    const n = document.createElement('img');
    n.className = 'notita';
    n.src = azar(NOTAS);
    n.alt = '';
    n.style.left = (s.x - 17 + (Math.random() * 30 - 15)) + 'px';
    n.style.top = (s.p.piso - s.p.h - 20) + 'px';
    n.style.setProperty('--dx', (Math.random() * 80 - 40) + 'px');
    v.esc.appendChild(n);
    setTimeout(() => n.remove(), 2900);
  }

  // Cada quien con su paso, siempre al compás (b = tiempo en beats, f = fase dentro del beat, g = golpe del beat)
  const PASOS = {
    muneco: (b, f, g) => ({ dx: Math.sin(b * Math.PI) * 10, y: -Math.sin(f * Math.PI) * 6, r: Math.sin(b * Math.PI) * 9, sx: 1 + g * .05, sy: 1 - g * .07, cara: 0 }),
    pinguino: (b, f, g) => { const o = Math.sin(b * Math.PI); return { dx: 0, y: -Math.sin(f * Math.PI) * 9, r: Math.sign(o) * Math.sqrt(Math.abs(o)) * 15, sx: 1, sy: 1 - g * .05, cara: Math.floor(b / 4) % 2 ? -1 : 1 }; },
    oso: (b, f, g) => { const u = Math.sin(f * Math.PI); return { dx: 0, y: -u * 14, r: 0, sx: 1 + g * .12 - u * .03, sy: 1 - g * .14 + u * .06, cara: Math.floor(b / 2) % 2 ? -1 : 1 }; },
    reno: (b, f, g) => ({ dx: Math.sin(b * Math.PI / 2) * 24, y: -Math.sin(f * Math.PI) * 18, r: Math.sin(b * Math.PI) * 5, sx: 1, sy: 1 - g * .06, cara: Math.cos(b * Math.PI / 2) >= 0 ? 1 : -1 }),
    santa: (b, f, g) => ({ dx: Math.sin(b * Math.PI / 4) * 16, y: -Math.sin(f * Math.PI) * 7, r: Math.sin(b * Math.PI) * 7, sx: 1 + g * .06, sy: 1 - g * .08, cara: Math.floor(b / 4) % 2 ? -1 : 1 }),
    galleta: (b, f, g) => { const n = Math.floor(b); return { dx: 0, y: -Math.sin(f * Math.PI) * 22, r: Math.sin(b * Math.PI * 2) * 8, sx: n % 8 === 7 ? Math.cos(f * Math.PI * 2) : 1, sy: 1 - g * .1, cara: n % 2 ? -1 : 1 }; },
  };
  const PASO_BASE = (b, f, g) => ({ dx: 0, y: -Math.sin(f * Math.PI) * 10, r: 0, sx: 1, sy: 1 - g * .06, cara: 0 });

  // ── El Cascanueces y la bailarina
  const FRASES_T = { b: ['¡Un, dos, tres… giro!', '¡En puntitas!', '¿Bailamos otra?', '¡Feliz Navidad!'],
                     n: ['¡Crac! ¿Alguien trae nueces?', '¡Firmes, soldados!', '¡A sus órdenes, señorita!', '¡Jo, qué ritmo!'] };
  const HOGAR = { b: 760, n: 450 };
  const teatros = [];
  document.querySelectorAll('[data-teatro]').forEach((cont) => {
    const esc = document.createElement('div');
    esc.className = 'teatro-esc';
    esc.innerHTML = `<img class="fondo" alt="" src="${ESCENARIO}"><img class="pendulo" alt="" src="${PENDULO}">`;
    cont.appendChild(esc);
    const candilejas = [];
    for (let x = 24; x < 1200; x += 48) {
      const c = document.createElement('i');
      c.className = 'candileja';
      c.style.left = x + 'px';
      esc.appendChild(c);
      candilejas.push(c);
    }
    const quien = {};
    for (const k of ['n', 'b']) {
      const haz = document.createElement('div');
      haz.className = 'haz';
      esc.appendChild(haz);
      const ref = document.createElement('div');
      ref.className = 'reflector';
      ref.style.top = '424px';
      esc.appendChild(ref);
      const el = document.createElement('div');
      el.className = 'bailarin';
      const imgs = {};
      for (const [pose, src] of Object.entries(POSES[k])) {
        const im = document.createElement('img');
        im.src = src;
        im.alt = '';
        el.appendChild(im);
        imgs[pose] = im;
      }
      el.setAttribute('role', 'img');
      el.setAttribute('aria-label', k === 'b' ? 'La bailarina' : 'El Cascanueces');
      esc.appendChild(el);
      quien[k] = { k, el, imgs, haz, ref, x: HOGAR[k], actual: null, actualImg: null, brinco: 0 };
      el.addEventListener('click', (e) => { e.stopPropagation(); tocarBailarin(quien[k], esc); });
    }
    const ajustar = () => { esc.style.transform = `scale(${cont.clientWidth / 1200})`; };
    new ResizeObserver(ajustar).observe(cont);
    ajustar();
    teatros.push({ cont, esc, quien, candilejas, pendulo: esc.querySelector('.pendulo') });
  });
  function ponerPose(d, pose, volteo) {
    const clave = pose + volteo;
    if (d.actual === clave) return;
    if (d.actualImg) d.actualImg.classList.remove('on');
    const im = d.imgs[pose] || d.imgs[Object.keys(d.imgs)[0]];
    im.classList.add('on');
    im.classList.toggle('voltea', volteo < 0);
    d.actualImg = im;
    d.actual = clave;
  }
  function tramoDe(lista, t) {
    for (const s of lista) if (t >= s.i && t < s.i + s.d) return s;
    return lista[0];
  }
  function tocarBailarin(d, esc) {
    d.brinco = .6;
    const g = document.createElement('span');
    g.className = 'globo-t';
    g.textContent = azar(FRASES_T[d.k]);
    esc.appendChild(g);
    const w = g.offsetWidth;
    g.style.left = Math.max(8, Math.min(1192 - w, d.x - w / 2)) + 'px';
    g.style.top = (d.k === 'b' ? 150 : 120) + 'px';
    setTimeout(() => g.remove(), 2700);
    for (let i = 0; i < 6; i++) chispa(esc, d.x, 260);
  }
  function chispa(esc, x, y) {
    const c = document.createElement('i');
    c.className = 'chispa';
    c.style.left = (x - 6 + Math.random() * 40 - 20) + 'px';
    c.style.top = (y + Math.random() * 60 - 30) + 'px';
    c.style.setProperty('--dx', (Math.random() * 80 - 40) + 'px');
    c.style.setProperty('--dy', (-30 - Math.random() * 60) + 'px');
    esc.appendChild(c);
    setTimeout(() => c.remove(), 1500);
  }
  function bailarTeatro(T, b, g, nuevo, dt) {
    const funcion = baile > .5;
    T.cont.classList.toggle('funcion', funcion);
    T.pendulo.style.transform = `rotate(${(Math.sin(funcion ? b * Math.PI : reloj * 2.2) * 9).toFixed(2)}deg)`;
    if (funcion && nuevo) T.candilejas.forEach((c, i) => c.classList.toggle('on', (i + Math.floor(b)) % 2 === 0));
    for (const k of ['n', 'b']) {
      const d = T.quien[k];
      let pose, volteo = 1, x = HOGAR[k], y = 0;
      if (funcion) {                                 // la función: la coreografía al compás
        const t = ((b % COREO.tiempos) + COREO.tiempos) % COREO.tiempos;
        const s = tramoDe(COREO[k], t);
        const u = (t - s.i) / s.d;
        const fr = s.f[Math.min(s.f.length - 1, Math.floor(u * s.f.length))];
        pose = fr[0]; volteo = fr[1];
        x = s.x0 + (s.x1 - s.x0) * u;
        y = -s.h * Math.sin(Math.PI * u);
        if (nuevo && k === 'b' && pose.startsWith('passe') && Math.random() < .6) chispa(T.esc, d.x, 300);
      } else if (k === 'b') {                        // ensayo tranquilo: brazos que suben y bajan
        const fases = ['primera', 'brazos', 'segunda', 'brazos', 'primera', 'plie'];
        pose = fases[Math.floor(reloj / 1.6) % fases.length];
        y = pose === 'brazos' ? -3 : 0;
      } else {                                       // el cascanueces, firme… y de vez en cuando truena la mandíbula
        const c = reloj % 9;
        pose = c > 7.6 ? 'saludo' : (c % 3 < .28 ? 'firme_boca' : 'firme');
      }
      d.x += (x - d.x) * Math.min(1, dt * (funcion ? 30 : 2.5));
      if (d.brinco > 0) { y -= Math.sin((d.brinco / .6) * Math.PI) * 34; d.brinco -= dt; }
      ponerPose(d, pose, volteo);
      d.el.style.transform = `translate(${(d.x - 114).toFixed(1)}px, ${(150 + y).toFixed(1)}px)`;
      d.ref.style.transform = `translateX(${d.x.toFixed(1)}px) scale(${(1 + y / 160).toFixed(3)})`;
      d.haz.style.left = d.x.toFixed(1) + 'px';
    }
  }

  let tMusica = 0, ytVisto = -1, baile = 0, ultimoBeat = -1, antes = performance.now(), reloj = 0;
  function tiempoMusica(dt) {                        // reloj suave pegado al video de YouTube
    if (!sonando) return tMusica;
    tMusica += dt;
    try {
      const yt = player.getCurrentTime();
      if (typeof yt === 'number' && yt !== ytVisto) {
        ytVisto = yt;
        const err = yt - tMusica;
        if (Math.abs(err) > .35) tMusica = yt; else tMusica += err * .2;
      }
    } catch (e) {}
    return tMusica;
  }

  function cuadro(ahora) {
    const dt = Math.min(.05, (ahora - antes) / 1000);
    antes = ahora;
    reloj += dt;
    baile += ((sonando ? 1 : 0) - baile) * Math.min(1, dt * 5);
    const b = Math.max(0, tiempoMusica(dt) - fase) * bpm / 60, f = b - Math.floor(b), g = Math.pow(1 - f, 3);
    const beat = Math.floor(b);
    const nuevoBeat = sonando && beat !== ultimoBeat;
    if (nuevoBeat) ultimoBeat = beat;
    alCompas(beat, g, nuevoBeat, baile);
    for (const t of teatros) bailarTeatro(t, b, g, nuevoBeat, dt);
    for (const v of villas) {
      v.luces.style.opacity = (baile * (.12 + g * .26)).toFixed(3);
      if (nuevoBeat && baile > .6 && beat % 2 === 0) notita(v);
      for (const p of v.pinos) {
        const lado = p.i % 2 ? 1 : -1;
        const r = (1 - baile) * Math.sin(reloj * 1.6 + p.i * 1.3) * 1.6 + baile * Math.sin(b * Math.PI) * 7 * lado;
        p.el.style.transform = `rotate(${r.toFixed(2)}deg) scale(${(1 + baile * g * .04).toFixed(3)}, ${(1 - baile * g * .07).toFixed(3)})`;
      }
      for (const s of v.gente) {
        s.t += dt;
        let y = 0;
        if (!sonando && baile < .05) {                 // pasear, detenerse, voltearse
          if (s.pausa > 0) s.pausa -= dt;
          else {
            s.x += s.dir * s.vel * dt;
            y = (Math.floor(s.t * 4) % 2) ? -4 : 0;     // pasitos
            if (s.x < s.p.min || s.x > s.p.max) { s.dir *= -1; s.x = Math.max(s.p.min, Math.min(s.p.max, s.x)); }
            if (Math.random() < dt * .25) s.pausa = .6 + Math.random() * 1.8;
            if (Math.random() < dt * .08) s.dir *= -1;
          }
        }
        const m = (PASOS[s.p.id] || PASO_BASE)(b, f, g);
        const k = baile;
        if (s.brinco > 0) {                             // brinco al clic
          y -= Math.sin((s.brinco / .7) * Math.PI) * 40;
          s.brinco -= dt;
        }
        const cara = k > .5 && m.cara ? m.cara : s.dir;
        s.el.style.transform = `translate(${(s.x - s.p.w / 2 + m.dx * k).toFixed(1)}px, ${(y + m.y * k).toFixed(1)}px) ` +
          `rotate(${(m.r * k).toFixed(2)}deg) scale(${(1 + (m.sx - 1) * k).toFixed(3)}, ${(1 + (m.sy - 1) * k).toFixed(3)})`;
        s.img.style.transform = `scaleX(${cara})`;
      }
    }
    requestAnimationFrame(cuadro);
  }
  if (!quieto) requestAnimationFrame(cuadro);
  else for (const v of villas) for (const s of v.gente) s.el.style.transform = `translate(${s.x - s.p.w / 2}px,0)`;

  // ── Series de foquitos: titilan solitos y, con música, se prenden al compás
  const COLORES_FOCO = ['#ff4d5e', '#ffcf5a', '#5fe07a', '#7cc8ff', '#ff8fb8', '#fff1c4'];
  const series = [];
  document.querySelectorAll('.foquitos').forEach((cont, k) => {
    const n = +cont.dataset.focos || 24;
    const svgNS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(svgNS, 'svg');
    svg.setAttribute('viewBox', `0 0 ${n * 40} 60`);
    svg.setAttribute('preserveAspectRatio', 'none');
    let d = 'M0 6';
    for (let i = 0; i < n; i++) d += ` Q${i * 40 + 20} 34 ${(i + 1) * 40} 6`;
    svg.innerHTML = `<path d="${d}" fill="none" stroke="#1d4a2a" stroke-width="3" vector-effect="non-scaling-stroke"/>`;
    cont.appendChild(svg);
    const focos = [];
    for (let i = 0; i < n; i++) {
      const f = document.createElement('i');
      f.className = 'foco titila';
      f.style.left = ((i + .5) / n * 100) + '%';
      f.style.top = '19px';
      f.style.transform = `rotate(${(Math.random() * 16 - 8).toFixed(1)}deg)`;
      f.style.setProperty('--c', COLORES_FOCO[(i + k) % COLORES_FOCO.length]);
      f.style.setProperty('--d', (1.6 + Math.random() * 2.4).toFixed(2) + 's');
      f.style.animationDelay = (-Math.random() * 3).toFixed(2) + 's';
      cont.appendChild(f);
      focos.push(f);
    }
    series.push(focos);
  });
  const barras = [...document.querySelectorAll('#compas i')];
  let bailandoFocos = false;
  function alCompas(beat, g, nuevo, k) {               // lo llama el cuadro de la villa
    if (k > .5 && !bailandoFocos) { bailandoFocos = true; series.flat().forEach((f) => f.classList.remove('titila')); }
    if (k <= .5 && bailandoFocos) { bailandoFocos = false; series.flat().forEach((f) => { f.classList.add('titila'); f.classList.remove('apagado'); }); }
    if (bailandoFocos && nuevo) {
      series.forEach((focos) => focos.forEach((f, i) => f.classList.toggle('apagado', (i + beat) % 3 === 0)));   // persecución
    }
    barras.forEach((b, i) => {
      const h = k > .1 ? 4 + 12 * k * Math.max(0, g * (1 - Math.abs(i - 3.5) / 5) + .25 * Math.random()) : 4;
      b.style.height = h.toFixed(1) + 'px';
    });
  }

  // ── Ambiente: lluvia de ceros y unos (en colores navideños) atrás, y nieve al frente
  const lluvia = $('lluvia'), lctx = lluvia.getContext('2d');
  const nieve = $('nieve'), nctx = nieve.getContext('2d');
  const TONOS = ['95,224,122', '255,207,90', '255,77,94', '255,244,230'];
  let columnas = [], copos = [], tLluvia = 0;
  const copo = document.createElement('canvas');      // un copo difuminado que se reutiliza
  copo.width = copo.height = 32;
  { const c = copo.getContext('2d'), gr = c.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, 'rgba(255,253,248,1)'); gr.addColorStop(.4, 'rgba(255,252,245,.85)'); gr.addColorStop(1, 'rgba(255,252,245,0)');
    c.fillStyle = gr; c.fillRect(0, 0, 32, 32); }
  const PASO_COL = 22;
  function medir() {
    lluvia.width = nieve.width = innerWidth;
    lluvia.height = nieve.height = innerHeight;
    columnas = Array.from({ length: Math.ceil(innerWidth / PASO_COL) }, () => ({
      y: Math.random() * innerHeight, v: 40 + Math.random() * 90, largo: 8 + Math.floor(Math.random() * 16),
      tono: azar(TONOS), bits: Array.from({ length: 40 }, () => (Math.random() < .5 ? '0' : '1')),
    }));
    copos = Array.from({ length: Math.round(innerWidth * innerHeight / 14000) }, () => {
      const cerca = Math.random() < .2;
      return { x: Math.random() * innerWidth, y: Math.random() * innerHeight, r: cerca ? 3 + Math.random() * 2.5 : 1 + Math.random() * 1.8,
               a: cerca ? .55 + Math.random() * .3 : .6 + Math.random() * .4, v: cerca ? .7 + Math.random() * .6 : .3 + Math.random() * .7, f: Math.random() * 6.28 };
    });
  }
  let antesAmb = performance.now();
  function ambiente(ahora) {
    const t = ahora || performance.now(), dt = Math.max(0, Math.min(.05, (t - antesAmb) / 1000)); antesAmb = t;
    tLluvia += dt;
    lctx.clearRect(0, 0, lluvia.width, lluvia.height);
    lctx.font = '14px "JetBrains Mono", monospace';
    lctx.textAlign = 'center';
    for (let c = 0; c < columnas.length; c++) {
      const col = columnas[c];
      col.y += col.v * dt;
      if (col.y - col.largo * 18 > lluvia.height) { col.y = -Math.random() * 300; col.tono = azar(TONOS); }
      if (Math.random() < .02) col.bits[Math.floor(Math.random() * col.bits.length)] = Math.random() < .5 ? '0' : '1';
      for (let k = 0; k < col.largo; k++) {
        const y = col.y - k * 18;
        if (y < -18 || y > lluvia.height + 18) continue;
        const a = k === 0 ? .55 : .26 * (1 - k / col.largo);
        lctx.fillStyle = k === 0 ? `rgba(255,248,225,${a})` : `rgba(${col.tono},${a})`;
        lctx.fillText(col.bits[(Math.floor(y / 18) + 400) % col.bits.length], c * PASO_COL + PASO_COL / 2, y);
      }
    }
    nctx.clearRect(0, 0, nieve.width, nieve.height);
    for (const c of copos) {
      c.y += c.v; c.f += .015; c.x += Math.sin(c.f) * .5;
      if (c.y > nieve.height + 8) { c.y = -8; c.x = Math.random() * nieve.width; }
      nctx.globalAlpha = c.a;
      nctx.drawImage(copo, c.x - c.r * 2, c.y - c.r * 2, c.r * 4, c.r * 4);
    }
    nctx.globalAlpha = 1;
    if (!quieto) requestAnimationFrame(ambiente);
  }
  addEventListener('resize', medir);
  medir();
  ambiente();
})();
</script>
</body>
</html>
"""


def svg_uri(texto):
    return "data:image/svg+xml;base64," + base64.b64encode(texto.encode()).decode()


def datos_pinos():
    """Los pinos de atrás de la villa: van aparte para que también se mezan y bailen."""
    p = P.pino()
    return [{"x": x, "y": P.PISO_ATRAS - p.h * e + 2, "w": p.w * e, "h": p.h * e,
             "src": svg("personajes/pino.svg")} for x, e in P.POS_PINOS]


def poses_ballet():
    b, c = ballet.todas()
    return {"b": {k: svg_uri(ballet.pose_svg(sp)) for k, sp in b.items()},
            "n": {k: svg_uri(ballet.pose_svg(sp)) for k, sp in c.items()}}


def pendulo_svg():
    """El péndulo del reloj (se mece solo; con música, al compás)."""
    esc = ballet.escenario()
    pix = {(x - 302 - 12 + 15, y - 80): c for (x, y), c in esc.capas["pendulo"].items()}
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 46" width="90" height="138" shape-rendering="crispEdges">'
            f'{ballet.trazo(pix)}</svg>')


def main():
    import gala
    corazon = P.corazon()
    corazon_svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 7 6" shape-rendering="crispEdges">'
                   f'{P.trazo(corazon.capas["base"])}</svg>')
    icono = P.pino()
    icono_svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 36" shape-rendering="crispEdges">'
                 + "".join(P.trazo(icono.capas[c]) for c in icono.orden) + "</svg>")
    fuente = lambda nombre: uri(AQUI / "fuente" / nombre, "font/woff2")  # noqa: E731
    titulo = "".join(f'<span style="animation-delay:{k * .09:.2f}s"{" class=\"oro\"" if k > 5 else ""}>{c}</span>'
                     if c != " " else "<br>" for k, c in enumerate("FELIZ NAVIDAD"))
    ecualizador = "".join(f'<i style="animation-delay:{-(k * 137 % 50) / 100:.2f}s;animation-duration:{.32 + (k * 53 % 30) / 100:.2f}s"></i>'
                          for k in range(18))
    reemplazos = {
        "@@PS2P@@": fuente("PressStart2P-Regular.woff2"),
        "@@F_MONO@@": fuente("JetBrainsMono-Regular.woff2"),
        "@@F_FREDOKA@@": fuente("Fredoka-SemiBold.woff2"),
        "@@ICONO@@": svg_uri(icono_svg),
        "@@CORAZON@@": svg_uri(corazon_svg),
        "@@ACEBO@@": svg_uri(gala.acebo()),
        "@@NOTA1@@": svg_uri(gala.nota()),
        "@@NOTA2@@": svg_uri(gala.nota(True, "#ffd0c4", "#c8172f")),
        "@@BANNER@@": svg("banner.svg"),
        "@@FONDO@@": svg("pueblo-fondo.svg"),
        "@@ASCII@@": svg("arbol-escena.svg"),
        "@@PERSONAJES@@": json.dumps(datos_pueblo(), ensure_ascii=False),
        "@@PINOS@@": json.dumps(datos_pinos()),
        "@@TITULO@@": titulo,
        "@@ECUALIZADOR@@": ecualizador,
        "@@VIDEO@@": VIDEO,
        "@@LISTA@@": LISTA,
        "@@COREO@@": json.dumps(ballet.coreo_json()),
        "@@POSES@@": json.dumps(poses_ballet()),
        "@@ESCENARIO@@": svg_uri(ballet.escenario_svg(sin=("candilejas", "pendulo"))),
        "@@PENDULO@@": svg_uri(pendulo_svg()),
        "@@BELEN@@": svg("nacimiento.svg"),
    }
    html = PLANTILLA
    for k, v in reemplazos.items():
        html = html.replace(k, v)
    assert "@@" not in html, html[html.index("@@") - 40:html.index("@@") + 40]
    SALIDA.parent.mkdir(exist_ok=True)
    SALIDA.write_text(html, encoding="utf-8")
    print(f"pagina/index.html  ({len(html.encode()) / 1e6:.2f} MB)")


if __name__ == "__main__":
    main()
