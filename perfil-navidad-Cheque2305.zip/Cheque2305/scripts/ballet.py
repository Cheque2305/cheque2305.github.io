#!/usr/bin/env python3
"""El Cascanueces y la bailarina: pixel art con esqueleto, para que bailen pose por pose.

Cada pose es una lista de ángulos (0° = hacia abajo, positivo = hacia la derecha); el motor
dibuja las extremidades como "cápsulas" con luz y sombra y les pone contorno, igual que a los
personajes de La Villa de Santa.

    python3 scripts/ballet.py          # escribe assets/ballet/*.svg, assets/cascanueces.svg y una hoja de poses
"""
import math
from pathlib import Path

from pixel import CONTORNO, NEGRO, NIEVE, ORO, PIEL, ROJO, VERDE, Sprite

AQUI = Path(__file__).resolve().parent
ASSETS = AQUI.parent / "assets"

ROSA_T = ("#ffe0ec", "#ff9cc4", "#e0648f", "#a83a66")
TUTU = ("#ffffff", "#ffd3e6", "#f4a3c4", "#d27aa0")
MEDIA = ("#ffe8e6", "#f6c8c8", "#dca2a6", "#b47c84")
ZAPATILLA = ("#ffd6e4", "#f4a6c0", "#d07898", "#a85a78")
PELO = ("#9a6438", "#6e4024", "#4a2814", "#2e180c")
MADERA = ("#ffe8cc", "#f6d2ae", "#ddb08a", "#b88866")      # la cara de madera del cascanueces
MEJILLA = "#f2787c"

W, H = 76, 104                                                # lienzo de cada pose
PISO = 100


# ───────────────────────── motor de esqueleto ─────────────────────────
def punta(p, largo, ang):
    """Desde p, avanza 'largo' con ángulo 'ang' (0 = abajo, 90 = derecha, 180 = arriba)."""
    a = math.radians(ang)
    return (p[0] + math.sin(a) * largo, p[1] + math.cos(a) * largo)


def capsula(sp, a, b, r0, r1, tonos, luz=(-.6, -.8)):
    """Extremidad redondeada de a hasta b (radio r0 → r1) con brillo y sombra."""
    (x0, y0), (x1, y1) = a, b
    dx, dy = x1 - x0, y1 - y0
    L2 = dx * dx + dy * dy or 1e-6
    rmax = max(r0, r1)
    for y in range(math.floor(min(y0, y1) - rmax - 1), math.ceil(max(y0, y1) + rmax + 1)):
        for x in range(math.floor(min(x0, x1) - rmax - 1), math.ceil(max(x0, x1) + rmax + 1)):
            px, py = x + .5, y + .5
            t = max(0.0, min(1.0, ((px - x0) * dx + (py - y0) * dy) / L2))
            cx, cy = x0 + dx * t, y0 + dy * t
            r = r0 + (r1 - r0) * t
            d = math.hypot(px - cx, py - cy)
            if d > r:
                continue
            nx, ny = (px - cx) / max(r, .5), (py - cy) / max(r, .5)
            s = nx * luz[0] + ny * luz[1]
            c = tonos[0] if s > .45 else (tonos[2] if s < -.35 else tonos[1])
            sp.px(x, y, c)


def disco(sp, cx, cy, rx, ry, tonos):
    sp.elipse(cx, cy, rx, ry, tonos)


def oval(sp, cx, cy, rx, ry, c):
    for y in range(math.floor(cy - ry), math.ceil(cy + ry) + 1):
        for x in range(math.floor(cx - rx), math.ceil(cx + rx) + 1):
            if ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2 <= 1:
                sp.px(x, y, c)


# ───────────────────────── la bailarina ─────────────────────────
#   cadera: (dx, dy) del centro, torso: inclinación, cabeza: inclinación extra
#   bi/bd: brazo izquierdo/derecho (hombro, codo) · pi/pd: pierna (cadera, rodilla) · punta: de pie en puntas
BAILARINA = {
    "primera":     dict(t=0, ci=0, bi=(-14, 10), bd=(14, -10), pi=(-4, 0), pd=(4, 0), puntas=False, cara=1),
    "brazos":      dict(t=0, ci=-4, bi=(-128, -205), bd=(128, 205), pi=(-4, 0), pd=(4, 0), puntas=True, cara=1),
    "plie":        dict(t=0, ci=0, bi=(-80, -95), bd=(80, 95), pi=(-30, 25), pd=(30, -25), puntas=False, baja=6, cara=1),
    "segunda":     dict(t=0, ci=3, bi=(-95, -105), bd=(95, 105), pi=(-14, -14), pd=(14, 14), puntas=True, cara=1),
    "arabesque":   dict(t=22, ci=-10, bi=(-120, -120), bd=(70, 82), pi=(-82, -84), pd=(2, 2), puntas=True, cara=1),
    "attitude":    dict(t=8, ci=-6, bi=(-132, -200), bd=(100, 110), pi=(-80, -150), pd=(2, 2), puntas=True, cara=1),
    "passe":       dict(t=0, ci=0, bi=(-128, -205), bd=(128, 205), pi=(-2, -2), pd=(70, -40), puntas=True, cara=1),
    "passe_lado":  dict(t=0, ci=0, bi=(-128, -205), bd=(128, 205), pi=(-2, -2), pd=(70, -40), puntas=True, cara=0),
    "passe_atras": dict(t=0, ci=0, bi=(-128, -205), bd=(128, 205), pi=(-2, -2), pd=(70, -40), puntas=True, cara=-1),
    "jete":        dict(t=10, ci=-6, bi=(-115, -110), bd=(115, 110), pi=(-95, -95), pd=(80, 82), puntas=True, aire=True, cara=1),
    "reverencia":  dict(t=28, ci=12, bi=(-50, -60), bd=(48, 58), pi=(-20, -40), pd=(18, 10), puntas=False, baja=4, cara=1),
    "mano":        dict(t=-4, ci=-4, bi=(-95, -100), bd=(130, 200), pi=(-2, -2), pd=(16, 18), puntas=True, cara=1),
    "salto":       dict(t=0, ci=-6, bi=(-132, -200), bd=(132, 200), pi=(-20, -60), pd=(20, 60), puntas=True, aire=True, cara=1),
}


def bailarina(nombre):
    p = BAILARINA[nombre]
    sp = Sprite(W, H)
    largo_muslo, largo_pierna = 15, 15
    alto_pierna = largo_muslo + largo_pierna + (3 if p["puntas"] else 1)
    cad = (W / 2, PISO - alto_pierna + p.get("baja", 0))
    if p.get("aire"):
        cad = (cad[0], cad[1] - 2)
    t = p["t"]
    cuello = punta(cad, 20, 180 + t)
    hombro_i, hombro_d = punta(cuello, 5, 180 + t + 90), punta(cuello, 5, 180 + t - 90)
    hombro_i = (hombro_i[0], hombro_i[1] + 2)
    hombro_d = (hombro_d[0], hombro_d[1] + 2)

    def pierna(lado, angs, capa):
        sp.capa(capa)
        a1, a2 = angs
        cadera = (cad[0] + lado * 3.5, cad[1])
        rod = punta(cadera, largo_muslo, a1)
        pie = punta(rod, largo_pierna, a2)
        capsula(sp, cadera, rod, 3.6, 3, MEDIA)
        capsula(sp, rod, pie, 3, 2.2, MEDIA)
        fin = punta(pie, 4.5 if p["puntas"] or abs(a2) > 30 else 3, a2 if (p["puntas"] or abs(a2) > 30) else a2 + lado * 70)
        capsula(sp, pie, fin, 2.4, 2, ZAPATILLA)
        sp.contorno()
        return pie

    def brazo(hombro, angs, capa):
        sp.capa(capa)
        a1, a2 = angs
        codo = punta(hombro, 12, a1)
        mano = punta(codo, 12, a2)
        capsula(sp, hombro, codo, 2.4, 2, PIEL)
        capsula(sp, codo, mano, 2, 1.8, PIEL)
        oval(sp, mano[0], mano[1], 2.2, 2.2, PIEL[1])
        sp.contorno()

    # lo de atrás: pierna y brazo izquierdos
    pierna(-1, p["pi"], "pierna_atras")
    if p["cara"] >= 0:
        brazo(hombro_i, p["bi"], "brazo_atras")
    pierna(1, p["pd"], "pierna_frente")
    # torso (corpiño rosa) y tutú
    sp.capa("cuerpo")
    capsula(sp, punta(cad, 2, 180 + t), punta(cuello, 3, t), 6, 7, ROSA_T)
    capsula(sp, punta(cuello, 1, t), punta(cuello, 4, 180 + t), 2.4, 2.4, PIEL)          # cuello
    for k in range(5):                                                                 # brillitos dorados en el corpiño
        x, y = punta(cad, 5 + k * 3, 180 + t)
        sp.px(round(x + (1 if k % 2 else -2)), round(y), ORO[0])
    sp.contorno()
    sp.capa("tutu")
    tx, ty = punta(cad, 1, 180 + t)
    ang_tutu = math.radians(t)
    for y in range(-9, 10):
        for x in range(-24, 25):
            xr = x * math.cos(ang_tutu) + y * math.sin(ang_tutu)
            yr = -x * math.sin(ang_tutu) + y * math.cos(ang_tutu)
            d = (xr / 22) ** 2 + (yr / 5.5) ** 2
            if d <= 1:
                borde = abs(xr) > 18 and ((round(xr) + round(yr)) % 3 == 0)
                if yr < -1.8:
                    c = TUTU[0]
                elif yr > 2.2:
                    c = TUTU[3] if d > .55 else TUTU[2]
                else:
                    c = TUTU[1] if not borde else TUTU[0]
                sp.px(round(tx + x), round(ty + y), c)
    for k in range(-3, 4):                                                             # pliegues del tutú
        x, y = tx + k * 6, ty + 3
        sp.px(round(x), round(y), TUTU[2])
    sp.px(round(tx - 8), round(ty - 2), ORO[0])
    sp.px(round(tx + 9), round(ty - 1), ORO[0])
    sp.contorno()
    # cabeza: cara, chongo con coronita
    sp.capa("cabeza")
    cab = punta(cuello, 9, 180 + t + p["ci"])
    if p["cara"] == -1:                                                                 # de espaldas: puro pelo
        sp.elipse(cab[0], cab[1], 8.4, 8.6, PELO)
    else:
        sp.elipse(cab[0], cab[1], 8, 8.6, PIEL)
        sp.elipse(cab[0], cab[1] - 4, 8.6, 5.2, PELO, dentro=lambda x, y: y <= cab[1] - 2)
        lado = p["cara"]
        if lado == 1:
            sp.pts([(round(cab[0] - 3), round(cab[1] + 1)), (round(cab[0] + 3), round(cab[1] + 1))], CONTORNO)
            sp.pts([(round(cab[0] - 3), round(cab[1])), (round(cab[0] + 3), round(cab[1]))], CONTORNO)
            sp.pts([(round(cab[0] - 5), round(cab[1] + 3)), (round(cab[0] + 4), round(cab[1] + 3))], MEJILLA)
            sp.pts([(round(cab[0] - 1), round(cab[1] + 4)), (round(cab[0]), round(cab[1] + 5)), (round(cab[0] + 1), round(cab[1] + 4))], ROJO[2])
        else:                                                                           # de perfil
            sp.pts([(round(cab[0] + 3), round(cab[1])), (round(cab[0] + 3), round(cab[1] + 1))], CONTORNO)
            sp.px(round(cab[0] + 4), round(cab[1] + 3), MEJILLA)
            sp.elipse(cab[0] - 3, cab[1] - 1, 5, 6, PELO)
    sp.elipse(cab[0], cab[1] - 10, 4.4, 3.6, PELO)                                     # chongo
    for k, c in enumerate((ORO[0], ORO[1], "#ff5c8a", ORO[1], ORO[0])):                  # coronita
        sp.px(round(cab[0] - 4 + k * 2), round(cab[1] - 7 - (k % 2)), c)
    sp.contorno()
    if p["cara"] < 0:
        brazo(hombro_i, p["bi"], "brazo_atras2")
    brazo(hombro_d, p["bd"], "brazo_frente")
    return sp


# ───────────────────────── el cascanueces ─────────────────────────
CASCANUECES = {
    "firme":      dict(t=0, bi=(-6, -4), bd=(6, 4), pi=(-1, -1), pd=(1, 1), boca=False),
    "firme_boca": dict(t=0, bi=(-6, -4), bd=(6, 4), pi=(-1, -1), pd=(1, 1), boca=True),
    "marcha_a":   dict(t=0, bi=(-40, -60), bd=(30, 10), pi=(-80, 0), pd=(2, 2), boca=False, sube=0),
    "marcha_b":   dict(t=0, bi=(-30, -10), bd=(40, 60), pi=(-2, -2), pd=(80, 0), boca=True, sube=0),
    "saludo":     dict(t=0, bi=(-6, -4), bd=(118, 212), pi=(-1, -1), pd=(1, 1), boca=False),
    "mano":       dict(t=-4, bi=(-30, 20), bd=(95, 100), pi=(-3, -3), pd=(6, 6), boca=True),
    "arriba":     dict(t=0, bi=(-142, -168), bd=(142, 168), pi=(-14, -14), pd=(14, 14), boca=True),
    "reverencia": dict(t=34, bi=(-20, -40), bd=(80, 140), pi=(-6, -6), pd=(10, 10), boca=False),
    "salto":      dict(t=0, bi=(-120, -132), bd=(120, 132), pi=(-30, -10), pd=(30, 10), boca=True, aire=True),
}


def cascanueces(nombre):
    p = CASCANUECES[nombre]
    sp = Sprite(W, H)
    largo = 22
    cad = (W / 2, PISO - largo - 3)
    t = p["t"]
    cuello = punta(cad, 24, 180 + t)

    def pierna(lado, angs, capa):
        sp.capa(capa)
        a1, a2 = angs
        cadera = (cad[0] + lado * 5, cad[1])
        rod = punta(cadera, 11, a1)
        pie = punta(rod, 11, a2)
        capsula(sp, cadera, rod, 4.2, 4, ROJO)
        capsula(sp, rod, pie, 4, 4, NEGRO)                                              # botas
        for k in range(2):                                                              # agujetas doradas
            x, y = punta(rod, 3 + k * 3, a2)
            sp.px(round(x), round(y), ORO[1])
        bota = punta(pie, 4, a2 + lado * 0 + 90 * (1 if lado > 0 else -1) * 0 + 90)
        capsula(sp, pie, bota, 3.6, 3, NEGRO)
        sp.contorno()

    def brazo(hombro, angs, capa):
        sp.capa(capa)
        a1, a2 = angs
        codo = punta(hombro, 10, a1)
        mano = punta(codo, 9, a2)
        capsula(sp, hombro, codo, 3.6, 3.2, ROJO)
        capsula(sp, codo, mano, 3.2, 3, ROJO)
        x, y = punta(codo, 6, a2)
        oval(sp, x, y, 3.2, 3.2, ORO[1])                                                 # puño dorado
        sp.elipse(mano[0], mano[1], 3.2, 3.2, NIEVE)                                    # guante blanco
        sp.contorno()

    hombro_i = punta(punta(cuello, 3, t), 9, 180 + t + 90)
    hombro_d = punta(punta(cuello, 3, t), 9, 180 + t - 90)
    brazo(hombro_i, p["bi"], "brazo_atras")
    pierna(-1, p["pi"], "pierna_atras")
    pierna(1, p["pd"], "pierna_frente")
    # casaca roja con peto verde, cinturón negro y botones dorados
    sp.capa("cuerpo")
    capsula(sp, punta(cad, 1, 180 + t), punta(cuello, 2, t), 9.5, 10, ROJO)
    for k in range(9):
        x, y = punta(cad, 2 + k * 2.4, 180 + t)
        for dx in (-3, -2, -1, 0, 1, 2, 3):
            sp.px(round(x + dx * math.cos(math.radians(t))), round(y + dx * math.sin(math.radians(t))),
                  VERDE[0] if dx == -3 else (VERDE[2] if dx == 3 else VERDE[1]))
        for dx in (-5, 5):
            if k % 2 == 0:
                sp.px(round(x + dx * math.cos(math.radians(t))), round(y + dx * math.sin(math.radians(t))), ORO[0])
    for k in range(-8, 9):                                                               # cinturón
        x, y = punta(cad, 3, 180 + t)
        a = math.radians(t)
        sp.px(round(x + k * math.cos(a)), round(y + k * math.sin(a)), NEGRO[1])
        sp.px(round(x + k * math.cos(a) - math.sin(a)), round(y + k * math.sin(a) + math.cos(a)), NEGRO[2])
    x, y = punta(cad, 3, 180 + t)
    sp.rect(round(x) - 2, round(y) - 1, round(x) + 2, round(y) + 1, ORO[1])
    sp.px(round(x), round(y), NEGRO[1])
    for lado in (-1, 1):                                                                 # charreteras doradas
        x, y = punta(punta(cuello, 3, t), 9, 180 + t + 90 * lado)
        sp.elipse(x, y, 4.4, 2.6, ORO)
        for k in range(-3, 4):
            sp.px(round(x + k), round(y + 3), ORO[2] if k % 2 else ORO[1])
    sp.contorno()
    # cabeza de madera: pelo y barba blancos, bigotote, dientes y corona roja
    sp.capa("cabeza")
    cab = punta(cuello, 9, 180 + t)
    cx, cy = cab
    sp.elipse(cx - 7, cy + 2, 3.6, 7, NIEVE)                                             # pelo blanco a los lados
    sp.elipse(cx + 7, cy + 2, 3.6, 7, NIEVE)
    sp.rect(round(cx - 6), round(cy - 6), round(cx + 6), round(cy + 8), MADERA[1])      # cara cuadradita
    sp.rect(round(cx - 6), round(cy - 6), round(cx - 5), round(cy + 8), MADERA[0])
    sp.rect(round(cx + 5), round(cy - 6), round(cx + 6), round(cy + 8), MADERA[2])
    sp.pts([(round(cx - 3), round(cy - 2)), (round(cx + 3), round(cy - 2))], CONTORNO)          # ojos
    sp.pts([(round(cx - 3), round(cy - 3)), (round(cx + 3), round(cy - 3))], "#3f8fe0")
    sp.pts([(round(cx - 4), round(cy - 5)), (round(cx - 3), round(cy - 5)), (round(cx - 2), round(cy - 5)),
            (round(cx + 2), round(cy - 5)), (round(cx + 3), round(cy - 5)), (round(cx + 4), round(cy - 5))], NEGRO[1])  # cejas
    sp.pts([(round(cx - 5), round(cy + 1)), (round(cx + 5), round(cy + 1))], MEJILLA)
    sp.pts([(round(cx), round(cy - 1)), (round(cx), round(cy))], MADERA[2])                     # nariz
    for k in range(-5, 6):                                                               # bigotote
        sp.px(round(cx + k), round(cy + 2 - (abs(k) > 3)), NEGRO[1] if abs(k) < 5 else NEGRO[0])
        sp.px(round(cx + k), round(cy + 3 - (abs(k) > 3)), NEGRO[2])
    boca_alto = 4 if p["boca"] else 2
    sp.rect(round(cx - 3), round(cy + 4), round(cx + 3), round(cy + 4 + boca_alto), NIEVE[0])  # dientes
    if p["boca"]:
        sp.rect(round(cx - 2), round(cy + 6), round(cx + 2), round(cy + 6), CONTORNO)
    for k in range(-4, 5):                                                               # barba blanca
        sp.px(round(cx + k), round(cy + 9 + boca_alto - 2), NIEVE[1] if k % 2 else NIEVE[0])
        if abs(k) < 3:
            sp.px(round(cx + k), round(cy + 10 + boca_alto - 2), NIEVE[2])
    sp.contorno()
    sp.capa("corona")
    top = cy - 7
    sp.rect(round(cx - 7), round(top - 12), round(cx + 7), round(top), ROJO[1])           # corona de terciopelo
    sp.rect(round(cx - 7), round(top - 12), round(cx - 6), round(top), ROJO[0])
    sp.rect(round(cx + 6), round(top - 12), round(cx + 7), round(top), ROJO[2])
    sp.rect(round(cx - 8), round(top - 2), round(cx + 8), round(top), ORO[1])             # banda dorada
    sp.rect(round(cx - 8), round(top - 2), round(cx + 8), round(top - 2), ORO[0])
    for x in range(round(cx - 6), round(cx + 7), 3):
        sp.px(x, round(top - 1), ROJO[1] if x % 2 else VERDE[1])                         # joyitas
    for k in (-6, -2, 2, 6):
        sp.px(round(cx + k), round(top - 13), ORO[1])                                   # picos
        sp.px(round(cx + k), round(top - 6), ORO[2])
    sp.elipse(cx, top - 15, 2.6, 2.6, ORO)                                               # bolita
    sp.contorno()
    brazo(hombro_d, p["bd"], "brazo_frente")
    return sp


# ───────────────────────── el escenario ─────────────────────────
EW, EH, EP = 400, 174, 3                                  # escenario: 400x174 pixeles grandes (1200x522)
PISO_ESC = 150                                            # dónde pisan los bailarines


def escenario():
    """Teatrito navideño: telón rojo, cielo nevado al fondo, el árbol gigante y el reloj de la medianoche."""
    import random
    from pixel import AZUL, CAFE
    r = random.Random(12)
    sp = Sprite(EW, EH)
    sp.capa("fondo")
    cielo = ["#0a1230", "#0e1a40", "#132250", "#182b60", "#1e3570", "#26407e", "#2f4c8a"]
    for y in range(PISO_ESC):
        for x in range(EW):
            t = y / PISO_ESC * (len(cielo) - 1) + ((x * 3 + y * 5) % 4) * .14
            sp.px(x, y, cielo[min(len(cielo) - 1, int(t))])
    for _ in range(120):
        sp.px(r.randrange(EW), r.randrange(100), r.choice(["#ffffff", "#cfe0ff", "#ffe9a8", "#8fa6dc"]))
    for x in range(EW):                                   # lomitas nevadas
        h1 = int(118 + 7 * math.sin(x / 23) + 4 * math.sin(x / 9))
        h2 = int(128 + 5 * math.sin(x / 31 + 2) + 3 * math.sin(x / 7))
        for y in range(h1, PISO_ESC):
            sp.px(x, y, "#5a6ea8" if y < h1 + 2 else "#3e5290")
        for y in range(h2, PISO_ESC):
            sp.px(x, y, "#c8d6f2" if y < h2 + 2 else ("#9fb2e0" if (x + y) % 5 else "#b4c4ea"))
    # el árbol gigante (el que crece a medianoche)
    cx = 104
    for k, (top, base, ancho) in enumerate(((22, 52, 14), (38, 76, 22), (58, 102, 30), (80, 130, 40))):
        sp.poligono([(cx, top), (cx + ancho, base), (cx - ancho, base)], VERDE[1])
    sp.recolorear(lambda x, y, c: c == VERDE[1] and x > cx + 3, lambda x, y, c: VERDE[2])
    sp.recolorear(lambda x, y, c: c == VERDE[1] and x < cx - 6 and (x + y) % 3 == 0, lambda x, y, c: VERDE[0])
    for base, ancho in ((52, 14), (76, 22), (102, 30), (130, 40)):
        for x in range(cx - ancho + 1, cx + ancho):
            if (x * 7) % 5 < 3:
                sp.px(x, base - 1, NIEVE[0] if x < cx + 2 else NIEVE[1])
    for k in range(60):                                   # guirnalda dorada y esferas
        y = r.randint(28, 126)
        lim = int((y - 18) * .36)
        x = cx + r.randint(-lim + 2, lim - 2)
        sp.px(x, y, r.choice([ROJO[0], ORO[0], "#9ad6ff", "#ff8fb8", "#ffffff"]))
    for y in range(36, 126, 18):
        lim = int((y - 18) * .36)
        for x in range(cx - lim + 3, cx + lim - 3):
            if (x + y // 3) % 2 == 0:
                sp.px(x, y + (x - cx) // 6, ORO[1])
    sp.rect(cx - 5, 130, cx + 5, 140, CAFE[1])
    sp.rect(cx - 5, 130, cx - 4, 140, CAFE[0])
    sp.contorno()
    sp.capa("estrella")
    sp.pts([(cx, 14), (cx, 15), (cx, 16), (cx, 17), (cx, 18), (cx - 2, 16), (cx - 1, 16), (cx + 1, 16), (cx + 2, 16),
            (cx - 1, 15), (cx + 1, 15), (cx - 1, 17), (cx + 1, 17)], ORO[0])
    sp.px(cx, 16, "#ffffff")
    sp.capa("fondo")
    # regalitos al pie del árbol
    for x0, w, h, caja, liston in ((70, 14, 10, ROJO, ORO), (86, 10, 8, VERDE, ROJO), (118, 12, 12, ORO, ROJO), (132, 9, 7, AZUL, NIEVE)):
        y0 = 141 - h
        sp.rect(x0, y0, x0 + w, 141, caja[1])
        sp.rect(x0, y0, x0 + 1, 141, caja[0])
        sp.rect(x0 + w - 1, y0, x0 + w, 141, caja[2])
        sp.rect(x0 + w // 2, y0, x0 + w // 2 + 1, 141, liston[1])
        sp.pts([(x0 + w // 2 - 2, y0 - 1), (x0 + w // 2 + 3, y0 - 1), (x0 + w // 2 - 1, y0 - 2), (x0 + w // 2 + 2, y0 - 2)], liston[0])
    # el reloj de la medianoche
    sp.capa("reloj")
    rx = 302
    sp.rect(rx, 50, rx + 24, 141, CAFE[1])
    sp.rect(rx, 50, rx + 2, 141, CAFE[0])
    sp.rect(rx + 22, 50, rx + 24, 141, CAFE[2])
    sp.poligono([(rx - 3, 50), (rx + 12, 38), (rx + 27, 50)], CAFE[2])
    sp.elipse(rx + 12, 62, 9, 9, ("#fff8e6", "#f6e6c4", "#d8c49a"))
    for k in range(12):
        a = k / 12 * math.tau
        sp.px(round(rx + 12 + math.sin(a) * 7), round(62 - math.cos(a) * 7), NEGRO[1])
    sp.linea(rx + 12, 62, rx + 12, 56, NEGRO[1])          # las doce en punto
    sp.linea(rx + 12, 62, rx + 12, 58, NEGRO[2])
    sp.rect(rx + 6, 78, rx + 18, 130, "#3a2214")
    sp.contorno()
    sp.capa("pendulo")
    sp.linea(rx + 12, 80, rx + 12, 118, ORO[2])
    sp.elipse(rx + 12, 121, 4, 4, ORO)
    # el piso del escenario
    sp.capa("piso")
    for y in range(141, 166):
        for x in range(EW):
            tabla = (x + (y // 6) * 37) % 52
            c = "#8a5a32" if (y // 6) % 2 else "#7a4e2a"
            if tabla == 0 or y % 6 == 0:
                c = "#4a2c18"
            elif y % 6 == 1:
                c = "#a8723e"
            sp.px(x, y, c)
    sp.rect(0, 166, EW - 1, 168, ORO[1])
    sp.rect(0, 166, EW - 1, 166, ORO[0])
    sp.rect(0, 169, EW - 1, EH - 1, "#2a1210")
    sp.capa("candilejas")
    for x in range(8, EW, 16):                            # foquitos del proscenio
        sp.elipse(x, 171, 2.2, 1.8, ORO)
    # el telón: lados recogidos con cordón dorado y cenefa arriba
    sp.capa("telon")
    for lado in (-1, 1):
        for y in range(EH - 8):
            ancho = 52 - int(26 * math.exp(-((y - 108) / 26) ** 2)) if y > 60 else 52 - int(max(0, (y - 20)) * .1)
            ancho = max(18, ancho)
            for k in range(ancho):
                x = k if lado < 0 else EW - 1 - k
                pliegue = (k + int(4 * math.sin(y / 30))) % 9
                c = ROJO[0] if pliegue < 2 else (ROJO[1] if pliegue < 6 else (ROJO[2] if pliegue < 8 else ROJO[3]))
                sp.px(x, y, c)
            borde = ancho if lado < 0 else EW - 1 - ancho
            sp.px(borde, y, ROJO[3])
        cy_ = 108
        for k in range(-3, 30):
            x = (12 + k) if lado < 0 else EW - 13 - k
            yy = cy_ + int(2 * math.sin(k / 3))
            sp.px(x, yy, ORO[1])
            sp.px(x, yy + 1, ORO[2])
        bx = 40 if lado < 0 else EW - 41
        sp.elipse(bx, cy_ + 6, 3, 4, ORO)
        for k in range(-2, 3):
            sp.linea(bx + k, cy_ + 9, bx + k, cy_ + 16, ORO[2] if k % 2 else ORO[1])
    for x in range(EW):                                   # cenefa con ondas y fleco dorado
        alto = 18 + int(6 * abs(math.sin(x / 40 * math.pi)))
        for y in range(alto):
            pliegue = (x + y // 4) % 10
            sp.px(x, y, ROJO[1] if pliegue < 6 else (ROJO[2] if pliegue < 9 else ROJO[0]))
        sp.px(x, alto, ORO[0])
        sp.px(x, alto + 1, ORO[1] if x % 2 else ORO[2])
        if x % 3 == 0:
            sp.px(x, alto + 2, ORO[2])
    for x in range(20, EW, 40):
        sp.elipse(x, 8, 4, 4, ORO)
    return sp


def escenario_svg(sin=("candilejas", "pendulo", "estrella")):
    capas = {k: v for k, v in escenario().capas.items() if k not in sin}
    cuerpo = "".join(trazo(capas[k]) for k in escenario().orden if k in capas)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {EW} {EH}" width="{EW * EP}" height="{EH * EP}" '
            f'shape-rendering="crispEdges">{cuerpo}</svg>')


# ───────────────────────── exportar ─────────────────────────
def trazo(pix):
    """Pixeles → paths SVG (por color, con corridas horizontales)."""
    por_color = {}
    for (x, y), c in pix.items():
        por_color.setdefault(c, []).append((y, x))
    out = []
    for c, lst in por_color.items():
        lst.sort()
        d = []
        i = 0
        while i < len(lst):
            y, x = lst[i]
            j = i
            while j + 1 < len(lst) and lst[j + 1] == (y, lst[j][1] + 1):
                j += 1
            d.append(f"M{x} {y}h{j - i + 1}v1h-{j - i + 1}z")
            i = j + 1
        out.append(f'<path fill="{c}" d="{"".join(d)}"/>')
    return "".join(out)


def aplanar(sp):
    pix = {}
    for capa in sp.orden:
        pix.update(sp.capas[capa])
    return pix


def pose_svg(sp):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
            f'shape-rendering="crispEdges">{trazo(aplanar(sp))}</svg>')


# ───────────────────────── la coreografía (32 tiempos) ─────────────────────────
# (inicio, duración en tiempos, [(pose, volteo), ...] repartidas en el tramo, x inicial, x final, altura del brinco)
GIRO = [("passe", 1), ("passe_lado", 1), ("passe_atras", 1), ("passe_lado", -1)]
X_B, X_N, X_B2 = 760, 450, 630
COREO_B = [
    (0, 1, [("brazos", 1)], X_B, X_B, 8), (1, 1, [("segunda", 1)], X_B, X_B, 0),
    (2, 1, [("brazos", 1)], X_B, X_B, 8), (3, 1, [("plie", 1)], X_B, X_B, 0),
    (4, 4, GIRO * 4, X_B, X_B, 0),
    (8, 2, [("arabesque", 1)], X_B, X_B, 0), (10, 2, [("attitude", 1)], X_B, X_B, 0),
    (12, 2, [("jete", -1)], X_B, X_B2, 70), (14, 2, [("reverencia", -1)], X_B2, X_B2, 0),
    (16, 1, [("mano", 1)], X_B2, X_B2, 0), (17, 1, [("brazos", 1)], X_B2, X_B2, 6),
    (18, 1, [("mano", 1)], X_B2, X_B2, 0), (19, 1, [("brazos", 1)], X_B2, X_B2, 6),
    (20, 1, [("salto", 1)], X_B2, X_B2, 40), (21, 1, [("plie", 1)], X_B2, X_B2, 0),
    (22, 1, [("salto", 1)], X_B2, X_B2, 40), (23, 1, [("plie", 1)], X_B2, X_B2, 0),
    (24, 4, GIRO * 4, X_B2, X_B, 0),
    (28, 2, [("arabesque", -1)], X_B, X_B, 0), (30, 2, [("reverencia", 1)], X_B, X_B, 0),
]
COREO_N = [
    (0, 1, [("marcha_a", 1)], X_N, X_N, 3), (1, 1, [("marcha_b", 1)], X_N, X_N, 3),
    (2, 1, [("marcha_a", 1)], X_N, X_N, 3), (3, 1, [("marcha_b", 1)], X_N, X_N, 3),
    (4, 1, [("mano", 1)], X_N, X_N, 0), (5, 1, [("firme_boca", 1), ("firme", 1)], X_N, X_N, 0),
    (6, 1, [("mano", 1)], X_N, X_N, 0), (7, 1, [("firme_boca", 1), ("firme", 1)], X_N, X_N, 0),
    (8, 2, [("saludo", 1)], X_N, X_N, 0), (10, 2, [("arriba", 1)], X_N, X_N, 10),
    (12, 2, [("firme_boca", 1), ("firme", 1)] * 2, X_N, X_N, 0), (14, 2, [("reverencia", 1)], X_N, X_N, 0),
    (16, 4, [("mano", 1), ("mano", 1), ("firme_boca", 1), ("mano", 1)], X_N, X_N, 0),
    (20, 1, [("salto", 1)], X_N, X_N, 34), (21, 1, [("firme", 1)], X_N, X_N, 0),
    (22, 1, [("salto", 1)], X_N, X_N, 34), (23, 1, [("firme", 1)], X_N, X_N, 0),
    (24, 1, [("marcha_a", 1)], X_N, X_N, 3), (25, 1, [("marcha_b", 1)], X_N, X_N, 3),
    (26, 1, [("marcha_a", 1)], X_N, X_N, 3), (27, 1, [("marcha_b", 1)], X_N, X_N, 3),
    (28, 2, [("saludo", 1)], X_N, X_N, 0), (30, 2, [("reverencia", 1)], X_N, X_N, 0),
]
TIEMPOS = 32


def coreo_json():
    def tramo(lst):
        return [dict(i=i, d=d, f=[[p, v] for p, v in fr], x0=x0, x1=x1, h=h) for i, d, fr, x0, x1, h in lst]
    return {"b": tramo(COREO_B), "n": tramo(COREO_N), "tiempos": TIEMPOS}


def _linea_tiempo(coreo, paso=.125):
    """Muestrea la coreografía: [(tiempo, pose, volteo, x, y)]."""
    out = []
    t = 0.0
    while t < TIEMPOS - 1e-9:
        for i, d, frames, x0, x1, h in coreo:
            if i <= t < i + d:
                u = (t - i) / d
                pose, flip = frames[min(len(frames) - 1, int(u * len(frames)))]
                out.append((t, pose, flip, x0 + (x1 - x0) * u, -h * math.sin(math.pi * u)))
                break
        t += paso
    return out


def cascanueces_svg(bpm=120):
    """Para el README: el dúo bailando en bucle (a 120 pulsos por minuto)."""
    b, c = todas()
    seg = TIEMPOS * 60 / bpm
    P = EP
    css = [f"@keyframes pend{{from{{transform:rotate(-9deg)}}to{{transform:rotate(9deg)}}}}"
           f".pend{{transform-origin:{(302 + 12) * P}px {80 * P}px;animation:pend {60 / bpm:.3f}s ease-in-out infinite alternate}}",
           f".cand{{animation:cand {120 / bpm:.3f}s steps(1) infinite}}.cand2{{animation:cand {120 / bpm:.3f}s steps(1) {-60 / bpm:.3f}s infinite}}"
           "@keyframes cand{50%{opacity:.25}}",
           ".est{animation:est 1.6s ease-in-out infinite}@keyframes est{50%{opacity:.4}}",
           "@media (prefers-reduced-motion:reduce){*{animation:none!important}}"]
    cuerpo = [escenario_svg().split(">", 1)[1].rsplit("</svg>", 1)[0].replace("<path", "<path", 1)]
    esc = escenario()
    cuerpo = [f'<g transform="scale({P})">' + "".join(trazo(esc.capas[k]) for k in esc.orden if k not in ("candilejas", "pendulo", "estrella")) + "</g>"]
    cuerpo.append(f'<g class="est" transform="scale({P})">{trazo(esc.capas["estrella"])}</g>')
    cuerpo.append(f'<g class="pend"><g transform="scale({P})">{trazo(esc.capas["pendulo"])}</g></g>')
    focos = sorted(esc.capas["candilejas"].items())
    for k, cls in ((0, "cand"), (1, "cand2")):
        pix = {xy: c_ for xy, c_ in focos if (xy[0] // 16) % 2 == k}
        cuerpo.append(f'<g class="{cls}" transform="scale({P})">{trazo(pix)}</g>')
    cuerpo.append('<defs><radialGradient id="spot"><stop offset="0" stop-color="#fff6d0" stop-opacity=".55"/>'
                  '<stop offset="1" stop-color="#fff6d0" stop-opacity="0"/></radialGradient></defs>')
    for quien, poses, coreo in (("n", c, COREO_N), ("b", b, COREO_B)):
        linea = _linea_tiempo(coreo)
        n = len(linea)
        # el desplazamiento (x, brinco) del bailarín
        kf = []
        for k, (t, pose, flip, x, y) in enumerate(linea + [linea[0]]):
            pct = 100 * k / n
            kf.append(f"{pct:.3f}%{{transform:translate({x - W * P / 2:.1f}px,{PISO_ESC * P - PISO * P + y:.1f}px)}}")
        css.append(f"@keyframes mov{quien}{{{''.join(kf)}}}.mov{quien}{{animation:mov{quien} {seg:.2f}s linear infinite}}")
        spots = [f"{100 * k / n:.3f}%{{transform:translateX({x:.1f}px)}}" for k, (t, _, _, x, _) in enumerate(linea + [linea[0]])]
        css.append(f"@keyframes spot{quien}{{{''.join(spots)}}}.spot{quien}{{animation:spot{quien} {seg:.2f}s linear infinite}}")
        cuerpo.append(f'<g class="spot{quien}"><ellipse cx="0" cy="{PISO_ESC * P + 6}" rx="90" ry="16" fill="url(#spot)"/></g>')
        grupos = []
        usados = sorted({(pose, flip) for _, pose, flip, _, _ in linea})
        for pose, flip in usados:
            nombre = f"{quien}_{pose}_{'i' if flip < 0 else 'd'}"
            # intervalos donde esta pose está visible
            kf = []
            vis_prev = None
            for k, (t, p_, f_, _, _) in enumerate(linea):
                vis = (p_, f_) == (pose, flip)
                if vis != vis_prev:
                    pct = 100 * k / n
                    if k:
                        kf.append(f"{max(0, pct - .001):.3f}%{{opacity:{0 if vis else 1}}}")
                    kf.append(f"{pct:.3f}%{{opacity:{1 if vis else 0}}}")
                    vis_prev = vis
            kf.append(f"100%{{opacity:{1 if vis_prev else 0}}}")
            css.append(f"@keyframes {nombre}{{{''.join(kf)}}}.{nombre}{{opacity:0;animation:{nombre} {seg:.2f}s linear infinite}}")
            tr = f"scale({P})" if flip > 0 else f"translate({W * P} 0) scale({-P} {P})"
            grupos.append(f'<g class="{nombre}"><g transform="{tr}">{trazo(aplanar(poses[pose]))}</g></g>')
        cuerpo.append(f'<g class="mov{quien}">{"".join(grupos)}</g>')
    titulo = "El Cascanueces y la bailarina bailando en un teatrito navideño, en pixel art"
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {EW * P} {EH * P}" width="{EW * P}" height="{EH * P}" '
            f'shape-rendering="crispEdges" role="img" aria-label="{titulo}"><title>{titulo}</title>'
            f'<style>{"".join(css)}</style>{"".join(cuerpo)}</svg>')


def todas():
    return ({k: bailarina(k) for k in BAILARINA}, {k: cascanueces(k) for k in CASCANUECES})


if __name__ == "__main__":
    import sys
    b, c = todas()
    dest = ASSETS / "ballet"
    dest.mkdir(parents=True, exist_ok=True)
    for k, sp in b.items():
        (dest / f"bailarina-{k}.svg").write_text(pose_svg(sp), encoding="utf-8")
    for k, sp in c.items():
        (dest / f"cascanueces-{k}.svg").write_text(pose_svg(sp), encoding="utf-8")
    (dest / "escenario.svg").write_text(escenario_svg(()), encoding="utf-8")
    (dest / "escenario-fondo.svg").write_text(escenario_svg(), encoding="utf-8")
    doc = cascanueces_svg()
    (ASSETS / "cascanueces.svg").write_text(doc, encoding="utf-8")
    print(f"assets/cascanueces.svg  ({len(doc.encode()) / 1e3:.0f} KB)")
    # hoja de poses para revisar
    piezas = list(b.items()) + list(c.items())
    P = 4
    cols = 7
    filas = (len(piezas) + cols - 1) // cols
    cuerpo = []
    for i, (k, sp) in enumerate(piezas):
        x, y = (i % cols) * W * P, (i // cols) * (H * P + 30)
        cuerpo.append(f'<g transform="translate({x} {y}) scale({P})">{trazo(aplanar(sp))}</g>'
                      f'<text x="{x + 8}" y="{y + H * P + 20}" fill="#fff" font-size="18" font-family="monospace">{k}</text>')
    hoja = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{cols * W * P}" height="{filas * (H * P + 30)}" shape-rendering="crispEdges">'
            f'<rect width="100%" height="100%" fill="#3a1418"/>{"".join(cuerpo)}</svg>')
    Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/ballet_hoja.svg").write_text(hoja, encoding="utf-8")
    print(f"{len(b)} poses de bailarina y {len(c)} de cascanueces")
