#!/usr/bin/env python3
"""Personajes navideños en pixel art, animados en una escena nevada.

    python3 scripts/personajes.py   -> genera assets/personajes.svg y assets/musica.svg

Cada personaje se dibuja con figuras (elipses, polígonos, líneas) sobre una
cuadrícula de pixeles; las partes que se mueven van en capas separadas.
"""
import base64
import random
from pathlib import Path

from pixel import (AZUL, CAFE, CANELA, COSTAL, GALLETA, MEJILLA, NARANJA, NEGRO,
                   NIEVE, OJO, ORO, PIEL, ROJO, ROSA, VERDE, Sprite)

AQUI = Path(__file__).resolve().parent
ASSETS = AQUI.parent / "assets"
FUENTE_PIXEL = AQUI / "fuente" / "PressStart2P-Regular.woff2"

# Botón de música (GitHub no deja reproducir audio en el README: el botón abre la página
# navideña https://cheque2305.github.io, donde suena al presionar START)
CANCION = "Santa Claus Is Comin' To Town"
ARTISTA = "Peggy Lee"


# ═══════════════════════ muñeco de nieve ═══════════════════════
def muneco():
    s = Sprite(34, 54)
    s.capa("base")
    s.elipse(17, 42.5, 11.5, 9.2, NIEVE)
    s.elipse(17, 28, 8.6, 7.2, NIEVE)
    s.elipse(17, 16.5, 6.6, 5.8, NIEVE)
    # sombrero de copa con listón y acebo
    s.rect(12, 1, 21, 9, NEGRO[1])
    s.rect(12, 1, 12, 9, NEGRO[0])
    s.rect(21, 1, 21, 9, NEGRO[2])
    s.rect(12, 1, 21, 1, NEGRO[0])
    s.rect(12, 7, 21, 8, ROJO[1])
    s.rect(12, 7, 12, 8, ROJO[0])
    s.rect(9, 10, 24, 11, NEGRO[1])
    s.rect(9, 10, 24, 10, NEGRO[0])
    s.pts([(17, 6), (18, 7), (19, 6), (16, 7)], VERDE[1])
    s.pts([(18, 6), (17, 7)], ROJO[0])
    # nariz de zanahoria, boca de carbón y botones
    s.pts([(16, 17)], NARANJA[0])
    s.pts([(17, 17), (18, 17)], NARANJA[1])
    s.pts([(19, 17), (17, 18)], NARANJA[2])
    s.pts([(13, 19), (14, 20), (16, 21), (18, 21), (20, 20), (21, 19)], NEGRO[2])
    for y in (26, 30, 38, 43):
        s.pts([(17, y)], NEGRO[2])
        s.pts([(17, y - 1)], NEGRO[0])
    # bufanda verde con rayas rojas
    for x in range(10, 25):
        for y in (21, 22, 23):
            if abs(x - 17) <= (7 if y < 23 else 6):
                c = ROJO[1] if (x // 2) % 2 == 0 else VERDE[1]
                if y == 23:
                    c = ROJO[2] if c == ROJO[1] else VERDE[2]
                s.px(x, y, c)
    for y in range(24, 33):
        for x in (20, 21, 22):
            c = ROJO[1] if (y // 2) % 2 == 0 else VERDE[1]
            s.px(x, y, (ROJO[2] if c == ROJO[1] else VERDE[2]) if x == 22 else c)
    s.pts([(20, 33), (22, 33)], VERDE[2])
    # brazo izquierdo (fijo)
    s.linea(9, 29, 3, 23, CAFE[2])
    s.linea(4, 24, 2, 21, CAFE[2])
    s.linea(5, 25, 5, 22, CAFE[2])
    s.contorno()
    s.capa("ojos")
    s.pts([(14, 15), (14, 16), (20, 15), (20, 16)], NEGRO[3])
    s.capa("brazo")                                   # brazo que saluda
    s.linea(25, 29, 31, 22, CAFE[2])
    s.linea(30, 23, 33, 21, CAFE[2])
    s.linea(30, 23, 30, 19, CAFE[2])
    s.contorno()
    return s, {"brazo": (25, 29)}


# ═══════════════════════ pingüino ═══════════════════════
def pinguino():
    s = Sprite(34, 44)
    s.capa("base")
    s.elipse(5.5, 27, 2.8, 6.5, NEGRO)
    s.elipse(28.5, 27, 2.8, 6.5, NEGRO)
    s.elipse(12.5, 40.5, 3.4, 1.8, NARANJA)
    s.elipse(21.5, 40.5, 3.4, 1.8, NARANJA)
    s.elipse(17, 26, 11.5, 14, NEGRO)
    s.elipse(17, 30, 7.8, 9.4, NIEVE)
    s.elipse(14, 19, 3.8, 3.8, NIEVE)
    s.elipse(20, 19, 3.8, 3.8, NIEVE)
    s.elipse(17, 21, 5, 2.6, NIEVE)
    s.pts([(16, 21), (17, 21), (18, 21)], NARANJA[1])
    s.pts([(16, 21)], NARANJA[0])
    s.pts([(17, 22)], NARANJA[2])
    s.pts([(12, 21), (22, 21)], ROSA)
    # gorro de Santa
    s.elipse(17, 13.5, 9.8, 7.5, ROJO, dentro=lambda x, y: y <= 13)
    s.poligono([(21, 7), (25, 6), (30, 11), (29, 14), (25, 9)], ROJO[1])
    s.pts([(25, 7), (26, 8)], ROJO[0])
    s.pts([(28, 12), (29, 13)], ROJO[2])
    s.elipse(29.5, 15, 2.4, 2.3, NIEVE)
    for x in range(7, 28):
        for y in (12, 13, 14):
            s.px(x, y, NIEVE[2] if y == 14 else (NIEVE[0] if (x + y) % 3 else NIEVE[1]))
    # bufanda azul con rayas
    for x in range(8, 27):
        for y in (24, 25):
            if abs(x - 17) <= 9:
                s.px(x, y, AZUL[2] if y == 25 else (AZUL[1] if (x // 2) % 2 else NIEVE[1]))
    for y in range(26, 33):
        for x in (9, 10, 11):
            s.px(x, y, AZUL[2] if x == 11 else (AZUL[1] if (y // 2) % 2 else NIEVE[1]))
    s.pts([(9, 33), (11, 33)], AZUL[2])
    s.contorno()
    s.capa("ojos")
    s.pts([(14, 18), (14, 19), (20, 18), (20, 19)], OJO)
    return s, {}


# ═══════════════════════ oso polar ═══════════════════════
def oso():
    s = Sprite(36, 48)
    s.capa("base")
    s.elipse(11.5, 44.5, 4, 2.4, NIEVE)
    s.elipse(24.5, 44.5, 4, 2.4, NIEVE)
    s.elipse(18, 33, 12, 11.5, NIEVE)
    s.elipse(8.5, 13.5, 2.6, 2.6, NIEVE)
    s.elipse(27.5, 13.5, 2.6, 2.6, NIEVE)
    s.pts([(8, 13), (27, 13)], ROSA)
    s.elipse(18, 18, 9.8, 8.2, NIEVE)
    s.elipse(18, 21.5, 4.6, 3, (NIEVE[0], NIEVE[0], NIEVE[1]))
    s.pts([(17, 19), (18, 19), (19, 19), (18, 20)], NEGRO[3])
    s.pts([(17, 19)], NEGRO[0])
    s.pts([(16, 22), (17, 23), (19, 23), (20, 22)], NEGRO[2])
    s.pts([(18, 22)], NEGRO[2])
    s.pts([(12, 21), (24, 21)], ROSA)
    # gorro tejido con rayas y pompón
    s.elipse(18, 12, 9.6, 7.4, ROJO, dentro=lambda x, y: y <= 11)
    s.recolorear(lambda x, y, c: c in ROJO and y <= 11 and (y // 2) % 2 == 0,
                 lambda x, y, c: NIEVE[1] if c != ROJO[2] else NIEVE[2])
    for x in range(8, 29):
        for y in (11, 12, 13):
            s.px(x, y, ROJO[2] if x % 2 else ROJO[1])
    s.elipse(18, 4, 3, 2.8, NIEVE)
    # taza de chocolate caliente
    s.rect(14, 28, 22, 35, ROJO[1])
    s.rect(14, 28, 14, 35, ROJO[0])
    s.rect(22, 28, 22, 35, ROJO[2])
    s.rect(14, 35, 22, 35, ROJO[2])
    s.rect(14, 28, 22, 28, NIEVE[1])
    s.rect(15, 29, 21, 29, CAFE[2])
    s.pts([(15, 31), (16, 31), (18, 31), (19, 31), (15, 32), (16, 32), (17, 32), (18, 32), (19, 32), (16, 33), (17, 33), (18, 33), (17, 34)], NIEVE[0])
    s.pts([(23, 30), (24, 30), (25, 31), (25, 32), (24, 33), (23, 33)], ROJO[2])
    s.elipse(12, 32.5, 2.6, 2.4, NIEVE)
    s.elipse(26.5, 30.5, 2.4, 2.2, NIEVE)
    s.contorno()
    s.capa("ojos")
    s.pts([(13, 16), (13, 17), (23, 16), (23, 17)], OJO)
    s.capa("vapor")
    s.pts([(16, 26), (17, 25), (17, 24), (16, 23), (19, 25), (20, 24), (20, 23), (19, 22)], NIEVE[2])
    return s, {}


# ═══════════════════════ reno ═══════════════════════
def reno():
    s = Sprite(36, 52)
    s.capa("base")
    cuerno = (CANELA[0], CANELA[1], CANELA[2])
    for lado in (-1, 1):
        cx = 18
        s.linea(cx + lado * 5, 13, cx + lado * 8, 7, cuerno[1], 2 if lado < 0 else 1)
        s.linea(cx + lado * 8, 7, cx + lado * 9, 1, cuerno[1])
        s.linea(cx + lado * 8, 8, cx + lado * 13, 5, cuerno[1])
        s.linea(cx + lado * 9, 3, cx + lado * 12, 1, cuerno[1])
        s.linea(cx + lado * 6, 11, cx + lado * 4, 6, cuerno[1])
        if lado > 0:
            s.linea(cx + 6, 13, cx + 9, 7, cuerno[2])
    s.elipse(8, 18, 3.4, 1.8, CAFE)
    s.elipse(28, 18, 3.4, 1.8, CAFE)
    s.pts([(7, 18), (8, 18)], ROSA)
    s.pts([(28, 18), (29, 18)], ROSA)
    s.elipse(12.5, 47, 2.8, 3.6, CAFE)
    s.elipse(23.5, 47, 2.8, 3.6, CAFE)
    s.rect(10, 49, 15, 50, NEGRO[1])
    s.rect(21, 49, 26, 50, NEGRO[1])
    s.elipse(18, 37, 9.8, 10.5, CAFE)
    s.elipse(18, 39.5, 5.8, 6.8, CANELA)
    s.elipse(8, 36, 2.6, 5.4, CAFE)
    s.elipse(28, 36, 2.6, 5.4, CAFE)
    s.pts([(7, 41), (8, 41), (9, 41), (27, 41), (28, 41), (29, 41)], NEGRO[1])
    s.elipse(18, 20.5, 7.8, 6.8, CAFE)
    s.elipse(18, 24, 4.8, 3.1, CANELA)
    s.elipse(18, 22.3, 2, 1.4, NEGRO)
    s.pts([(17, 22)], NEGRO[0])
    s.pts([(17, 26), (18, 26), (19, 26)], CAFE[3])
    s.pts([(13, 23), (23, 23)], ROSA)
    for x in range(11, 26):
        s.px(x, 28, ROJO[0] if x < 14 else ROJO[1])
        s.px(x, 29, ROJO[2])
    s.contorno()
    s.capa("ojos")
    s.pts([(14, 19), (14, 20), (22, 19), (22, 20)], OJO)
    s.capa("campana")
    s.elipse(18, 31.5, 2.3, 2.2, ORO)
    s.pts([(18, 32)], NEGRO[2])
    s.contorno()
    return s, {"campana": (18, 29)}


# ═══════════════════════ galleta de jengibre ═══════════════════════
def galleta():
    s = Sprite(32, 42)
    s.capa("base")
    s.elipse(11.5, 34, 3.2, 6.2, GALLETA)
    s.elipse(20.5, 34, 3.2, 6.2, GALLETA)
    s.elipse(6, 20.5, 5.4, 2.8, GALLETA)
    s.elipse(26, 20.5, 5.4, 2.8, GALLETA)
    s.elipse(16, 24, 6.8, 8.6, GALLETA)
    s.elipse(16, 10, 7.4, 7, GALLETA)
    glaseado = NIEVE[0]
    s.pts([(1, 19), (2, 20), (1, 21), (2, 22)], glaseado)
    s.pts([(30, 19), (29, 20), (30, 21), (29, 22)], glaseado)
    s.pts([(9, 38), (10, 39), (11, 38), (12, 39), (13, 38)], glaseado)
    s.pts([(18, 38), (19, 39), (20, 38), (21, 39), (22, 38)], glaseado)
    s.pts([(12, 13), (13, 14), (14, 14), (15, 14), (16, 14), (17, 14), (18, 14), (19, 13)], glaseado)
    s.pts([(10, 12), (21, 12)], MEJILLA)
    for y, tonos in ((21, ROJO), (25, VERDE), (29, ORO)):
        s.pts([(15, y), (16, y)], tonos[0])
        s.pts([(15, y + 1), (16, y + 1)], tonos[2])
    s.pts([(13, 17), (14, 17), (17, 17), (18, 17), (13, 18), (18, 18)], ROJO[1])
    s.pts([(15, 17), (16, 17)], ROJO[2])
    s.pts([(14, 18), (17, 18)], ROJO[2])
    s.contorno()
    s.capa("ojos")
    s.pts([(13, 9), (13, 10), (19, 9), (19, 10)], OJO)
    s.pts([(13, 9), (19, 9)], "#3a3442")
    return s, {}


# ═══════════════════════ Santa clásico ═══════════════════════
def santa():
    s = Sprite(58, 76)
    s.capa("base")

    def en_abrigo(x, y):
        return ((x + .5 - 28) / 17.5) ** 2 + ((y + .5 - 47) / 15.5) ** 2 <= 1

    # costal de regalos en la espalda (con un bastón de dulce y dos cajas asomándose)
    baston = [(45, 2), (46, 1), (47, 1), (48, 2), (48, 3), (44, 3), (44, 4), (43, 5), (43, 6), (42, 7), (42, 8), (41, 9), (41, 10)]
    for i, (x, y) in enumerate(baston):
        s.px(x, y, ROJO[1] if i % 3 == 0 else NIEVE[0])
        s.px(x + 1, y, ROJO[2] if i % 3 == 0 else NIEVE[2]) if y > 3 else None
    s.rect(36, 11, 42, 17, VERDE[1])
    s.rect(36, 11, 36, 17, VERDE[0])
    s.rect(42, 11, 42, 17, VERDE[2])
    s.rect(39, 11, 39, 17, ORO[1])
    s.rect(44, 12, 50, 18, ROJO[1])
    s.rect(44, 12, 44, 18, ROJO[0])
    s.rect(50, 12, 50, 18, ROJO[2])
    s.rect(47, 12, 47, 18, NIEVE[0])
    s.rect(44, 15, 50, 15, NIEVE[0])
    s.elipse(45.5, 31, 10.5, 13, COSTAL)
    s.recolorear(lambda x, y, c: c == COSTAL[1] and (x * 3 + y * 5) % 11 == 0, lambda x, y, c: COSTAL[2])
    s.elipse(40, 19, 4.4, 2.4, COSTAL)
    s.rect(37, 20, 43, 21, ORO[2])
    # piernas y botas negras con borde de piel
    for x0 in (18, 31):
        s.rect(x0, 59, x0 + 7, 66, ROJO[1])
        s.rect(x0, 59, x0, 66, ROJO[0])
        s.rect(x0 + 7, 59, x0 + 7, 66, ROJO[2])
    s.elipse(19.5, 70.5, 6, 3.2, NEGRO)
    s.rect(17, 66, 26, 69, NEGRO[1])
    s.elipse(36.5, 70.5, 6, 3.2, NEGRO)
    s.rect(30, 66, 39, 69, NEGRO[1])
    for x0 in (17, 30):
        s.rect(x0, 66, x0 + 9, 66, NIEVE[1])
        s.rect(x0, 67, x0 + 9, 67, NIEVE[2])
    s.pts([(15, 69), (16, 69), (40, 69), (41, 69)], NEGRO[0])
    # abrigo con piel blanca, cinturón y hebilla dorada
    s.elipse(28, 47, 17.5, 15.5, ROJO)
    s.recolorear(lambda x, y, c: c in ROJO and y >= 57 and en_abrigo(x, y),
                 lambda x, y, c: NIEVE[2] if y >= 61 or (x + y) % 4 == 0 else (NIEVE[0] if y == 57 else NIEVE[1]))
    for y in range(36, 58):
        s.px(27, y, NIEVE[0])
        s.px(28, y, NIEVE[1])
        s.px(29, y, NIEVE[2] if y % 3 else NIEVE[1])
    s.recolorear(lambda x, y, c: (c in ROJO or c in NIEVE) and y in (49, 50, 51) and en_abrigo(x, y),
                 lambda x, y, c: NEGRO[0] if y == 49 else NEGRO[1])
    s.rect(23, 48, 33, 52, ORO[1])
    s.rect(23, 48, 33, 48, ORO[0])
    s.rect(23, 48, 23, 52, ORO[0])
    s.rect(33, 48, 33, 52, ORO[2])
    s.rect(23, 52, 33, 52, ORO[2])
    s.rect(25, 49, 31, 51, NEGRO[1])
    s.rect(27, 50, 29, 50, ORO[1])
    s.pts([(25, 49), (26, 49)], NEGRO[0])
    # cabeza: patillas, cara, barba, bigote, nariz y cejas
    s.elipse(20, 20, 2.6, 4.4, NIEVE)
    s.elipse(36, 20, 2.6, 4.4, NIEVE)
    s.elipse(28, 20, 7.8, 6.2, PIEL)
    s.elipse(28, 31, 11.5, 10.5, NIEVE)
    s.recolorear(lambda x, y, c: c == NIEVE[1] and y > 26 and (x - y // 2) % 4 == 0, lambda x, y, c: NIEVE[2])
    s.recolorear(lambda x, y, c: c == NIEVE[1] and y > 26 and (x - y // 2) % 4 == 2 and y % 2, lambda x, y, c: NIEVE[0])
    s.elipse(24.2, 24.8, 4.2, 1.9, NIEVE)
    s.elipse(31.8, 24.8, 4.2, 1.9, NIEVE)
    s.pts([(20, 25), (36, 25)], NIEVE[2])
    s.elipse(28, 22.3, 1.9, 1.6, (PIEL[1], PIEL[2], PIEL[3]))
    s.pts([(27, 21)], PIEL[0])
    s.elipse(22.5, 22.5, 1.8, 1.2, (MEJILLA, MEJILLA, MEJILLA))
    s.elipse(33.5, 22.5, 1.8, 1.2, (MEJILLA, MEJILLA, MEJILLA))
    s.pts([(22, 17), (23, 16), (24, 16), (25, 17), (31, 17), (32, 16), (33, 16), (34, 17)], NIEVE[0])
    s.pts([(23, 17), (24, 17), (32, 17), (33, 17)], NIEVE[2])
    # gorro que cae hacia la izquierda con pompón
    s.elipse(28, 14, 10, 7.5, ROJO, dentro=lambda x, y: y <= 13)
    s.poligono([(21, 8), (17, 7), (11, 12), (12, 15), (17, 10)], ROJO[1])
    s.pts([(16, 8), (14, 10)], ROJO[0])
    s.pts([(13, 14), (14, 13)], ROJO[2])
    s.elipse(11, 16, 2.8, 2.7, NIEVE)
    for x in range(18, 39):
        for y in (12, 13, 14, 15):
            if abs(x - 28) <= 10 - (y == 15):
                s.px(x, y, NIEVE[2] if y == 15 else (NIEVE[0] if (x * 2 + y) % 3 else NIEVE[1]))
    s.contorno()
    # brazos en capas propias para que el contorno los separe del abrigo
    s.capa("brazo_izq")                               # mano en la panza
    s.poligono([(10, 39), (15, 35), (22, 47), (17, 51)], ROJO[1])
    s.linea(11, 39, 17, 50, ROJO[0])
    s.linea(15, 36, 21, 47, ROJO[2])
    s.elipse(19.5, 50.5, 3.6, 2.3, NIEVE)
    s.elipse(22.5, 52.5, 2.8, 2.4, NEGRO)
    s.contorno()
    s.capa("brazo_der")                               # sostiene el costal
    s.poligono([(35, 41), (42, 39), (43, 25), (38, 25)], ROJO[1])
    s.linea(36, 40, 38, 26, ROJO[0])
    s.linea(42, 38, 43, 26, ROJO[2])
    s.elipse(40.5, 24.5, 3.9, 2, NIEVE)
    s.elipse(40.5, 21, 3, 2.6, NEGRO)
    s.contorno()
    s.capa("ojos")                                    # ojos felices ^ ^
    s.pts([(23, 20), (24, 19), (25, 20), (31, 20), (32, 19), (33, 20)], OJO)
    s.capa("boca")                                    # boca abierta: ¡jo jo jo!
    s.elipse(28, 27, 2.4, 1.6, (ROJO[3], ROJO[3], ROJO[3]))
    s.pts([(27, 28), (28, 28)], ROJO[0])
    return s, {}


PERSONAJES = [muneco, pinguino, oso, santa, reno, galleta]


# ═══════════════════════ exportar ═══════════════════════
def trazo(pixeles):
    """Une pixeles contiguos del mismo color en un <path> por color."""
    por_color = {}
    for (x, y), c in pixeles.items():
        por_color.setdefault(c, set()).add((x, y))
    out = []
    for c, conj in por_color.items():
        d = []
        for y in sorted({p[1] for p in conj}):
            xs = sorted(p[0] for p in conj if p[1] == y)
            ini = prev = xs[0]
            for x in xs[1:] + [None]:
                if x is not None and x == prev + 1:
                    prev = x
                    continue
                d.append(f"M{ini} {y}h{prev - ini + 1}v1h{ini - prev - 1}z")
                if x is not None:
                    ini = prev = x
        out.append(f'<path fill="{c}" d="{"".join(d)}"/>')
    return "".join(out)


def fuente_css():
    return ("@font-face{font-family:'PS2P';src:url(data:font/woff2;base64,"
            + base64.b64encode(FUENTE_PIXEL.read_bytes()).decode() + ") format('woff2');}"
            "text{font-family:'PS2P',monospace}")


def musica_svg():
    """Botón tipo rocola: botón de play, nombre de la canción y ecualizador animado."""
    W, H, P = 1200, 112, 4
    rnd = random.Random(7)
    css = [fuente_css(),
           ".eq{animation-name:eq;animation-timing-function:steps(1);animation-iteration-count:infinite;"
           "transform-box:fill-box;transform-origin:50% 100%}",
           "@keyframes eq{0%{transform:scaleY(.25)}20%{transform:scaleY(1)}40%{transform:scaleY(.5)}"
           "60%{transform:scaleY(.8)}80%{transform:scaleY(.35)}}",
           ".late{animation:late 1.2s steps(1) infinite}@keyframes late{50%{transform:translate(2px,2px)}}",
           ".nota{animation:nota 2.4s steps(6) infinite}"
           "@keyframes nota{from{transform:translateY(8px);opacity:0}30%{opacity:1}to{transform:translateY(-26px);opacity:0}}",
           "@media (prefers-reduced-motion: reduce){*{animation:none!important}}"]
    c = [f'<rect x="2" y="2" width="{W - 4}" height="{H - 4}" rx="14" fill="#3a1d1c" stroke="#ffcf5a" stroke-opacity=".6" stroke-width="3"/>']
    # botón de play en pixeles
    boton = Sprite(20, 20)
    boton.elipse(10, 10, 10, 10, VERDE)
    boton.contorno(ORO[1])
    boton.poligono([(7.5, 5), (15.5, 10), (7.5, 15)], NIEVE[0])
    c.append(f'<g class="late"><g transform="translate(22 12) scale({P})" shape-rendering="crispEdges">'
             f'{trazo(boton.capas["base"])}</g></g>')
    # notitas que suben
    nota = Sprite(6, 8)
    nota.rect(4, 0, 5, 1, NIEVE[0])
    nota.rect(4, 0, 4, 6, NIEVE[0])
    nota.rect(1, 5, 4, 7, NIEVE[0])
    nota.rect(0, 6, 0, 6, NIEVE[0])
    for i, (x, col) in enumerate([(120, ORO[1]), (150, VERDE[0]), (178, ROJO[0])]):
        tr = trazo(nota.capas["base"]).replace(NIEVE[0], col)
        c.append(f'<g class="nota" style="animation-delay:{-i * .8:.1f}s"><g transform="translate({x} 40) scale(3)" '
                 f'shape-rendering="crispEdges">{tr}</g></g>')
    titulo = f"{ARTISTA} · {CANCION}".replace("'", "&#39;")
    c.append(f'<text x="220" y="50" font-size="22" fill="#ffffff">DALE PLAY</text>'
             f'<text x="430" y="50" font-size="13" fill="{ORO[1]}">¡y que empiece la gala!</text>'
             f'<text x="220" y="84" font-size="13" fill="#f0c99a">{titulo}</text>')
    # ecualizador
    x0 = W - 40 - 18 * 16
    for k in range(18):
        alto = 56
        col = (VERDE[0], VERDE[1], ORO[1], ROJO[0])[k % 4]
        dur = rnd.uniform(.7, 1.3)
        c.append(f'<rect class="eq" x="{x0 + k * 16}" y="{H - 28 - alto}" width="12" height="{alto}" fill="{col}" '
                 f'shape-rendering="crispEdges" style="animation-duration:{dur:.2f}s;animation-delay:{-rnd.uniform(0, dur):.2f}s"/>')
    c.append(f'<rect x="{x0 - 6}" y="{H - 26}" width="{18 * 16 + 8}" height="4" fill="#8a4a34"/>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" '
            f'aria-label="Dale play: entra a mi página navideña con música ({ARTISTA}, {CANCION})"><title>Dale play a la música</title>'
            f'<style>{"".join(css)}</style>{"".join(c)}</svg>')


# ═══════════════════════ decorados del pueblito ═══════════════════════
def pino():
    s = Sprite(26, 36)
    s.capa("base")
    for (cx, top, base, ancho) in ((13, 2, 11, 7), (13, 7, 20, 10), (13, 13, 30, 13)):
        s.poligono([(cx, top), (cx + ancho, base), (cx - ancho, base)], VERDE[1])
    s.recolorear(lambda x, y, c: c == VERDE[1] and x > 14, lambda x, y, c: VERDE[2])
    s.recolorear(lambda x, y, c: c == VERDE[1] and x < 11 and (x + y) % 3 == 0, lambda x, y, c: VERDE[0])
    for (cx, base, ancho) in ((13, 11, 7), (13, 20, 10), (13, 30, 13)):       # nieve en las puntas
        for x in range(cx - ancho + 1, cx + ancho):
            if (x * 7) % 5 < 3:
                s.px(x, base - 1, NIEVE[0] if x < 15 else NIEVE[1])
    s.rect(11, 30, 14, 34, CAFE[1])
    s.rect(11, 30, 11, 34, CAFE[0])
    s.contorno()
    s.capa("estrella")
    s.pts([(13, 0), (12, 1), (13, 1), (14, 1), (13, 2)], ORO[0])
    s.capa("luces")
    r = random.Random(4)
    for _ in range(9):
        y = r.randint(5, 28)
        lim = {True: 6}.get(y < 11, 9 if y < 20 else 12)
        s.px(13 + r.randint(-lim + 2, lim - 2), y, r.choice([ROJO[0], ORO[0], AZUL[0], ROSA, "#ffffff"]))
    return s


def cabana():
    s = Sprite(46, 40)
    s.capa("base")
    s.rect(31, 3, 35, 13, "#b5523b")                                   # chimenea
    s.rect(31, 3, 31, 13, "#d06a4f")
    s.pts([(33, 6), (32, 9), (34, 11)], "#8a3a2a")
    s.rect(30, 2, 36, 3, NIEVE[0])
    s.rect(5, 17, 40, 38, "#a8693f")                                  # paredes de madera
    for y in range(19, 38, 3):
        s.rect(5, y, 40, y, "#7f4c2c")
    s.rect(5, 17, 5, 38, "#c98a55")
    s.rect(40, 17, 40, 38, "#6e4026")
    s.poligono([(0, 18), (23, 2), (46, 18)], "#a33a35")               # techo
    s.recolorear(lambda x, y, c: c == "#a33a35" and x > 24, lambda x, y, c: "#7e2a28")
    s.poligono([(0, 17.5), (23, 1.5), (46, 17.5), (41, 17.5), (23, 5.5), (5, 17.5)], NIEVE[0])
    s.recolorear(lambda x, y, c: c == NIEVE[0] and x > 25 and y > 6, lambda x, y, c: NIEVE[1])
    for x in (3, 8, 14, 31, 37, 42):                                  # carámbanos
        s.px(x, 18, NIEVE[1])
    s.rect(19, 25, 27, 38, "#5f3a22")                                 # puerta
    s.rect(19, 25, 19, 38, "#7a4a2c")
    s.pts([(25, 32)], ORO[0])
    for dx, dy in ((0, -2), (1, -2), (2, -1), (2, 0), (2, 1), (1, 2), (0, 2), (-1, 2), (-2, 1), (-2, 0), (-2, -1), (-1, -2)):
        s.px(23 + dx, 28 + dy, VERDE[1] if (dx + dy) % 2 else VERDE[0])  # corona en la puerta
    s.pts([(22, 30), (23, 30), (24, 30)], ROJO[1])
    s.rect(4, 37, 41, 39, NIEVE[0])
    s.contorno()
    s.capa("ventanas")                                                # ventanas con luz cálida
    for x0 in (8, 30):
        s.rect(x0, 21, x0 + 7, 28, "#ffd36b")
        s.rect(x0, 25, x0 + 7, 28, "#ffb347")
        s.rect(x0 + 3, 21, x0 + 4, 28, "#5f3a22")
        s.rect(x0, 24, x0 + 7, 24, "#5f3a22")
    s.capa("luces")                                                   # foquitos en el borde del techo
    for i, x in enumerate(range(2, 45, 3)):
        y = round(18 - abs(x - 23) * 16 / 23) + 1
        s.px(x, y, [ROJO[0], ORO[0], VERDE[0], AZUL[0]][i % 4])
    return s


def corazon():
    s = Sprite(7, 6)
    for y, fila in enumerate([".RR.RR.", "RWRRRRR", "RRRRRRR", ".RRRRR.", "..RRR..", "...R..."]):
        for x, ch in enumerate(fila):
            if ch != ".":
                s.px(x, y, {"R": ROSA, "W": "#ffffff"}[ch])
    return s


def trineo(con_contorno=True):
    """Trineo de Santa con cuatro renos en pleno vuelo (dos cuadros de galope: patas0/patas1)."""
    s = Sprite(100, 28)
    s.capa("base")
    s.elipse(9, 12, 5.5, 5.5, COSTAL)                                   # costal con regalos
    s.rect(5, 4, 8, 7, ROJO[1])
    s.rect(6, 4, 6, 7, ORO[0])
    s.rect(10, 5, 13, 7, VERDE[1])
    s.rect(10, 6, 13, 6, ORO[1])
    s.elipse(18, 12, 4.6, 4.2, ROJO)                                    # Santa
    s.rect(14, 15, 22, 15, NIEVE[1])
    s.elipse(20, 6.5, 2.3, 2.1, PIEL)
    s.elipse(20.5, 8.7, 2.6, 1.9, NIEVE)
    s.poligono([(17.5, 5.5), (22.5, 5.5), (19, 1.5), (16, 2.5)], ROJO[1])
    s.rect(17, 5, 22, 5, NIEVE[0])
    s.elipse(15.5, 2.5, 1.3, 1.3, NIEVE)
    s.pts([(19, 6)], OJO)
    s.linea(21, 11, 27, 11, ROJO[1])
    s.pts([(27, 11), (28, 11)], NEGRO[1])
    s.poligono([(3, 14), (28, 14), (31, 10), (35, 9), (34, 12), (30, 21), (6, 21), (2, 17)], ROJO[1])  # trineo
    s.recolorear(lambda x, y, c: c == ROJO[1] and y >= 19, lambda x, y, c: ROJO[2])
    s.recolorear(lambda x, y, c: c == ROJO[1] and y == 15, lambda x, y, c: ROJO[0])
    s.linea(3, 14, 28, 14, ORO[1])
    s.linea(28, 14, 31, 10, ORO[1])
    s.pts([(35, 8), (36, 9), (36, 10), (35, 11), (34, 10)], ORO[0])
    for x in range(8, 28, 5):
        s.px(x, 17, ORO[1])
    s.linea(1, 25, 31, 25, ORO[2])                                      # patines
    s.pts([(32, 24), (33, 23), (33, 22), (32, 21), (0, 24), (0, 23)], ORO[2])
    s.linea(9, 22, 9, 24, ORO[2])
    s.linea(24, 22, 24, 24, ORO[2])
    s.linea(29, 11, 56, 12, CAFE[3])                                    # riendas
    s.linea(56, 12, 90, 11, CAFE[3])
    renos = (41, 55, 69, 83)
    for i, x0 in enumerate(renos):
        y = 0 if i % 2 else 1
        s.elipse(x0 + 6, 14 + y, 5.2, 2.6, CAFE)
        s.linea(x0 + 3, 16 + y, x0 + 8, 16 + y, CANELA[1])
        s.linea(x0 + 10, 13 + y, x0 + 12, 10 + y, CAFE[1], 2)
        s.elipse(x0 + 13.5, 9 + y, 2.3, 1.6, CAFE)
        s.pts([(x0 + 15, 9 + y)], NEGRO[2])
        s.pts([(x0 + 13, 8 + y)], OJO)
        s.linea(x0 + 12, 7 + y, x0 + 11, 4 + y, CANELA[0])
        s.linea(x0 + 11, 5 + y, x0 + 9, 4 + y, CANELA[0])
        s.linea(x0 + 14, 7 + y, x0 + 15, 4 + y, CANELA[0])
        s.linea(x0 + 15, 5 + y, x0 + 17, 4 + y, CANELA[0])
        s.pts([(x0 + 10, 12 + y), (x0 + 11, 12 + y)], ROJO[1])
        s.pts([(x0 + 11, 13 + y)], ORO[0])
        s.pts([(x0, 13 + y)], NIEVE[0])
    if con_contorno:
        s.contorno()
    for f in (0, 1):                                                    # patas: estiradas / encogidas
        s.capa(f"patas{f}")
        for i, x0 in enumerate(renos):
            y = 0 if i % 2 else 1
            if f == 0:
                trazos = [(9, 15, 13, 17), (8, 16, 12, 18), (3, 15, -1, 17), (2, 16, -2, 18)]
            else:
                trazos = [(9, 15, 10, 18), (8, 16, 8, 19), (3, 15, 3, 18), (2, 16, 1, 19)]
            for ax, ay, bx, by in trazos:
                s.linea(x0 + ax, ay + y, x0 + bx, by + y, CAFE[2])
        if con_contorno:
            s.contorno()
    return s


def capa_svg(sp, capa, clase="", estilo=""):
    return f'<g class="{clase}"{estilo}>{trazo(sp.capas[capa])}</g>'


CLASE_CAPA = {"ojos": "parp", "brazo": "saluda", "vapor": "vapor", "campana": "campana", "boca": "boca",
              "luces": "focos", "ventanas": "ventana", "estrella": "brilla"}

CSS_SPRITES = (
    ".parp{animation:parp 4.2s steps(1) infinite}@keyframes parp{0%,93%{opacity:1}94%,97%{opacity:0}}"
    ".saluda{animation:saluda .9s steps(1) infinite}@keyframes saluda{50%{transform:rotate(-18deg)}}"
    ".campana{animation:campana .7s steps(1) infinite}@keyframes campana{33%{transform:rotate(18deg)}66%{transform:rotate(-18deg)}}"
    ".vapor{animation:vapor 1.6s steps(4) infinite}@keyframes vapor{from{transform:translateY(2px);opacity:1}to{transform:translateY(-4px);opacity:0}}"
    ".boca{animation:boca 5s steps(1) infinite}@keyframes boca{0%,40%{opacity:1}10%,20%,30%{opacity:0}45%,100%{opacity:0}}"
    ".focos{animation:focos 1.2s steps(1) infinite}@keyframes focos{50%{opacity:.35}}"
    ".ventana{animation:ventana 3s steps(3) infinite}@keyframes ventana{50%{opacity:.82}}"
    ".brilla{animation:focos 1.6s steps(1) infinite}"
)


def dibujar(sp, anclas, x, y, P, k=0):
    """Grupo SVG de un sprite con sus capas animadas, en (x, y) a escala P."""
    partes = [f'<g transform="translate({x:.0f} {y:.0f}) scale({P})" shape-rendering="crispEdges">']
    for capa in sp.orden:
        if not sp.capas[capa]:
            continue
        estilo = ""
        if capa in anclas:
            ax, ay = anclas[capa]
            estilo = f' style="transform-origin:{ax}px {ay}px"'
        elif capa == "ojos":
            estilo = f' style="animation-delay:{-k * .9:.1f}s"'
        partes.append(capa_svg(sp, capa, CLASE_CAPA.get(capa, ""), estilo))
    partes.append("</g>")
    return "".join(partes)


# Cómo se mueve cada quien: (fila, centro x, cuánto camina, segundos por vuelta, se voltea)
MOVIMIENTO = {
    "muneco": ("atras", 120, 26, 9, True),
    "oso": ("atras", 430, 80, 11, True),
    "reno": ("atras", 790, 90, 8, True),
    "pinguino": ("frente", 255, 75, 8, True),
    "santa": ("frente", 610, 28, 10, False),
    "galleta": ("frente", 955, 70, 6, True),
}


PISO_ATRAS, PISO_FRENTE = 368, 448
FRASES_SANTA = ["¡JO JO JO!", "¡ESTÁS EN MI LISTA!", "¡GUÁRDAME UN TAMAL!"]


POS_PINOS = [(20, 4), (300, 3), (560, 3), (690, 4), (1120, 4)]   # (x, escala) de los pinos de atrás


def svg(con_personajes=True, con_pinos=True):
    """La Villa de Santa completa; para la página web sale solo el fondo (sin personajes ni pinos)."""
    W, H = 1200, 470
    piso_atras, piso_frente = PISO_ATRAS, PISO_FRENTE
    rnd = random.Random(1225)
    css = [fuente_css(), CSS_SPRITES,
           ".mece{animation:mece 3.4s ease-in-out infinite alternate;transform-box:fill-box;transform-origin:50% 100%}"
           "@keyframes mece{from{transform:rotate(-2deg)}to{transform:rotate(2deg)}}",
           ".paso{animation:paso .5s steps(1) infinite}@keyframes paso{50%{transform:translateY(-4px)}}",
           ".brinco{animation:brinco 2.4s steps(1) infinite}"
           "@keyframes brinco{0%,60%{transform:translateY(0)}64%{transform:translateY(-10px)}68%{transform:translateY(-20px)}"
           "72%{transform:translateY(-25px)}76%{transform:translateY(-20px)}80%{transform:translateY(-10px)}84%{transform:translateY(0)}}",
           ".contoneo{animation:contoneo 1s steps(1) infinite;transform-box:fill-box;transform-origin:50% 100%}"
           "@keyframes contoneo{50%{transform:rotate(-5deg)}0%,100%{transform:rotate(5deg)}}",
           ".panza{animation:panza 5s steps(1) infinite}"
           "@keyframes panza{0%,40%{transform:translateY(0)}5%,15%,25%,35%{transform:translateY(-5px)}45%,100%{transform:translateY(0)}}",
           ".jojo{opacity:0;animation:jojo 15s steps(1) infinite}@keyframes jojo{0%,13%{opacity:1}14%,100%{opacity:0}}",
           ".cz{animation:cz 7s linear infinite;opacity:0}"
           "@keyframes cz{0%{opacity:0;transform:translateY(0)}2%{opacity:1}22%{opacity:1;transform:translateY(-26px)}28%,100%{opacity:0;transform:translateY(-34px)}}",
           ".humo{animation:humo 3.2s ease-out infinite}"
           "@keyframes humo{from{transform:translate(0,0) scale(.5);opacity:.75}to{transform:translate(14px,-60px) scale(1.6);opacity:0}}",
           ".nv{animation:nv linear infinite}",
           f"@keyframes nv{{to{{transform:translateY({H + 20}px)}}}}",
           ".tw{animation:tw 2.6s steps(2) infinite}@keyframes tw{50%{opacity:.25}}",
           "@media (prefers-reduced-motion: reduce){*{animation:none!important}.cz{opacity:0}}"]
    c = [f'<defs><linearGradient id="cielo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a1438"/>'
         f'<stop offset=".7" stop-color="#7a3354"/><stop offset="1" stop-color="#c46a7a"/></linearGradient>'
         f'<radialGradient id="luzVentana"><stop offset="0" stop-color="#ffcf6b" stop-opacity=".55"/>'
         f'<stop offset="1" stop-color="#ffcf6b" stop-opacity="0"/></radialGradient>'
         f'<radialGradient id="luzLuna"><stop offset="0" stop-color="#fff1c2" stop-opacity=".45"/>'
         f'<stop offset="1" stop-color="#fff1c2" stop-opacity="0"/></radialGradient>'
         f'<clipPath id="tarj"><rect width="{W}" height="{H}" rx="22"/></clipPath></defs>',
         f'<g clip-path="url(#tarj)"><rect width="{W}" height="{H}" fill="url(#cielo)"/>']
    for _ in range(60):
        x, y = rnd.randrange(0, W, 5), rnd.randrange(0, 250, 5)
        c.append(f'<rect class="tw" x="{x}" y="{y}" width="5" height="5" fill="#fff1d6" '
                 f'opacity="{rnd.uniform(.4, .9):.2f}" style="animation-delay:{-rnd.uniform(0, 2.6):.2f}s"/>')
    luna = Sprite(16, 16)
    luna.elipse(8, 8, 7.5, 7.5, ("#fff6d8", "#f3e3b0", "#d2bd86", "#b39f6c"))
    for x, y in [(5, 5), (6, 5), (10, 9), (11, 9), (10, 10), (6, 11)]:
        luna.px(x, y, "#d2bd86")
    c.append('<circle cx="1110" cy="80" r="90" fill="url(#luzLuna)"/>')
    c.append(f'<g transform="translate(1070 40) scale(5)" shape-rendering="crispEdges">{trazo(luna.capas["base"])}</g>')

    def suelo(y0, color, sombra, amp):
        alto, h = [], 0
        for _ in range(W // 5 + 1):
            h = max(-amp, min(amp, h + rnd.choice((-1, 0, 0, 1))))
            alto.append(h)
        d = "".join(f"M{x * 5} {y0 + a * 5}h5V{H}h-5z" for x, a in enumerate(alto))
        return (f'<path d="{d}" fill="{color}" shape-rendering="crispEdges"/>'
                f'<rect y="{y0 + (amp + 1) * 5}" width="{W}" height="{H}" fill="{sombra}" shape-rendering="crispEdges"/>')

    # fondo: lomita de nieve, pinos y cabaña con humo
    c.append(suelo(piso_atras - 14, "#f6e8ee", "#ead6e0", 2))
    for i, (px_, esc_) in enumerate(POS_PINOS[:4]):
        p = pino()
        if con_pinos:
            c.append(f'<g class="mece" style="animation-delay:{-i * .8:.1f}s">{dibujar(p, {}, px_, piso_atras - p.h * esc_ + 2, esc_)}</g>')
    cab = cabana()
    cx0, cy0 = 960, piso_atras - cab.h * 5 + 6
    for x0 in (8, 30):
        c.append(f'<circle class="ventana" cx="{cx0 + (x0 + 4) * 5}" cy="{cy0 + 25 * 5}" r="55" fill="url(#luzVentana)"/>')
    for i in range(4):
        c.append(f'<circle class="humo" style="animation-delay:{-i * .8:.1f}s;transform-origin:{cx0 + 33 * 5}px {cy0}px" '
                 f'cx="{cx0 + 33 * 5}" cy="{cy0 - 5}" r="9" fill="#efe2ea"/>')
    c.append(dibujar(cab, {}, cx0, cy0, 5))
    p = pino()
    if con_pinos:
        px_, esc_ = POS_PINOS[4]
        c.append(f'<g class="mece" style="animation-delay:-1.7s">{dibujar(p, {}, px_, piso_atras - p.h * esc_ + 2, esc_)}</g>')

    def personaje(nombre, sp, anclas, P, piso, k):
        fila, cx, d, dur, voltea = MOVIMIENTO[nombre]
        x, y = cx - sp.w * P / 2, piso - sp.h * P + 4
        interior = {"pinguino": "contoneo", "galleta": "brinco", "santa": "panza"}.get(nombre, "paso")
        heart = corazon()
        out = [f'<g class="cam-{nombre}">',
               f'<ellipse cx="{cx}" cy="{piso + 2}" rx="{sp.w * P * .36:.0f}" ry="{P * 1.6:.0f}" fill="#8a4a6a" opacity=".35"/>',
               f'<g class="{interior}" style="animation-delay:{-k * .37:.2f}s">{dibujar(sp, anclas, x, y, P, k)}</g>',
               f'<g class="cz" style="animation-delay:{k * 1.1 + 1:.1f}s"><g transform="translate({cx - 7} {y - 22}) scale(2)" '
               f'shape-rendering="crispEdges">{trazo(heart.capas["base"])}</g></g></g>']
        if voltea:
            css.append(f".cam-{nombre}{{animation:cam-{nombre} {dur}s ease-in-out infinite;transform-box:fill-box;transform-origin:center}}"
                       f"@keyframes cam-{nombre}{{0%,100%{{transform:translateX(-{d}px) scaleX(1)}}46%{{transform:translateX({d}px) scaleX(1)}}"
                       f"50%{{transform:translateX({d}px) scaleX(-1)}}96%{{transform:translateX(-{d}px) scaleX(-1)}}}}")
        else:
            css.append(f".cam-{nombre}{{animation:cam-{nombre} {dur}s ease-in-out infinite alternate}}"
                       f"@keyframes cam-{nombre}{{from{{transform:translateX(-{d}px)}}to{{transform:translateX({d}px)}}}}")
        return "".join(out)

    sprites = {f.__name__: f() for f in PERSONAJES}
    orden = list(sprites)
    for nombre in ("muneco", "oso", "reno"):
        sp, anclas = sprites[nombre]
        if con_personajes:
            c.append(personaje(nombre, sp, anclas, 4, piso_atras, orden.index(nombre)))
    c.append(suelo(piso_frente - 22, "#fff8f2", "#f1dfe6", 2))
    for nombre in ("pinguino", "santa", "galleta"):
        sp, anclas = sprites[nombre]
        if con_personajes:
            c.append(personaje(nombre, sp, anclas, 5, piso_frente, orden.index(nombre)))

    # globo de "¡JO JO JO!" sobre Santa (no se voltea con él)
    sp, _ = sprites["santa"]
    bx, by = 610 + 40, piso_frente - sp.h * 5 - 10
    for k, frase in enumerate(FRASES_SANTA if con_personajes else []):
        ancho_g = len(frase) * 16 + 34
        c.append(f'<g class="jojo" style="animation-delay:{k * 5}s"><rect x="{bx}" y="{by}" width="{ancho_g}" height="44" fill="#ffffff" shape-rendering="crispEdges"/>'
                 f'<rect x="{bx - 5}" y="{by + 5}" width="{ancho_g + 10}" height="34" fill="#ffffff" shape-rendering="crispEdges"/>'
                 f'<path d="M{bx + 20} {by + 44}h15v5h-5v5h-5v5h-5z" fill="#ffffff" shape-rendering="crispEdges"/>'
                 f'<text x="{bx + ancho_g / 2:.0f}" y="{by + 30}" font-size="16" text-anchor="middle" fill="{ROJO[1]}">{frase}</text></g>')

    for _ in range(70):
        tam = 5 * rnd.choice((1, 1, 2))
        dur = rnd.uniform(6, 13)
        c.append(f'<rect class="nv" x="{rnd.randrange(0, W, 5)}" y="-12" width="{tam}" height="{tam}" fill="#ffffff" '
                 f'opacity="{rnd.uniform(.55, .95):.2f}" shape-rendering="crispEdges" '
                 f'style="animation-duration:{dur:.2f}s;animation-delay:{-rnd.uniform(0, dur):.2f}s"/>')
    c.append(f'</g><rect x="1.5" y="1.5" width="{W - 3}" height="{H - 3}" rx="21" fill="none" stroke="#ffcf5a" stroke-opacity=".6" stroke-width="3"/>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" '
            f'aria-label="La Villa de Santa en pixel art: muñeco de nieve, pingüino, oso polar, Santa, reno y galleta de jengibre caminando bajo la luna">'
            f'<title>La Villa de Santa</title><style>{"".join(css)}</style>{"".join(c)}</svg>')


def sprite_svg(sp, anclas, P=4):
    """Un personaje suelto (con parpadeo y sus detalles animados) para la página web."""
    W, H = sp.w * P, sp.h * P
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">'
            f'<style>{CSS_SPRITES}@media (prefers-reduced-motion: reduce){{*{{animation:none!important}}}}</style>'
            f'{dibujar(sp, anclas, 0, 0, P)}</svg>')


if __name__ == "__main__":
    ASSETS.mkdir(exist_ok=True)
    (ASSETS / "personajes").mkdir(exist_ok=True)
    for nombre, doc in (("personajes.svg", svg()), ("pueblo-fondo.svg", svg(False, False)), ("musica.svg", musica_svg())):
        (ASSETS / nombre).write_text(doc, encoding="utf-8")
        print(f"assets/{nombre}  ({len(doc.encode()) // 1024} KB)")
    for f in PERSONAJES + [pino, cabana]:
        r = f()
        sp, anclas = r if isinstance(r, tuple) else (r, {})
        (ASSETS / "personajes" / f"{f.__name__}.svg").write_text(sprite_svg(sp, anclas), encoding="utf-8")
    print("assets/personajes/*.svg (sprites sueltos para la página)")
